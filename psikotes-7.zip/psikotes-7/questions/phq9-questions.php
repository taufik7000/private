<?php
$questions = array(
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda mengalami sedikit minat atau kesenangan dalam melakukan sesuatu?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'phq9'
    ),
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda merasa sedih, murung, atau putus asa?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'phq9'
    ),
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda merasa sulit untuk tidur, tetap tertidur, atau tidur terlalu banyak?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'phq9'
    ),
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda merasa lelah atau kurang energi?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'phq9'
    ),
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda merasa nafsu makan berkurang atau makan berlebihan?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'phq9'
    ),
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda merasa buruk tentang diri Anda - atau merasa bahwa Anda gagal atau telah mengecewakan diri sendiri atau keluarga Anda?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'phq9'
    ),
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda merasa kesulitan berkonsentrasi pada hal-hal, seperti membaca koran atau menonton televisi?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'phq9'
    ),
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda merasa bergerak atau berbicara sangat lambat sehingga orang lain bisa memperhatikan? Atau, sebaliknya - begitu gelisah atau tidak bisa diam sehingga Anda lebih sering bergerak dari biasanya?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'phq9'
    ),
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda memiliki pikiran bahwa Anda lebih baik mati atau menyakiti diri sendiri dengan cara tertentu?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'phq9'
    ),
);
?>
