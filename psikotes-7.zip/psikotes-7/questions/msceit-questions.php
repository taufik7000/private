<?php
$questions = array(
    // Perceiving Emotions
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_1',
        'image' => plugin_dir_url(__FILE__) . '../images/happy1.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_2',
        'image' => plugin_dir_url(__FILE__) . '../images/sad1.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_3',
        'image' => plugin_dir_url(__FILE__) . '../images/angry1.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_4',
        'image' => plugin_dir_url(__FILE__) . '../images/surprised1.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_5',
        'image' => plugin_dir_url(__FILE__) . '../images/scared1.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Takut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_6',
        'image' => plugin_dir_url(__FILE__) . '../images/happy2.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_7',
        'image' => plugin_dir_url(__FILE__) . '../images/sad2.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_8',
        'image' => plugin_dir_url(__FILE__) . '../images/angry2.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_9',
        'image' => plugin_dir_url(__FILE__) . '../images/surprised2.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_10',
        'image' => plugin_dir_url(__FILE__) . '../images/scared2.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Takut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_11',
        'image' => plugin_dir_url(__FILE__) . '../images/happy3.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_12',
        'image' => plugin_dir_url(__FILE__) . '../images/sad3.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_13',
        'image' => plugin_dir_url(__FILE__) . '../images/angry3.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_14',
        'image' => plugin_dir_url(__FILE__) . '../images/surprised3.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_15',
        'image' => plugin_dir_url(__FILE__) . '../images/scared3.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Takut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_16',
        'image' => plugin_dir_url(__FILE__) . '../images/happy4.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_17',
        'image' => plugin_dir_url(__FILE__) . '../images/sad4.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_18',
        'image' => plugin_dir_url(__FILE__) . '../images/angry4.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_19',
        'image' => plugin_dir_url(__FILE__) . '../images/surprised4.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Terkejut'
        )
    ),
    array(
        'question' => 'Identifikasi emosi pada wajah berikut:',
        'name' => 'perceiving_emotions_20',
        'image' => plugin_dir_url(__FILE__) . '../images/scared4.jpg',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Takut'
        )
    ),

    // Using Emotions
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda akan memberikan pidato di depan audiens yang besar."',
        'name' => 'using_emotions_1',
        'options' => array(
            'A' => 'Gugup dan Bersemangat',
            'B' => 'Tenang dan Acuh',
            'C' => 'Bahagia dan Santai',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda menerima kabar baik tentang pekerjaan Anda."',
        'name' => 'using_emotions_2',
        'options' => array(
            'A' => 'Gembira dan Bersemangat',
            'B' => 'Cemas dan Khawatir',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda mengalami kecelakaan kecil di rumah."',
        'name' => 'using_emotions_3',
        'options' => array(
            'A' => 'Khawatir dan Cemas',
            'B' => 'Bahagia dan Santai',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda bertemu teman lama setelah bertahun-tahun."',
        'name' => 'using_emotions_4',
        'options' => array(
            'A' => 'Bahagia dan Bersemangat',
            'B' => 'Cemas dan Khawatir',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda mendapatkan kritik keras dari atasan Anda."',
        'name' => 'using_emotions_5',
        'options' => array(
            'A' => 'Sedih dan Kecewa',
            'B' => 'Bahagia dan Santai',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda mendapat undangan untuk acara yang sangat penting."',
        'name' => 'using_emotions_6',
        'options' => array(
            'A' => 'Gembira dan Bersemangat',
            'B' => 'Cemas dan Khawatir',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda harus mengerjakan tugas yang sangat sulit dan menantang."',
        'name' => 'using_emotions_7',
        'options' => array(
            'A' => 'Gugup dan Bersemangat',
            'B' => 'Tenang dan Acuh',
            'C' => 'Bahagia dan Santai',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda berhasil menyelesaikan proyek besar tepat waktu."',
        'name' => 'using_emotions_8',
        'options' => array(
            'A' => 'Gembira dan Bersemangat',
            'B' => 'Cemas dan Khawatir',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda mengetahui bahwa sahabat Anda akan menikah."',
        'name' => 'using_emotions_9',
        'options' => array(
            'A' => 'Gembira dan Bersemangat',
            'B' => 'Cemas dan Khawatir',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda baru saja membeli rumah baru."',
        'name' => 'using_emotions_10',
        'options' => array(
            'A' => 'Gembira dan Bersemangat',
            'B' => 'Cemas dan Khawatir',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
        array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda mendapatkan hadiah kejutan dari teman."',
        'name' => 'using_emotions_11',
        'options' => array(
            'A' => 'Gembira dan Bersemangat',
            'B' => 'Cemas dan Khawatir',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda kehilangan dompet Anda di tempat umum."',
        'name' => 'using_emotions_12',
        'options' => array(
            'A' => 'Khawatir dan Cemas',
            'B' => 'Bahagia dan Santai',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda mendapati bahwa proyek yang Anda kerjakan tidak berhasil."',
        'name' => 'using_emotions_13',
        'options' => array(
            'A' => 'Sedih dan Kecewa',
            'B' => 'Bahagia dan Santai',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda mendengar kabar buruk tentang kesehatan anggota keluarga."',
        'name' => 'using_emotions_14',
        'options' => array(
            'A' => 'Sedih dan Kecewa',
            'B' => 'Bahagia dan Santai',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda terlibat dalam kecelakaan lalu lintas ringan."',
        'name' => 'using_emotions_15',
        'options' => array(
            'A' => 'Khawatir dan Cemas',
            'B' => 'Bahagia dan Santai',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda terjebak dalam kemacetan lalu lintas yang sangat parah."',
        'name' => 'using_emotions_16',
        'options' => array(
            'A' => 'Khawatir dan Cemas',
            'B' => 'Bahagia dan Santai',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda mendapatkan tugas tambahan dari atasan Anda."',
        'name' => 'using_emotions_17',
        'options' => array(
            'A' => 'Khawatir dan Cemas',
            'B' => 'Bahagia dan Santai',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda mengetahui bahwa Anda akan menjadi orang tua."',
        'name' => 'using_emotions_18',
        'options' => array(
            'A' => 'Gembira dan Bersemangat',
            'B' => 'Cemas dan Khawatir',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda menerima pujian dari atasan Anda."',
        'name' => 'using_emotions_19',
        'options' => array(
            'A' => 'Gembira dan Bersemangat',
            'B' => 'Cemas dan Khawatir',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),
    array(
        'question' => 'Kombinasi emosi mana yang paling tepat menggambarkan skenario berikut: "Anda diundang ke pesta oleh teman baik Anda."',
        'name' => 'using_emotions_20',
        'options' => array(
            'A' => 'Gembira dan Bersemangat',
            'B' => 'Cemas dan Khawatir',
            'C' => 'Tenang dan Acuh',
            'D' => 'Marah dan Frustrasi'
        )
    ),

    // Understanding Emotions
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang baru saja dipecat dari pekerjaannya?',
        'name' => 'understanding_emotions_1',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Takut'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang memenangkan lotre?',
        'name' => 'understanding_emotions_2',
        'options' => array(
            'A' => 'Gembira',
            'B' => 'Cemas',
            'C' => 'Sedih',
            'D' => 'Marah'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang gagal dalam ujian penting?',
        'name' => 'understanding_emotions_3',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Takut'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang menerima hadiah dari teman?',
        'name' => 'understanding_emotions_4',
        'options' => array(
            'A' => 'Gembira',
            'B' => 'Cemas',
            'C' => 'Sedih',
            'D' => 'Marah'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang kehilangan hewan peliharaannya?',
        'name' => 'understanding_emotions_5',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Takut'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang baru saja dipromosikan di pekerjaannya?',
        'name' => 'understanding_emotions_6',
        'options' => array(
            'A' => 'Gembira',
            'B' => 'Cemas',
            'C' => 'Sedih',
            'D' => 'Marah'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang pindah ke kota baru?',
        'name' => 'understanding_emotions_7',
        'options' => array(
            'A' => 'Gembira',
            'B' => 'Cemas',
            'C' => 'Sedih',
            'D' => 'Takut'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang memenangkan kompetisi?',
        'name' => 'understanding_emotions_8',
        'options' => array(
            'A' => 'Gembira',
            'B' => 'Cemas',
            'C' => 'Sedih',
            'D' => 'Marah'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang menghadapi masalah kesehatan serius?',
        'name' => 'understanding_emotions_9',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Takut'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang berlibur di tempat impian mereka?',
        'name' => 'understanding_emotions_10',
        'options' => array(
            'A' => 'Gembira',
            'B' => 'Cemas',
            'C' => 'Sedih',
            'D' => 'Marah'
        )
    ),
    
        array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang mengalami kecelakaan lalu lintas?',
        'name' => 'understanding_emotions_11',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Takut'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang mendapatkan tugas baru di kantor?',
        'name' => 'understanding_emotions_12',
        'options' => array(
            'A' => 'Gembira',
            'B' => 'Cemas',
            'C' => 'Sedih',
            'D' => 'Marah'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang berpisah dengan pasangan mereka?',
        'name' => 'understanding_emotions_13',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Takut'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang baru saja menjadi orang tua?',
        'name' => 'understanding_emotions_14',
        'options' => array(
            'A' => 'Gembira',
            'B' => 'Cemas',
            'C' => 'Sedih',
            'D' => 'Marah'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang melihat film horor?',
        'name' => 'understanding_emotions_15',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Takut'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang baru saja selesai ujian?',
        'name' => 'understanding_emotions_16',
        'options' => array(
            'A' => 'Gembira',
            'B' => 'Cemas',
            'C' => 'Sedih',
            'D' => 'Marah'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang mendapatkan promosi besar di pekerjaan?',
        'name' => 'understanding_emotions_17',
        'options' => array(
            'A' => 'Gembira',
            'B' => 'Cemas',
            'C' => 'Sedih',
            'D' => 'Marah'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang menghadiri acara pemakaman?',
        'name' => 'understanding_emotions_18',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Takut'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang menerima hadiah ulang tahun dari teman?',
        'name' => 'understanding_emotions_19',
        'options' => array(
            'A' => 'Gembira',
            'B' => 'Cemas',
            'C' => 'Sedih',
            'D' => 'Marah'
        )
    ),
    array(
        'question' => 'Apa yang mungkin dirasakan seseorang yang melihat kecelakaan di jalan?',
        'name' => 'understanding_emotions_20',
        'options' => array(
            'A' => 'Bahagia',
            'B' => 'Sedih',
            'C' => 'Marah',
            'D' => 'Takut'
        )
    ),

    // Managing Emotions
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi marah saat menghadapi konflik di tempat kerja?',
        'name' => 'managing_emotions_1',
        'options' => array(
            'A' => 'Berteriak',
            'B' => 'Tenang dan bicara dengan baik',
            'C' => 'Mengabaikan',
            'D' => 'Pergi dari tempat'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi sedih setelah kehilangan orang yang dicintai?',
        'name' => 'managing_emotions_2',
        'options' => array(
            'A' => 'Menangis sepanjang hari',
            'B' => 'Berbicara dengan teman atau konselor',
            'C' => 'Mengabaikan perasaan tersebut',
            'D' => 'Mengurung diri di kamar'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi cemas sebelum presentasi besar?',
        'name' => 'managing_emotions_3',
        'options' => array(
            'A' => 'Berlatih presentasi sebelumnya',
            'B' => 'Menghindari persiapan',
            'C' => 'Berbicara negatif pada diri sendiri',
            'D' => 'Tidur sepanjang hari'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi frustrasi saat terjebak dalam kemacetan?',
        'name' => 'managing_emotions_4',
        'options' => array(
            'A' => 'Mengeluh tanpa henti',
            'B' => 'Mendengarkan musik atau podcast',
            'C' => 'Menghentikan kendaraan dan berjalan kaki',
            'D' => 'Berkendara dengan cepat dan agresif'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi bahagia saat merayakan pencapaian besar?',
        'name' => 'managing_emotions_5',
        'options' => array(
            'A' => 'Merayakan dengan teman dan keluarga',
            'B' => 'Menyimpan kabar baik untuk diri sendiri',
            'C' => 'Mengabaikan perasaan bahagia tersebut',
            'D' => 'Membeli barang-barang mahal'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi takut saat berada di tempat yang tinggi?',
        'name' => 'managing_emotions_6',
        'options' => array(
            'A' => 'Menjauh dari tepi',
            'B' => 'Berteriak sekeras mungkin',
            'C' => 'Mengabaikan rasa takut',
            'D' => 'Mencari bantuan profesional'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi cemas saat menghadapi wawancara kerja?',
        'name' => 'managing_emotions_7',
        'options' => array(
            'A' => 'Berlatih wawancara dengan teman',
            'B' => 'Mengabaikan persiapan',
            'C' => 'Berbicara negatif pada diri sendiri',
            'D' => 'Membatalkan wawancara'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi sedih saat melihat film sedih?',
        'name' => 'managing_emotions_8',
        'options' => array(
            'A' => 'Menangis dan mengeluarkan perasaan',
            'B' => 'Mengabaikan perasaan tersebut',
            'C' => 'Berbicara dengan teman tentang film',
            'D' => 'Menghindari menonton film tersebut'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi marah saat bermain game dan kalah?',
        'name' => 'managing_emotions_9',
        'options' => array(
            'A' => 'Berteriak pada layar',
            'B' => 'Tenang dan mencoba lagi',
            'C' => 'Mengabaikan kekalahan',
            'D' => 'Menyalahkan orang lain'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi takut saat mendengar suara aneh di malam hari?',
        'name' => 'managing_emotions_10',
        'options' => array(
            'A' => 'Menelpon polisi',
            'B' => 'Mengabaikan suara tersebut',
            'C' => 'Mencari tahu sumber suara',
            'D' => 'Berlari keluar rumah'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi marah saat ada yang menyalip di jalan?',
        'name' => 'managing_emotions_11',
        'options' => array(
            'A' => 'Mengeluh tanpa henti',
            'B' => 'Tetap tenang dan lanjutkan berkendara',
            'C' => 'Mengabaikan perasaan tersebut',
            'D' => 'Berkendara dengan cepat dan agresif'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi takut saat akan berbicara di depan umum?',
        'name' => 'managing_emotions_12',
        'options' => array(
            'A' => 'Berlatih sebelumnya',
            'B' => 'Menghindari persiapan',
            'C' => 'Berbicara negatif pada diri sendiri',
            'D' => 'Membatalkan acara'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi bahagia saat mendapatkan hadiah kejutan?',
        'name' => 'managing_emotions_13',
        'options' => array(
            'A' => 'Merayakan dengan teman dan keluarga',
            'B' => 'Menyimpan kabar baik untuk diri sendiri',
            'C' => 'Mengabaikan perasaan bahagia tersebut',
            'D' => 'Membeli barang-barang mahal'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi cemas saat menunggu hasil ujian?',
        'name' => 'managing_emotions_14',
        'options' => array(
            'A' => 'Berlatih relaksasi dan meditasi',
            'B' => 'Mengabaikan perasaan tersebut',
            'C' => 'Berbicara negatif pada diri sendiri',
            'D' => 'Memikirkan hal lain'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi sedih saat mendengar kabar buruk?',
        'name' => 'managing_emotions_15',
        'options' => array(
            'A' => 'Menangis dan mengeluarkan perasaan',
            'B' => 'Mengabaikan perasaan tersebut',
            'C' => 'Berbicara dengan teman atau konselor',
            'D' => 'Mengurung diri di kamar'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi marah saat ada yang mengkritik Anda?',
        'name' => 'managing_emotions_16',
        'options' => array(
            'A' => 'Berteriak pada orang tersebut',
            'B' => 'Tetap tenang dan dengarkan kritik tersebut',
            'C' => 'Mengabaikan kritik',
            'D' => 'Menyalahkan orang lain'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi takut saat melihat film horor?',
        'name' => 'managing_emotions_17',
        'options' => array(
            'A' => 'Menjauh dari layar',
            'B' => 'Berteriak sekeras mungkin',
            'C' => 'Mengabaikan rasa takut',
            'D' => 'Mencari bantuan profesional'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi cemas saat menghadapi ujian penting?',
        'name' => 'managing_emotions_18',
        'options' => array(
            'A' => 'Berlatih ujian sebelumnya',
            'B' => 'Mengabaikan persiapan',
            'C' => 'Berbicara negatif pada diri sendiri',
            'D' => 'Tidur sepanjang hari'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi bahagia saat memenangkan kompetisi?',
        'name' => 'managing_emotions_19',
        'options' => array(
            'A' => 'Merayakan dengan teman dan keluarga',
            'B' => 'Menyimpan kabar baik untuk diri sendiri',
            'C' => 'Mengabaikan perasaan bahagia tersebut',
            'D' => 'Membeli barang-barang mahal'
        )
    ),
    array(
        'question' => 'Bagaimana cara terbaik untuk mengelola emosi marah saat ada yang memotong antrian?',
        'name' => 'managing_emotions_20',
        'options' => array(
            'A' => 'Mengeluh tanpa henti',
            'B' => 'Tetap tenang dan lanjutkan menunggu',
            'C' => 'Mengabaikan perasaan tersebut',
            'D' => 'Berkelahi dengan orang tersebut'
        )
    ),
);
?>
