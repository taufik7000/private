<?php
$questions = array(
    // Realistic
    array(
        'question' => 'Apakah Anda menikmati bekerja dengan alat dan mesin?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda suka memperbaiki barang yang rusak?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda menikmati kegiatan di luar ruangan seperti berkebun atau berkamping?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda suka mengendarai kendaraan berat atau mengoperasikan peralatan besar?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda suka bekerja dengan tangan Anda, seperti dalam pertukangan atau kerajinan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda menikmati pekerjaan fisik atau manual?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda suka mengikuti petunjuk dan prosedur dalam pekerjaan Anda?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda menikmati pekerjaan yang melibatkan pemecahan masalah teknis?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda merasa puas saat menyelesaikan proyek yang membutuhkan keterampilan praktis?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda suka bekerja di lingkungan yang aktif dan dinamis?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),

    // Investigative
    array(
        'question' => 'Apakah Anda suka melakukan eksperimen atau penelitian?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda menikmati membaca buku atau artikel sains?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda suka memecahkan teka-teki atau masalah logika?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda suka mengumpulkan dan menganalisis data?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda suka mencari jawaban atas pertanyaan-pertanyaan kompleks?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda suka mempelajari konsep-konsep baru dalam sains atau matematika?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda menikmati menguji hipotesis dalam penelitian?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda suka menganalisis masalah dan mencari solusinya?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda menikmati pekerjaan yang melibatkan pengumpulan fakta dan informasi?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda suka mendalami topik tertentu secara mendalam?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),

    // Artistic
    array(
        'question' => 'Apakah Anda menikmati kegiatan seni seperti melukis atau menulis?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda suka bermain musik atau menari?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda suka membuat atau merancang sesuatu?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda menikmati mengekspresikan diri melalui karya seni?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda suka menghadiri pameran seni atau konser?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda menikmati menulis cerita atau puisi?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda suka membuat sketsa atau gambar?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda merasa puas saat menciptakan sesuatu yang baru?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda suka bekerja di lingkungan yang kreatif dan inspiratif?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda menikmati belajar tentang seni dan budaya?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),

    // Social
    array(
        'question' => 'Apakah Anda suka membantu orang lain atau bekerja dalam tim?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda menikmati mengajar atau melatih orang lain?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda suka mendengarkan dan memberikan nasihat kepada teman?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda suka bekerja sebagai sukarelawan untuk organisasi amal?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda merasa puas saat membantu orang lain mencapai tujuan mereka?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda suka bekerja dalam lingkungan yang kolaboratif?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda menikmati memberikan dukungan emosional kepada orang lain?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda suka bekerja dengan anak-anak atau orang dewasa yang membutuhkan bantuan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda merasa nyaman bekerja dalam kelompok besar?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda menikmati memimpin kegiatan sosial atau acara?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),

    // Enterprising
    array(
        'question' => 'Apakah Anda menikmati memimpin proyek atau membuat keputusan penting?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda suka menjual produk atau layanan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda suka berbicara di depan umum atau memberikan presentasi?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda merasa nyaman dalam mengambil risiko?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda suka merancang strategi untuk mencapai tujuan tertentu?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda suka bekerja dalam lingkungan yang kompetitif?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda menikmati mengelola tim atau organisasi?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda merasa puas saat mencapai target penjualan atau keuntungan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda suka mengembangkan ide bisnis baru?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda menikmati bekerja di lingkungan yang dinamis dan berubah cepat?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),

    // Conventional
    array(
        'question' => 'Apakah Anda suka mengatur data atau bekerja dengan angka?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda menikmati pekerjaan yang melibatkan detail dan akurasi?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda suka mengelola dokumen atau catatan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda merasa puas saat menyelesaikan tugas administrasi?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda suka menggunakan perangkat lunak untuk mengelola data?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda menikmati pekerjaan yang membutuhkan ketelitian?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda suka bekerja dengan sistem dan prosedur yang terstruktur?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda merasa puas saat mengelola anggaran atau laporan keuangan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda suka mengikuti aturan dan regulasi dalam pekerjaan Anda?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda menikmati pekerjaan yang membutuhkan organisasi dan perencanaan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
);
?>
