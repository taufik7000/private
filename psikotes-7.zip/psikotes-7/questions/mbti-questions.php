<?php
$questions = array(
    // Ekstroversi (E) vs. Introversi (I)
    array(
        'question' => 'Ketika berada di pesta, Anda lebih suka:',
        'options' => array(
            'E' => 'Berbicara dengan banyak orang baru dan menikmati suasana ramai',
            'I' => 'Berbicara dengan beberapa teman dekat di sudut yang tenang'
        )
    ),
    array(
        'question' => 'Pada akhir pekan, Anda lebih sering:',
        'options' => array(
            'I' => 'Menghabiskan waktu sendirian dengan hobi atau buku',
            'E' => 'Menghabiskan waktu dengan kegiatan sosial bersama teman-teman'
        )
    ),
    array(
        'question' => 'Dalam rapat kerja, Anda:',
        'options' => array(
            'E' => 'Aktif berbicara dan mengemukakan pendapat Anda',
            'I' => 'Mendengarkan lebih banyak dan berbicara hanya saat diperlukan'
        )
    ),
    array(
        'question' => 'Ketika sedang stres, Anda cenderung:',
        'options' => array(
            'I' => 'Mencari waktu sendirian untuk merenung dan memulihkan diri',
            'E' => 'Mencari dukungan dan berbicara dengan banyak orang'
        )
    ),
    array(
        'question' => 'Saat makan siang di kantor, Anda lebih suka:',
        'options' => array(
            'I' => 'Makan sendirian atau dengan satu dua teman di meja kerja Anda',
            'E' => 'Makan bersama dengan banyak kolega di ruang makan'
        )
    ),
    array(
        'question' => 'Anda merasa lebih hidup dalam:',
        'options' => array(
            'I' => 'Situasi intim atau satu-satu',
            'E' => 'Kelompok besar'
        )
    ),
    array(
        'question' => 'Anda lebih cenderung:',
        'options' => array(
            'E' => 'Menyapa orang baru terlebih dahulu',
            'I' => 'Menunggu orang lain menyapa Anda terlebih dahulu'
        )
    ),
    array(
        'question' => 'Ketika di pesta, Anda biasanya:',
        'options' => array(
            'E' => 'Berada di tengah keramaian',
            'I' => 'Berbicara dengan beberapa orang terdekat'
        )
    ),
    array(
        'question' => 'Pada akhir pekan, Anda lebih sering:',
        'options' => array(
            'I' => 'Menghabiskan waktu sendirian dengan hobi atau buku',
            'E' => 'Menghabiskan waktu dengan kegiatan sosial bersama teman-teman'
        )
    ),
    array(
        'question' => 'Dalam rapat kerja, Anda:',
        'options' => array(
            'I' => 'Mendengarkan lebih banyak dan berbicara hanya saat diperlukan',
            'E' => 'Aktif berbicara dan mengemukakan pendapat Anda'
        )
    ),
    array(
        'question' => 'Ketika sedang stres, Anda cenderung:',
        'options' => array(
            'E' => 'Mencari dukungan dan berbicara dengan banyak orang',
            'I' => 'Mencari waktu sendirian untuk merenung dan memulihkan diri'
        )
    ),
    array(
        'question' => 'Saat makan siang di kantor, Anda lebih suka:',
        'options' => array(
            'E' => 'Makan bersama dengan banyak kolega di ruang makan',
            'I' => 'Makan sendirian atau dengan satu dua teman di meja kerja Anda'
        )
    ),

    // Sensing (S) vs. Intuition (N)
    array(
        'question' => 'Ketika merencanakan liburan, Anda lebih tertarik pada:',
        'options' => array(
            'S' => 'Detail spesifik tentang tempat yang akan dikunjungi',
            'N' => 'Gambaran besar dan ide-ide baru tentang petualangan yang mungkin'
        )
    ),
    array(
        'question' => 'Dalam mengambil keputusan, Anda lebih sering:',
        'options' => array(
            'N' => 'Mengandalkan intuisi dan gambaran masa depan',
            'S' => 'Mengandalkan fakta dan pengalaman sebelumnya'
        )
    ),
    array(
        'question' => 'Saat mengikuti petunjuk, Anda lebih suka:',
        'options' => array(
            'N' => 'Gambaran umum dan berimprovisasi sesuai situasi',
            'S' => 'Instruksi langkah demi langkah yang jelas'
        )
    ),
    array(
        'question' => 'Ketika mempelajari sesuatu yang baru, Anda lebih suka:',
        'options' => array(
            'S' => 'Memulai dengan dasar-dasar dan rincian praktis',
            'N' => 'Memahami konsep dan teori terlebih dahulu'
        )
    ),
    array(
        'question' => 'Dalam percakapan, Anda lebih sering:',
        'options' => array(
            'S' => 'Berbicara tentang fakta dan kejadian nyata',
            'N' => 'Berbicara tentang kemungkinan dan ide-ide baru'
        )
    ),
    array(
        'question' => 'Anda lebih suka:',
        'options' => array(
            'N' => 'Teori dan abstraksi',
            'S' => 'Informasi konkret'
        )
    ),
    array(
        'question' => 'Anda merasa puas ketika:',
        'options' => array(
            'N' => 'Mengeksplorasi ide baru',
            'S' => 'Mendapatkan fakta yang jelas'
        )
    ),
    array(
        'question' => 'Anda cenderung:',
        'options' => array(
            'N' => 'Mengandalkan intuisi',
            'S' => 'Mengandalkan pengalaman langsung'
        )
    ),
    array(
        'question' => 'Anda lebih suka:',
        'options' => array(
            'S' => 'Data yang dapat diukur',
            'N' => 'Kemungkinan dan potensi'
        )
    ),
    array(
        'question' => 'Anda merasa puas ketika:',
        'options' => array(
            'S' => 'Menggunakan indera untuk memahami dunia',
            'N' => 'Menggunakan imajinasi untuk memahami dunia'
        )
    ),
    array(
        'question' => 'Anda cenderung:',
        'options' => array(
            'S' => 'Menghargai kenyataan',
            'N' => 'Menghargai impian'
        )
    ),
    array(
        'question' => 'Anda lebih suka:',
        'options' => array(
            'S' => 'Mengikuti langkah-langkah yang terbukti',
            'N' => 'Mencoba pendekatan baru'
        )
    ),

    // Thinking (T) vs. Feeling (F)
    array(
        'question' => 'Saat menyelesaikan masalah, Anda lebih mengutamakan:',
        'options' => array(
            'T' => 'Analisis logis dan objektif',
            'F' => 'Pertimbangan dampak emosional pada orang lain'
        )
    ),
    array(
        'question' => 'Dalam memberikan kritik, Anda lebih:',
        'options' => array(
            'T' => 'Langsung dan berdasarkan fakta',
            'F' => 'Menyampaikan dengan hati-hati untuk menjaga perasaan'
        )
    ),
    array(
        'question' => 'Ketika membuat keputusan penting, Anda lebih sering:',
        'options' => array(
            'T' => 'Mempertimbangkan manfaat dan kerugian secara objektif',
            'F' => 'Mempertimbangkan bagaimana keputusan itu mempengaruhi orang lain'
        )
    ),
    array(
        'question' => 'Dalam konflik, Anda lebih suka:',
        'options' => array(
            'F' => 'Mencari solusi yang menjaga hubungan baik',
            'T' => 'Mencari solusi yang logis dan adil'
        )
    ),
    array(
        'question' => 'Saat memimpin tim, Anda lebih:',
        'options' => array(
            'T' => 'Fokus pada pencapaian tujuan dan efisiensi',
            'F' => 'Fokus pada kesejahteraan tim dan harmoni'
        )
    ),
    array(
        'question' => 'Ketika menyelesaikan proyek, Anda lebih suka:',
        'options' => array(
            'F' => 'Menyelesaikan tugas dengan mempertimbangkan perasaan tim',
            'T' => 'Menyelesaikan tugas dengan efisiensi tinggi'
        )
    ),
    array(
        'question' => 'Anda lebih nyaman dengan:',
        'options' => array(
            'T' => 'Pendekatan yang terstruktur dan logis',
            'F' => 'Pendekatan yang fleksibel dan intuitif'
        )
    ),
    array(
        'question' => 'Anda lebih sering:',
        'options' => array(
            'T' => 'Menyelesaikan masalah dengan analisis',
            'F' => 'Menyelesaikan masalah dengan hati'
        )
    ),
    array(
        'question' => 'Ketika berdebat, Anda lebih mengutamakan:',
        'options' => array(
            'T' => 'Argumen yang logis dan rasional',
            'F' => 'Perasaan dan perspektif lawan bicara'
        )
    ),
    array(
        'question' => 'Dalam situasi darurat, Anda lebih:',
        'options' => array(
            'T' => 'Tetap tenang dan berpikir rasional',
            'F' => 'Berusaha memahami perasaan orang-orang di sekitar'
        )
    ),
    array(
        'question' => 'Ketika bekerja dalam tim, Anda lebih:',
        'options' => array(
            'T' => 'Mengejar hasil akhir yang efektif',
            'F' => 'Menciptakan suasana kerja yang harmonis'
        )
    ),
    array(
        'question' => 'Saat mengelola konflik, Anda lebih sering:',
        'options' => array(
            'T' => 'Mencari solusi yang adil dan logis',
            'F' => 'Mencari solusi yang mempertahankan hubungan baik'
        )
    ),

    // Judging (J) vs. Perceiving (P)
    array(
        'question' => 'Ketika merencanakan proyek, Anda lebih suka:',
        'options' => array(
            'J' => 'Membuat rencana terperinci dan mengikuti jadwal ketat',
            'P' => 'Menjaga fleksibilitas dan beradaptasi dengan situasi'
        )
    ),
    array(
        'question' => 'Dalam mengatur waktu, Anda lebih sering:',
        'options' => array(
            'P' => 'Membiarkan hari berjalan secara alami tanpa rencana ketat',
            'J' => 'Menyusun jadwal harian yang rinci'
        )
    ),
    array(
        'question' => 'Ketika menghadapi perubahan mendadak, Anda lebih suka:',
        'options' => array(
            'J' => 'Tetap berpegang pada rencana awal sejauh mungkin',
            'P' => 'Beradaptasi dan mencari solusi baru dengan cepat'
        )
    ),
    array(
        'question' => 'Dalam menjalani kehidupan sehari-hari, Anda lebih sering:',
        'options' => array(
            'J' => 'Menyukai rutinitas yang teratur',
            'P' => 'Menikmati variasi dan kebebasan'
        )
    ),
    array(
        'question' => 'Saat mengerjakan tugas, Anda lebih suka:',
        'options' => array(
            'J' => 'Menyelesaikan tugas satu per satu sesuai prioritas',
            'P' => 'Mengambil beberapa tugas sekaligus dan mengikuti inspirasi'
        )
    ),
    array(
        'question' => 'Anda lebih suka:',
        'options' => array(
            'J' => 'Menetapkan tujuan yang jelas',
            'P' => 'Menjelajahi banyak pilihan'
        )
    ),
    array(
        'question' => 'Ketika bekerja, Anda lebih sering:',
        'options' => array(
            'J' => 'Mengikuti rencana dan jadwal yang telah dibuat',
            'P' => 'Mengikuti alur dan beradaptasi'
        )
    ),
    array(
        'question' => 'Dalam kegiatan sehari-hari, Anda lebih suka:',
        'options' => array(
            'J' => 'Segalanya teratur dan terstruktur',
            'P' => 'Segalanya fleksibel dan spontan'
        )
    ),
    array(
        'question' => 'Ketika membuat keputusan, Anda lebih:',
        'options' => array(
            'P' => 'Menjaga semua pilihan terbuka selama mungkin',
            'J' => 'Mengambil keputusan dengan cepat dan tegas'
        )
    ),
    array(
        'question' => 'Dalam perjalanan, Anda lebih suka:',
        'options' => array(
            'J' => 'Merencanakan setiap detail terlebih dahulu',
            'P' => 'Berimprovisasi sepanjang perjalanan'
        )
    ),
    array(
        'question' => 'Ketika mengatur rumah, Anda lebih:',
        'options' => array(
            'J' => 'Menjaga semuanya dalam urutan yang teratur',
            'P' => 'Membiarkan barang-barang di tempat yang nyaman'
        )
    ),
    array(
        'question' => 'Ketika bekerja dengan orang lain, Anda lebih:',
        'options' => array(
            'J' => 'Menetapkan peran dan tanggung jawab yang jelas',
            'P' => 'Menjaga fleksibilitas dan kolaborasi'
        )
    )
);
?>
