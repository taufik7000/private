<?php
$questions = array(
    // Emotional Expressivity
    array(
        'question' => 'Saya dengan mudah mengungkapkan emosi saya kepada orang lain.',
        'name' => 'emotional_expressivity_1',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya menunjukkan kegembiraan saya dengan jelas.',
        'name' => 'emotional_expressivity_2',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Orang lain tahu ketika saya marah.',
        'name' => 'emotional_expressivity_3',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya sering tersenyum kepada orang lain.',
        'name' => 'emotional_expressivity_4',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya menunjukkan ketertarikan saya pada orang lain dengan ekspresi wajah.',
        'name' => 'emotional_expressivity_5',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    
    // Emotional Sensitivity
    array(
        'question' => 'Saya bisa memahami perasaan orang lain hanya dengan melihat mereka.',
        'name' => 'emotional_sensitivity_1',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya dapat mendeteksi perubahan suasana hati orang lain.',
        'name' => 'emotional_sensitivity_2',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya memahami ketika seseorang merasa tidak nyaman.',
        'name' => 'emotional_sensitivity_3',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya bisa tahu ketika seseorang membutuhkan dukungan emosional.',
        'name' => 'emotional_sensitivity_4',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya cepat merasakan suasana hati kelompok.',
        'name' => 'emotional_sensitivity_5',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    
    // Emotional Control
    array(
        'question' => 'Saya dapat mengendalikan emosi saya dengan baik.',
        'name' => 'emotional_control_1',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya bisa tetap tenang di bawah tekanan.',
        'name' => 'emotional_control_2',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya jarang menunjukkan emosi negatif.',
        'name' => 'emotional_control_3',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya bisa mengatasi frustrasi dengan cepat.',
        'name' => 'emotional_control_4',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya tetap tenang ketika orang lain marah kepada saya.',
        'name' => 'emotional_control_5',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    
    // Social Expressivity
    array(
        'question' => 'Saya merasa nyaman berbicara di depan umum.',
        'name' => 'social_expressivity_1',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya dengan mudah memulai percakapan dengan orang baru.',
        'name' => 'social_expressivity_2',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya sering mengungkapkan pendapat saya dalam diskusi kelompok.',
        'name' => 'social_expressivity_3',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya suka berinteraksi dengan orang lain dalam kegiatan sosial.',
        'name' => 'social_expressivity_4',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya sering bercanda dengan teman dan keluarga.',
        'name' => 'social_expressivity_5',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    
    // Social Sensitivity
    array(
        'question' => 'Saya memahami isyarat sosial dengan baik.',
        'name' => 'social_sensitivity_1',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya menyadari ketika seseorang tidak ingin berbicara.',
        'name' => 'social_sensitivity_2',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya dapat menilai suasana hati orang lain dari bahasa tubuh mereka.',
        'name' => 'social_sensitivity_3',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya dapat memahami maksud orang lain hanya dari nada suara mereka.',
        'name' => 'social_sensitivity_4',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya cepat menangkap perubahan dalam dinamika kelompok.',
        'name' => 'social_sensitivity_5',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    
    // Social Control
    array(
        'question' => 'Saya dapat memimpin percakapan dengan baik.',
        'name' => 'social_control_1',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya merasa nyaman mengarahkan kegiatan kelompok.',
        'name' => 'social_control_2',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya dapat mengendalikan situasi sosial dengan mudah.',
        'name' => 'social_control_3',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mampu membuat keputusan dalam situasi sosial yang sulit.',
        'name' => 'social_control_4',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya dapat menenangkan konflik dalam kelompok.',
        'name' => 'social_control_5',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    )
);
?>
