<?php
$questions = array(
    // Realistic
    array(
        'question' => 'Apakah Anda menikmati memperbaiki alat atau mesin yang rusak?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda suka bekerja di luar ruangan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda menikmati pekerjaan fisik yang membutuhkan keterampilan tangan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda suka menggunakan alat-alat seperti palu atau obeng?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda menikmati pekerjaan yang membutuhkan kekuatan fisik?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda suka memecahkan masalah mekanis?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda menikmati berkebun atau merawat tanaman?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda suka mengoperasikan peralatan berat?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda menikmati kegiatan yang membutuhkan keterampilan praktis?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),
    array(
        'question' => 'Apakah Anda suka bekerja di lingkungan yang dinamis dan penuh aktivitas?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'realistic'
    ),

    // Investigative
    array(
        'question' => 'Apakah Anda suka melakukan eksperimen atau penelitian ilmiah?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda menikmati memecahkan teka-teki atau masalah logika?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda suka membaca buku atau artikel ilmiah?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda menikmati menganalisis data untuk menemukan pola atau tren?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda suka memahami cara kerja sesuatu?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda suka mencari jawaban atas pertanyaan-pertanyaan kompleks?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda menikmati memecahkan masalah teknis atau ilmiah?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda suka belajar tentang sains atau teknologi baru?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda menikmati menguji teori ilmiah?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),
    array(
        'question' => 'Apakah Anda suka mengumpulkan dan menganalisis informasi?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'investigative'
    ),

    // Artistic
    array(
        'question' => 'Apakah Anda menikmati melukis atau menggambar?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda suka menulis cerita atau puisi?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda suka bermain musik atau bernyanyi?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda menikmati kegiatan teater atau drama?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda suka merancang atau membuat sesuatu yang baru?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda menikmati mengekspresikan diri melalui seni visual?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda suka menghadiri pameran seni atau konser?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda menikmati membuat karya seni atau kerajinan tangan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda suka mengeksplorasi ide-ide kreatif?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),
    array(
        'question' => 'Apakah Anda menikmati bekerja di lingkungan yang kreatif?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'artistic'
    ),

    // Social
    array(
        'question' => 'Apakah Anda suka membantu orang lain?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda menikmati mengajar atau melatih orang lain?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda suka bekerja dengan anak-anak atau orang dewasa yang membutuhkan bantuan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda menikmati memberikan nasihat atau dukungan emosional kepada teman?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda suka bekerja sebagai sukarelawan di organisasi amal?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda menikmati memimpin kelompok atau kegiatan sosial?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda suka mengorganisir acara atau kegiatan komunitas?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda menikmati bekerja dalam tim?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda suka mengajari orang lain keterampilan baru?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),
    array(
        'question' => 'Apakah Anda merasa puas saat membantu orang lain mencapai tujuan mereka?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'social'
    ),

    // Enterprising
    array(
        'question' => 'Apakah Anda menikmati memimpin proyek atau tim?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda suka menjual produk atau layanan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda menikmati berbicara di depan umum atau memberikan presentasi?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda merasa nyaman mengambil risiko dalam bisnis?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda suka merancang strategi untuk mencapai tujuan tertentu?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda menikmati mengelola tim atau organisasi?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda merasa puas saat mencapai target penjualan atau keuntungan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda suka mengembangkan ide bisnis baru?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda menikmati bekerja di lingkungan yang kompetitif?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),
    array(
        'question' => 'Apakah Anda suka mencari peluang bisnis baru?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'enterprising'
    ),

    // Conventional
    array(
        'question' => 'Apakah Anda suka bekerja dengan data atau angka?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda menikmati pekerjaan yang membutuhkan ketelitian dan akurasi?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda suka mengelola dokumen atau catatan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda merasa puas saat menyelesaikan tugas administrasi?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda suka menggunakan perangkat lunak untuk mengelola data?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda menikmati pekerjaan yang membutuhkan ketelitian?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda suka bekerja dengan sistem dan prosedur yang terstruktur?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda merasa puas saat mengelola anggaran atau laporan keuangan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda suka mengikuti aturan dan regulasi dalam pekerjaan Anda?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
    array(
        'question' => 'Apakah Anda menikmati pekerjaan yang membutuhkan organisasi dan perencanaan?',
        'options' => array(
            'Y' => 'Ya',
            'N' => 'Tidak'
        ),
        'scale' => 'conventional'
    ),
);
?>
