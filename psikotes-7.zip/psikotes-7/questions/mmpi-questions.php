<?php
$questions = array(
    // Hypochondriasis (Hs)
    array(
        'question' => 'Saya sering merasa tegang atau cemas tanpa alasan yang jelas.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypochondriasis'
    ),
    array(
        'question' => 'Saya sering merasa sakit atau tidak nyaman di tubuh saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypochondriasis'
    ),
    array(
        'question' => 'Saya khawatir tentang kesehatan saya lebih dari orang lain.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypochondriasis'
    ),
    array(
        'question' => 'Saya sering mencari informasi tentang gejala penyakit.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypochondriasis'
    ),
    array(
        'question' => 'Saya merasa ada sesuatu yang salah dengan tubuh saya, meskipun dokter mengatakan saya sehat.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypochondriasis'
    ),
    array(
        'question' => 'Saya sering merasa lelah atau lesu.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypochondriasis'
    ),
    array(
        'question' => 'Saya merasa lebih baik setelah mengunjungi dokter.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypochondriasis'
    ),
    array(
        'question' => 'Saya sering memeriksa tubuh saya untuk mencari tanda-tanda penyakit.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypochondriasis'
    ),
    array(
        'question' => 'Saya merasa cemas ketika mendengar tentang penyakit orang lain.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypochondriasis'
    ),
    array(
        'question' => 'Saya sering berpikir tentang kematian.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypochondriasis'
    ),
    
    // Depression (D)
    array(
        'question' => 'Saya sering merasa sedih atau tertekan.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'depression'
    ),
    array(
        'question' => 'Saya merasa sulit untuk menikmati hal-hal yang dulu saya nikmati.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'depression'
    ),
    array(
        'question' => 'Saya sering merasa putus asa tentang masa depan.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'depression'
    ),
    array(
        'question' => 'Saya sulit berkonsentrasi pada tugas sehari-hari.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'depression'
    ),
    array(
        'question' => 'Saya merasa lelah hampir sepanjang waktu.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'depression'
    ),
    array(
        'question' => 'Saya merasa bahwa hidup tidak layak untuk dijalani.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'depression'
    ),
    array(
        'question' => 'Saya merasa diri saya tidak berharga.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'depression'
    ),
    array(
        'question' => 'Saya sulit tidur atau tidur terlalu banyak.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'depression'
    ),
    array(
        'question' => 'Saya kehilangan minat pada aktivitas sehari-hari.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'depression'
    ),
    array(
        'question' => 'Saya sering merasa cemas atau khawatir berlebihan.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'depression'
    ),
    
    // Hysteria (Hy)
    array(
        'question' => 'Saya mudah tersinggung atau marah.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hysteria'
    ),
    array(
        'question' => 'Saya sering merasa tertekan ketika menghadapi masalah.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hysteria'
    ),
    array(
        'question' => 'Saya merasa sulit untuk menenangkan diri ketika saya marah.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hysteria'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering bereaksi berlebihan terhadap situasi.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hysteria'
    ),
    array(
        'question' => 'Saya sering merasa gelisah atau tidak nyaman.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hysteria'
    ),
    array(
        'question' => 'Saya merasa bahwa saya tidak dapat mengendalikan emosi saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hysteria'
    ),
    array(
        'question' => 'Saya merasa bahwa orang lain tidak memahami saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hysteria'
    ),
    array(
        'question' => 'Saya sering merasa cemas tanpa alasan yang jelas.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hysteria'
    ),
    array(
        'question' => 'Saya sering merasa lelah atau lesu.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hysteria'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering bereaksi berlebihan terhadap masalah kecil.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hysteria'
    ),
    
    // Psychopathic Deviate (Pd)
    array(
        'question' => 'Saya memiliki masalah dengan otoritas.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychopathic_deviate'
    ),
    array(
        'question' => 'Saya sering melanggar aturan tanpa merasa bersalah.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychopathic_deviate'
    ),
    array(
        'question' => 'Saya merasa bahwa saya tidak perlu mengikuti aturan.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychopathic_deviate'
    ),
    array(
        'question' => 'Saya merasa bahwa orang lain terlalu mengatur saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychopathic_deviate'
    ),
    array(
        'question' => 'Saya sering merasa bahwa saya diperlakukan tidak adil oleh orang lain.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychopathic_deviate'
    ),
    array(
        'question' => 'Saya sering merasa bahwa saya berbeda dari orang lain.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychopathic_deviate'
    ),
    array(
        'question' => 'Saya merasa bahwa saya tidak cocok dengan lingkungan saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychopathic_deviate'
    ),
    array(
        'question' => 'Saya sering merasa kesulitan untuk mengikuti aturan atau norma sosial.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychopathic_deviate'
    ),
    array(
        'question' => 'Saya merasa bahwa saya lebih baik daripada orang lain.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychopathic_deviate'
    ),
    array(
        'question' => 'Saya merasa bahwa saya tidak perlu mematuhi otoritas.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychopathic_deviate'
    ),
    
    // Masculinity-Femininity (Mf)
    array(
        'question' => 'Saya tertarik pada kegiatan yang biasanya dilakukan oleh lawan jenis saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'masculinity_femininity'
    ),
    array(
        'question' => 'Saya sering merasa tidak sesuai dengan peran gender saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'masculinity_femininity'
    ),
    array(
        'question' => 'Saya merasa nyaman dengan identitas gender saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'masculinity_femininity'
    ),
    array(
        'question' => 'Saya merasa bahwa saya memiliki karakteristik yang biasanya dikaitkan dengan lawan jenis saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'masculinity_femininity'
    ),
    array(
        'question' => 'Saya sering merasa bahwa saya harus berperilaku sesuai dengan stereotip gender saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'masculinity_femininity'
    ),
    array(
        'question' => 'Saya merasa bahwa peran gender saya membatasi kemampuan saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'masculinity_femininity'
    ),
    array(
        'question' => 'Saya merasa nyaman berbicara tentang topik yang biasanya dikaitkan dengan lawan jenis saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'masculinity_femininity'
    ),
    array(
        'question' => 'Saya merasa bahwa saya memiliki keseimbangan antara karakteristik maskulin dan feminin.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'masculinity_femininity'
    ),
    array(
        'question' => 'Saya merasa bahwa saya bisa mengekspresikan diri saya tanpa memperhatikan peran gender.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'masculinity_femininity'
    ),
    array(
        'question' => 'Saya merasa bahwa saya tidak harus mengikuti norma gender tradisional.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'masculinity_femininity'
    ),
    
    // Paranoia (Pa)
    array(
        'question' => 'Saya sering merasa bahwa orang lain berbicara tentang saya di belakang saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'paranoia'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sedang diawasi.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'paranoia'
    ),
    array(
        'question' => 'Saya merasa bahwa orang lain berusaha memanipulasi saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'paranoia'
    ),
    array(
        'question' => 'Saya sering merasa curiga terhadap motif orang lain.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'paranoia'
    ),
    array(
        'question' => 'Saya merasa bahwa orang lain berusaha untuk merugikan saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'paranoia'
    ),
    array(
        'question' => 'Saya sering merasa bahwa saya menjadi korban persekongkolan.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'paranoia'
    ),
    array(
        'question' => 'Saya merasa bahwa saya harus selalu waspada terhadap niat orang lain.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'paranoia'
    ),
    array(
        'question' => 'Saya sering merasa bahwa orang lain tidak jujur terhadap saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'paranoia'
    ),
    array(
        'question' => 'Saya merasa bahwa orang lain berusaha untuk menghancurkan reputasi saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'paranoia'
    ),
    array(
        'question' => 'Saya merasa bahwa orang lain berusaha untuk mencuri ide atau karya saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'paranoia'
    ),
    
    // Psychasthenia (Pt)
    array(
        'question' => 'Saya sering merasa cemas atau khawatir berlebihan.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychasthenia'
    ),
    array(
        'question' => 'Saya sering merasa tidak bisa mengendalikan pikiran saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychasthenia'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering merasa cemas tanpa alasan yang jelas.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychasthenia'
    ),
    array(
        'question' => 'Saya sering merasa tegang atau gelisah.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychasthenia'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering berpikir tentang hal-hal yang membuat saya cemas.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychasthenia'
    ),
    array(
        'question' => 'Saya sering merasa khawatir tentang masa depan saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychasthenia'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering merasa cemas ketika saya sendirian.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychasthenia'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering merasa cemas ketika saya berada di keramaian.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychasthenia'
    ),
    array(
        'question' => 'Saya sering merasa bahwa saya tidak bisa berhenti memikirkan sesuatu yang membuat saya cemas.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychasthenia'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering merasa cemas ketika saya berada di tempat baru.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'psychasthenia'
    ),
    
    // Schizophrenia (Sc)
    array(
        'question' => 'Saya sering merasa bingung atau tidak tahu apa yang harus dilakukan.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'schizophrenia'
    ),
    array(
        'question' => 'Saya sering merasa bahwa saya memiliki kemampuan khusus yang orang lain tidak miliki.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'schizophrenia'
    ),
    array(
        'question' => 'Saya sering merasa bahwa saya dapat mendengar suara-suara yang orang lain tidak dapat dengar.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'schizophrenia'
    ),
    array(
        'question' => 'Saya sering merasa bahwa saya dapat melihat hal-hal yang orang lain tidak dapat lihat.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'schizophrenia'
    ),
    array(
        'question' => 'Saya sering merasa bahwa orang lain berusaha mengendalikan pikiran saya.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'schizophrenia'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering merasa bingung atau tidak fokus.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'schizophrenia'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering merasa bingung atau tidak tahu apa yang harus dilakukan ketika saya sendirian.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'schizophrenia'
    ),
    array(
        'question' => 'Saya sering merasa bahwa saya memiliki kemampuan untuk meramalkan masa depan.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'schizophrenia'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering merasa bingung atau tidak tahu apa yang harus dilakukan ketika saya berada di tempat baru.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'schizophrenia'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering merasa bingung atau tidak tahu apa yang harus dilakukan ketika saya berada di keramaian.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'schizophrenia'
    ),
    
    // Hypomania (Ma)
    array(
        'question' => 'Saya sering merasa sangat berenergi dan tidak bisa diam.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypomania'
    ),
    array(
        'question' => 'Saya merasa bahwa saya dapat melakukan banyak hal sekaligus.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypomania'
    ),
    array(
        'question' => 'Saya sering merasa bahwa saya dapat menyelesaikan pekerjaan lebih cepat dari orang lain.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypomania'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering berbicara lebih cepat dari orang lain.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypomania'
    ),
    array(
        'question' => 'Saya sering merasa bahwa saya dapat berpikir lebih cepat dari orang lain.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypomania'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering merasa berenergi sepanjang hari.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypomania'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering merasa berenergi ketika orang lain merasa lelah.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypomania'
    ),
    array(
        'question' => 'Saya sering merasa bahwa saya dapat mengerjakan banyak hal dalam waktu singkat.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypomania'
    ),
    array(
        'question' => 'Saya sering merasa bahwa saya tidak perlu banyak tidur.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypomania'
    ),
    array(
        'question' => 'Saya merasa bahwa saya sering merasa berenergi bahkan setelah bekerja keras.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'hypomania'
    ),
    
    // Social Introversion (Si)
    array(
        'question' => 'Saya merasa nyaman berada di sekitar banyak orang.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'social_introversion'
    ),
    array(
        'question' => 'Saya sering merasa kesepian.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'social_introversion'
    ),
    array(
        'question' => 'Saya merasa lebih nyaman menghabiskan waktu sendirian daripada bersama orang lain.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'social_introversion'
    ),
    array(
        'question' => 'Saya merasa canggung dalam situasi sosial.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'social_introversion'
    ),
    array(
        'question' => 'Saya merasa sulit untuk memulai percakapan dengan orang lain.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'social_introversion'
    ),
    array(
        'question' => 'Saya merasa tidak nyaman berada di keramaian.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'social_introversion'
    ),
    array(
        'question' => 'Saya lebih suka bekerja sendiri daripada dalam kelompok.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'social_introversion'
    ),
    array(
        'question' => 'Saya merasa lebih nyaman dengan beberapa teman dekat daripada banyak kenalan.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'social_introversion'
    ),
    array(
        'question' => 'Saya sering merasa gugup dalam situasi sosial.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'social_introversion'
    ),
    array(
        'question' => 'Saya merasa lebih nyaman menghabiskan waktu di rumah daripada keluar.',
        'options' => array(
            'T' => 'Benar',
            'F' => 'Salah'
        ),
        'scale' => 'social_introversion'
    ),
);
?>
