<?php
$questions = array(
    // Subtest: Pemahaman Verbal
    array(
        'question' => 'Apa arti kata "abstrak"?',
        'options' => array(
            'A' => 'Tidak nyata dan sulit dipahami',
            'B' => 'Nyata dan dapat dirasakan',
            'C' => 'Sesuatu yang sederhana',
            'D' => 'Sesuatu yang dapat diukur',
        ),
    ),
    array(
        'question' => 'Sebutkan sinonim untuk kata "bahagia".',
        'options' => array(
            'A' => 'Sedih',
            'B' => 'Gembira',
            'C' => 'Takut',
            'D' => 'Marah',
        ),
    ),
    array(
        'question' => 'Apa antonim dari kata "besar"?',
        'options' => array(
            'A' => 'Kecil',
            'B' => 'Tinggi',
            'C' => 'Panjang',
            'D' => 'Luas',
        ),
    ),
    array(
        'question' => 'Apa arti kata "inovatif"?',
        'options' => array(
            'A' => 'Kreatif dan penuh ide baru',
            'B' => 'Berulang dan monoton',
            'C' => 'Kuno dan usang',
            'D' => 'Cepat dan tangkas',
        ),
    ),
    array(
        'question' => 'Sebutkan sinonim untuk kata "berani".',
        'options' => array(
            'A' => 'Pengecut',
            'B' => 'Takut',
            'C' => 'Nekat',
            'D' => 'Gagah',
        ),
    ),
    array(
        'question' => 'Apa arti kata "proaktif"?',
        'options' => array(
            'A' => 'Tidak responsif',
            'B' => 'Menunggu instruksi',
            'C' => 'Inisiatif tinggi',
            'D' => 'Pasif',
        ),
    ),
    array(
        'question' => 'Apa antonim dari kata "malas"?',
        'options' => array(
            'A' => 'Rajin',
            'B' => 'Lambat',
            'C' => 'Cermat',
            'D' => 'Teliti',
        ),
    ),
    array(
        'question' => 'Apa arti kata "kompleks"?',
        'options' => array(
            'A' => 'Sederhana',
            'B' => 'Rumit',
            'C' => 'Jelas',
            'D' => 'Mudah',
        ),
    ),
    array(
        'question' => 'Apa sinonim dari kata "segera"?',
        'options' => array(
            'A' => 'Nanti',
            'B' => 'Lambat',
            'C' => 'Cepat',
            'D' => 'Berjalan',
        ),
    ),
    array(
        'question' => 'Apa antonim dari kata "berat"?',
        'options' => array(
            'A' => 'Ringan',
            'B' => 'Berisik',
            'C' => 'Tenang',
            'D' => 'Keras',
        ),
    ),
    // Subtest: Kemampuan Aritmetika
    array(
        'question' => 'Berapakah hasil dari 15 + 27?',
        'options' => array(
            'A' => '32',
            'B' => '42',
            'C' => '52',
            'D' => '62',
        ),
    ),
    array(
        'question' => 'Jika Anda membeli 3 buku seharga Rp50.000 per buku, berapakah total biaya yang harus Anda bayar?',
        'options' => array(
            'A' => 'Rp100.000',
            'B' => 'Rp150.000',
            'C' => 'Rp200.000',
            'D' => 'Rp250.000',
        ),
    ),
    array(
        'question' => 'Berapakah hasil dari 100 - 45?',
        'options' => array(
            'A' => '55',
            'B' => '65',
            'C' => '75',
            'D' => '85',
        ),
    ),
    array(
        'question' => 'Jika harga sebuah baju adalah Rp75.000 dan Anda membeli 2 baju, berapa total yang harus dibayar?',
        'options' => array(
            'A' => 'Rp100.000',
            'B' => 'Rp125.000',
            'C' => 'Rp150.000',
            'D' => 'Rp175.000',
        ),
    ),
    array(
        'question' => 'Berapakah hasil dari 12 × 6?',
        'options' => array(
            'A' => '64',
            'B' => '72',
            'C' => '84',
            'D' => '96',
        ),
    ),
    array(
        'question' => 'Jika Anda memiliki 120 kelereng dan membagikannya kepada 4 teman secara merata, berapa banyak kelereng yang diterima setiap teman?',
        'options' => array(
            'A' => '20',
            'B' => '30',
            'C' => '40',
            'D' => '50',
        ),
    ),
    array(
        'question' => 'Berapakah hasil dari 144 ÷ 12?',
        'options' => array(
            'A' => '10',
            'B' => '12',
            'C' => '14',
            'D' => '16',
        ),
    ),
    array(
        'question' => 'Jika Anda memiliki Rp500.000 dan membeli sepatu seharga Rp250.000, berapa sisa uang Anda?',
        'options' => array(
            'A' => 'Rp200.000',
            'B' => 'Rp250.000',
            'C' => 'Rp300.000',
            'D' => 'Rp350.000',
        ),
    ),
    array(
        'question' => 'Berapakah hasil dari 9²?',
        'options' => array(
            'A' => '81',
            'B' => '72',
            'C' => '63',
            'D' => '54',
        ),
    ),
    array(
        'question' => 'Jika sebuah mobil menempuh jarak 90 km dalam 2 jam, berapakah kecepatan rata-rata mobil tersebut?',
        'options' => array(
            'A' => '30 km/jam',
            'B' => '40 km/jam',
            'C' => '45 km/jam',
            'D' => '50 km/jam',
        ),
    ),
    // Subtest: Pemahaman Ruang Visual
    array(
        'question' => 'Dalam bentuk mana segitiga ini bisa cocok?',
        'options' => array(
            'A' => 'Lingkaran',
            'B' => 'Segitiga',
            'C' => 'Persegi',
            'D' => 'Persegi Panjang',
        ),
    ),
    array(
        'question' => 'Berapakah jumlah sisi pada kubus?',
        'options' => array(
            'A' => '4',
            'B' => '6',
            'C' => '8',
            'D' => '12',
        ),
    ),
    array(
        'question' => 'Manakah dari bentuk berikut yang merupakan piramida?',
        'options' => array(
            'A' => 'Lingkaran',
            'B' => 'Segitiga',
            'C' => 'Bola',
            'D' => 'Bujur Sangkar',
        ),
    ),
    array(
        'question' => 'Bentuk mana yang memiliki 4 sisi yang sama panjang?',
        'options' => array(
            'A' => 'Segitiga',
            'B' => 'Persegi',
            'C' => 'Lingkaran',
            'D' => 'Elips',
        ),
    ),
    array(
        'question' => 'Berapa jumlah sudut pada segilima?',
        'options' => array(
            'A' => '3',
            'B' => '4',
            'C' => '5',
            'D' => '6',
        ),
    ),
    array(
        'question' => 'Manakah dari bentuk berikut yang merupakan silinder?',
        'options' => array(
            'A' => 'Kerucut',
            'B' => 'Bola',
            'C' => 'Tabung',
            'D' => 'Piramida',
        ),
    ),
    array(
        'question' => 'Berapakah jumlah rusuk pada balok?',
        'options' => array(
            'A' => '8',
            'B' => '10',
            'C' => '12',
            'D' => '14',
        ),
    ),
    array(
        'question' => 'Bentuk mana yang memiliki diameter?',
        'options' => array(
            'A' => 'Segitiga',
            'B' => 'Lingkaran',
            'C' => 'Persegi',
            'D' => 'Elips',
        ),
    ),
    array(
        'question' => 'Manakah dari bentuk berikut yang merupakan prisma segitiga?',
        'options' => array(
            'A' => 'Bola',
            'B' => 'Kubus',
            'C' => 'Silinder',
            'D' => 'Prisma',
        ),
    ),
    array(
        'question' => 'Bentuk mana yang memiliki volume?',
        'options' => array(
            'A' => 'Persegi',
            'B' => 'Segitiga',
            'C' => 'Lingkaran',
            'D' => 'Kubus',
        ),
    ),
    // Subtest: Memori Kerja
    array(
        'question' => 'Ingatlah urutan angka ini: 3, 8, 1, 9. Ketika Anda ditanya, ulangi angka-angka ini dalam urutan terbalik.',
        'options' => array(
            'A' => '3, 8, 1, 9',
            'B' => '9, 1, 8, 3',
            'C' => '1, 9, 3, 8',
            'D' => '8, 3, 9, 1',
        ),
    ),
    array(
        'question' => 'Urutan huruf berikut: F, L, T, G. Ulangi dalam urutan terbalik.',
        'options' => array(
            'A' => 'F, L, T, G',
            'B' => 'G, T, L, F',
            'C' => 'L, F, T, G',
            'D' => 'T, G, L, F',
        ),
    ),
    array(
        'question' => 'Ingatlah urutan angka ini: 4, 2, 6, 7. Ketika Anda ditanya, ulangi angka-angka ini dalam urutan terbalik.',
        'options' => array(
            'A' => '4, 2, 6, 7',
            'B' => '7, 6, 2, 4',
            'C' => '6, 7, 4, 2',
            'D' => '2, 4, 7, 6',
        ),
    ),
    array(
        'question' => 'Urutan huruf berikut: P, Q, R, S. Ulangi dalam urutan terbalik.',
        'options' => array(
            'A' => 'P, Q, R, S',
            'B' => 'S, R, Q, P',
            'C' => 'Q, P, S, R',
            'D' => 'R, S, P, Q',
        ),
    ),
    array(
        'question' => 'Ingatlah urutan angka ini: 5, 9, 3, 4. Ketika Anda ditanya, ulangi angka-angka ini dalam urutan terbalik.',
        'options' => array(
            'A' => '5, 9, 3, 4',
            'B' => '4, 3, 9, 5',
            'C' => '3, 4, 5, 9',
            'D' => '9, 5, 4, 3',
        ),
    ),
    array(
        'question' => 'Urutan huruf berikut: D, E, F, G. Ulangi dalam urutan terbalik.',
        'options' => array(
            'A' => 'D, E, F, G',
            'B' => 'G, F, E, D',
            'C' => 'E, D, G, F',
            'D' => 'F, G, D, E',
        ),
    ),
    array(
        'question' => 'Ingatlah urutan angka ini: 7, 1, 5, 8. Ketika Anda ditanya, ulangi angka-angka ini dalam urutan terbalik.',
        'options' => array(
            'A' => '7, 1, 5, 8',
            'B' => '8, 5, 1, 7',
            'C' => '5, 8, 7, 1',
            'D' => '1, 7, 8, 5',
        ),
    ),
    array(
        'question' => 'Urutan huruf berikut: H, I, J, K. Ulangi dalam urutan terbalik.',
        'options' => array(
            'A' => 'H, I, J, K',
            'B' => 'K, J, I, H',
            'C' => 'I, H, K, J',
            'D' => 'J, K, H, I',
        ),
    ),
    array(
        'question' => 'Ingatlah urutan angka ini: 2, 6, 8, 3. Ketika Anda ditanya, ulangi angka-angka ini dalam urutan terbalik.',
        'options' => array(
            'A' => '2, 6, 8, 3',
            'B' => '3, 8, 6, 2',
            'C' => '8, 2, 3, 6',
            'D' => '6, 3, 2, 8',
        ),
    ),
    array(
        'question' => 'Urutan huruf berikut: L, M, N, O. Ulangi dalam urutan terbalik.',
        'options' => array(
            'A' => 'L, M, N, O',
            'B' => 'O, N, M, L',
            'C' => 'M, L, O, N',
            'D' => 'N, O, L, M',
        ),
    ),
    // Subtest: Kecepatan Pemrosesan
    array(
        'question' => 'Temukan pola yang benar dari urutan berikut: 2, 4, 6, 8, ...',
        'options' => array(
            'A' => '9',
            'B' => '10',
            'C' => '11',
            'D' => '12',
        ),
    ),
    array(
        'question' => 'Berapa banyak huruf "a" dalam kata "abrakadabra"?',
        'options' => array(
            'A' => '2',
            'B' => '3',
            'C' => '4',
            'D' => '5',
        ),
    ),
    array(
        'question' => 'Temukan pola yang benar dari urutan berikut: 5, 10, 15, 20, ...',
        'options' => array(
            'A' => '25',
            'B' => '30',
            'C' => '35',
            'D' => '40',
        ),
    ),
    array(
        'question' => 'Berapa banyak huruf "e" dalam kata "elektronik"?',
        'options' => array(
            'A' => '1',
            'B' => '2',
            'C' => '3',
            'D' => '4',
        ),
    ),
    array(
        'question' => 'Temukan pola yang benar dari urutan berikut: 3, 6, 9, 12, ...',
        'options' => array(
            'A' => '13',
            'B' => '14',
            'C' => '15',
            'D' => '16',
        ),
    ),
    array(
        'question' => 'Berapa banyak huruf "i" dalam kata "industri"?',
        'options' => array(
            'A' => '1',
            'B' => '2',
            'C' => '3',
            'D' => '4',
        ),
    ),
    array(
        'question' => 'Temukan pola yang benar dari urutan berikut: 4, 8, 12, 16, ...',
        'options' => array(
            'A' => '20',
            'B' => '22',
            'C' => '24',
            'D' => '26',
        ),
    ),
    array(
        'question' => 'Berapa banyak huruf "o" dalam kata "otomotif"?',
        'options' => array(
            'A' => '1',
            'B' => '2',
            'C' => '3',
            'D' => '4',
        ),
    ),
    array(
        'question' => 'Temukan pola yang benar dari urutan berikut: 7, 14, 21, 28, ...',
        'options' => array(
            'A' => '30',
            'B' => '35',
            'C' => '40',
            'D' => '45',
        ),
    ),
    array(
        'question' => 'Berapa banyak huruf "u" dalam kata "universitas"?',
        'options' => array(
            'A' => '1',
            'B' => '2',
            'C' => '3',
            'D' => '4',
        ),
    ),
);
