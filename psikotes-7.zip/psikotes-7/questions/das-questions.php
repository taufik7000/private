<?php
$questions = array(
    // Consensus
    array(
        'question' => 'Seberapa sering Anda dan pasangan Anda sepakat tentang cara mengatur keuangan rumah tangga?',
        'name' => 'consensus_1',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda dan pasangan Anda sepakat tentang bagaimana menghabiskan waktu luang?',
        'name' => 'consensus_2',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda dan pasangan Anda sepakat tentang cara mendidik anak?',
        'name' => 'consensus_3',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda dan pasangan Anda sepakat tentang pembagian tugas rumah tangga?',
        'name' => 'consensus_4',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda dan pasangan Anda sepakat tentang masalah keuangan besar?',
        'name' => 'consensus_5',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),

    // Satisfaction
    array(
        'question' => 'Seberapa puas Anda dengan hubungan Anda secara keseluruhan?',
        'name' => 'satisfaction_1',
        'options' => array(
            '0' => 'Sangat tidak puas',
            '1' => 'Tidak puas',
            '2' => 'Cukup puas',
            '3' => 'Puas',
            '4' => 'Sangat puas'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda mempertimbangkan untuk mengakhiri hubungan?',
        'name' => 'satisfaction_2',
        'options' => array(
            '0' => 'Sangat sering',
            '1' => 'Sering',
            '2' => 'Kadang-kadang',
            '3' => 'Jarang',
            '4' => 'Sangat jarang'
        )
    ),
    array(
        'question' => 'Seberapa puas Anda dengan cara Anda dan pasangan Anda menyelesaikan konflik?',
        'name' => 'satisfaction_3',
        'options' => array(
            '0' => 'Sangat tidak puas',
            '1' => 'Tidak puas',
            '2' => 'Cukup puas',
            '3' => 'Puas',
            '4' => 'Sangat puas'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda merasa bahagia dalam hubungan Anda?',
        'name' => 'satisfaction_4',
        'options' => array(
            '0' => 'Sangat jarang',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa puas Anda dengan stabilitas hubungan Anda?',
        'name' => 'satisfaction_5',
        'options' => array(
            '0' => 'Sangat tidak puas',
            '1' => 'Tidak puas',
            '2' => 'Cukup puas',
            '3' => 'Puas',
            '4' => 'Sangat puas'
        )
    ),

    // Cohesion
    array(
        'question' => 'Seberapa sering Anda dan pasangan Anda menghabiskan waktu bersama?',
        'name' => 'cohesion_1',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda merasa dekat secara emosional dengan pasangan Anda?',
        'name' => 'cohesion_2',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda dan pasangan Anda melakukan kegiatan bersama?',
        'name' => 'cohesion_3',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda dan pasangan Anda berbagi perasaan satu sama lain?',
        'name' => 'cohesion_4',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda merasa pasangan Anda memahami perasaan Anda?',
        'name' => 'cohesion_5',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),

    // Affectional Expression
    array(
        'question' => 'Seberapa sering Anda dan pasangan Anda menyatakan cinta satu sama lain?',
        'name' => 'affectional_expression_1',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda merasa bahwa pasangan Anda menunjukkan kasih sayang kepada Anda?',
        'name' => 'affectional_expression_2',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda dan pasangan Anda berpegangan tangan atau berpelukan?',
        'name' => 'affectional_expression_3',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda dan pasangan Anda berbagi ciuman?',
        'name' => 'affectional_expression_4',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda merasa pasangan Anda peduli dengan kesejahteraan Anda?',
        'name' => 'affectional_expression_5',
        'options' => array(
            '0' => 'Tidak pernah',
            '1' => 'Jarang',
            '2' => 'Kadang-kadang',
            '3' => 'Sering',
            '4' => 'Sangat sering'
        )
    )
);
?>
