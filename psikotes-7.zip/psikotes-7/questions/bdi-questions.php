<?php
$questions = array(
    array(
        'question' => 'Saya tidak merasa sedih.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa sedih.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya sedih sepanjang waktu dan tidak bisa menghilangkannya.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya sangat sedih atau tidak bahagia sehingga saya tidak tahan lagi.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa pesimis tentang masa depan.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa tidak berguna atau tidak berharga.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa gagal dalam hidup saya.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya kehilangan minat dalam aktivitas yang sebelumnya saya nikmati.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa kesepian.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa tidak bisa menikmati hidup.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa sangat lelah atau kehabisan energi.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa sulit untuk berkonsentrasi.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa kehilangan harapan.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa mudah marah atau tersinggung.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa sulit untuk memulai sesuatu.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa cemas atau gelisah.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa tidak berharga.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa lebih baik jika tidak hidup.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa orang lain akan lebih baik tanpa saya.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa hidup ini tidak layak dijalani.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
    array(
        'question' => 'Saya merasa sangat khawatir atau cemas.',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Sedikit',
            '2' => 'Sering',
            '3' => 'Sangat sering'
        ),
        'scale' => 'bdi'
    ),
);
?>
