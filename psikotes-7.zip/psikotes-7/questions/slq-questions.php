<?php
$questions = array(
    array(
        'question' => 'Tim Anda menghadapi tenggat waktu yang ketat dan memerlukan arahan yang jelas.',
        'options' => array(
            'directing' => 'Memberikan instruksi yang spesifik dan mengawasi pelaksanaannya.',
            'coaching' => 'Memberikan instruksi dan motivasi untuk menyelesaikan tugas.',
            'supporting' => 'Mendiskusikan tugas bersama tim dan memberikan dukungan emosional.',
            'delegating' => 'Memberikan tanggung jawab kepada tim untuk menyelesaikan tugas dengan sedikit pengawasan.'
        ),
    ),
    array(
        'question' => 'Seorang anggota tim baru membutuhkan bantuan untuk memahami tugasnya.',
        'options' => array(
            'directing' => 'Memberikan instruksi yang jelas dan memastikan anggota tim mengikuti arahan.',
            'coaching' => 'Memberikan instruksi serta dukungan untuk membantu anggota tim memahami tugasnya.',
            'supporting' => 'Mendiskusikan tugas bersama anggota tim dan memberikan dukungan.',
            'delegating' => 'Membiarkan anggota tim menyelesaikan tugasnya sendiri dengan sedikit pengawasan.'
        ),
    ),
    array(
        'question' => 'Tim Anda mengalami konflik internal yang mempengaruhi produktivitas.',
        'options' => array(
            'directing' => 'Memberikan arahan yang tegas untuk menyelesaikan konflik.',
            'coaching' => 'Mendiskusikan konflik dengan tim dan memberikan solusi serta dukungan.',
            'supporting' => 'Mendengarkan keluhan tim dan memberikan dukungan emosional.',
            'delegating' => 'Membiarkan tim menyelesaikan konflik sendiri dengan sedikit campur tangan.'
        ),
    ),
    array(
        'question' => 'Seorang anggota tim menunjukkan inisiatif yang baik dalam proyek baru.',
        'options' => array(
            'directing' => 'Memberikan instruksi spesifik tentang langkah selanjutnya.',
            'coaching' => 'Memberikan instruksi dan dorongan untuk melanjutkan inisiatif.',
            'supporting' => 'Memberikan pujian dan dukungan emosional untuk inisiatif tersebut.',
            'delegating' => 'Memberikan tanggung jawab penuh kepada anggota tim untuk melanjutkan proyek.'
        ),
    ),
    array(
        'question' => 'Proyek tim Anda mengalami keterlambatan karena kurangnya koordinasi.',
        'options' => array(
            'directing' => 'Memberikan instruksi yang jelas dan memastikan koordinasi yang tepat.',
            'coaching' => 'Mendiskusikan masalah koordinasi dengan tim dan memberikan solusi.',
            'supporting' => 'Mendengarkan masalah tim dan memberikan dukungan emosional.',
            'delegating' => 'Membiarkan tim mencari solusi sendiri dengan sedikit pengawasan.'
        ),
    ),
    array(
        'question' => 'Seorang anggota tim Anda merasa terbebani oleh tugas yang diberikan.',
        'options' => array(
            'directing' => 'Memberikan instruksi yang lebih jelas dan memantau kemajuan tugas.',
            'coaching' => 'Memberikan dukungan dan motivasi untuk membantu menyelesaikan tugas.',
            'supporting' => 'Mendengarkan kekhawatiran anggota tim dan memberikan dukungan emosional.',
            'delegating' => 'Membiarkan anggota tim mengatur tugasnya sendiri dengan sedikit pengawasan.'
        ),
    ),
    array(
        'question' => 'Tim Anda sedang mengerjakan proyek yang sangat kompleks.',
        'options' => array(
            'directing' => 'Memberikan instruksi yang rinci dan mengawasi setiap langkah.',
            'coaching' => 'Memberikan panduan dan dukungan untuk mengatasi kompleksitas proyek.',
            'supporting' => 'Mendengarkan masalah tim dan memberikan dukungan emosional.',
            'delegating' => 'Memberikan kepercayaan kepada tim untuk menyelesaikan proyek dengan sedikit pengawasan.'
        ),
    ),
    array(
        'question' => 'Anggota tim Anda memiliki ide baru yang inovatif.',
        'options' => array(
            'directing' => 'Memberikan instruksi spesifik tentang bagaimana mengimplementasikan ide.',
            'coaching' => 'Memberikan dukungan dan saran untuk mengembangkan ide lebih lanjut.',
            'supporting' => 'Memberikan pujian dan dukungan emosional untuk ide tersebut.',
            'delegating' => 'Memberikan tanggung jawab penuh kepada anggota tim untuk mengimplementasikan ide.'
        ),
    ),
    array(
        'question' => 'Tim Anda perlu meningkatkan efisiensi kerja.',
        'options' => array(
            'directing' => 'Memberikan instruksi yang jelas dan menetapkan target efisiensi.',
            'coaching' => 'Memberikan panduan dan dukungan untuk meningkatkan efisiensi.',
            'supporting' => 'Mendengarkan masalah tim dan memberikan dukungan emosional.',
            'delegating' => 'Membiarkan tim mencari cara untuk meningkatkan efisiensi sendiri dengan sedikit pengawasan.'
        ),
    ),
    array(
        'question' => 'Seorang anggota tim Anda menunjukkan kinerja yang buruk.',
        'options' => array(
            'directing' => 'Memberikan instruksi yang lebih jelas dan mengawasi kinerja dengan ketat.',
            'coaching' => 'Memberikan dukungan dan motivasi untuk meningkatkan kinerja.',
            'supporting' => 'Mendengarkan masalah anggota tim dan memberikan dukungan emosional.',
            'delegating' => 'Memberikan kepercayaan kepada anggota tim untuk memperbaiki kinerjanya sendiri dengan sedikit pengawasan.'
        ),
    ),
    array(
        'question' => 'Tim Anda sedang menghadapi perubahan besar dalam organisasi.',
        'options' => array(
            'directing' => 'Memberikan instruksi yang jelas tentang bagaimana menghadapi perubahan.',
            'coaching' => 'Memberikan dukungan dan saran untuk membantu tim beradaptasi.',
            'supporting' => 'Mendengarkan kekhawatiran tim dan memberikan dukungan emosional.',
            'delegating' => 'Membiarkan tim menemukan cara sendiri untuk beradaptasi dengan perubahan.'
        ),
    ),
    array(
        'question' => 'Seorang anggota tim membutuhkan pengembangan keterampilan untuk proyek baru.',
        'options' => array(
            'directing' => 'Memberikan instruksi yang rinci tentang keterampilan yang dibutuhkan.',
            'coaching' => 'Memberikan dukungan dan sumber daya untuk pengembangan keterampilan.',
            'supporting' => 'Mendiskusikan rencana pengembangan keterampilan bersama anggota tim.',
            'delegating' => 'Membiarkan anggota tim mengembangkan keterampilannya sendiri dengan sedikit pengawasan.'
        ),
    ),
    array(
        'question' => 'Tim Anda bekerja pada proyek dengan kolaborasi lintas departemen.',
        'options' => array(
            'directing' => 'Memberikan instruksi yang jelas tentang kolaborasi lintas departemen.',
            'coaching' => 'Memberikan dukungan dan saran untuk memastikan kolaborasi yang efektif.',
            'supporting' => 'Mendengarkan masalah kolaborasi dan memberikan dukungan emosional.',
            'delegating' => 'Membiarkan tim mengelola kolaborasi lintas departemen dengan sedikit pengawasan.'
        ),
    ),
    array(
        'question' => 'Seorang anggota tim mengusulkan metode baru untuk meningkatkan produktivitas.',
        'options' => array(
            'directing' => 'Memberikan instruksi tentang bagaimana mengimplementasikan metode baru.',
            'coaching' => 'Memberikan dukungan dan saran untuk pengembangan metode baru.',
            'supporting' => 'Memberikan pujian dan dukungan emosional untuk usulan tersebut.',
            'delegating' => 'Memberikan tanggung jawab penuh kepada anggota tim untuk mengimplementasikan metode baru.'
        ),
    ),
    array(
        'question' => 'Tim Anda menghadapi situasi darurat yang memerlukan tindakan cepat.',
        'options' => array(
            'directing' => 'Memberikan instruksi yang tegas dan mengawasi tindakan yang diambil.',
            'coaching' => 'Memberikan dukungan dan motivasi untuk menghadapi situasi darurat.',
            'supporting' => 'Mendengarkan kekhawatiran tim dan memberikan dukungan emosional.',
            'delegating' => 'Membiarkan tim mengambil keputusan sendiri dengan sedikit pengawasan.'
        ),
    ),
);
?>
