<?php
$questions = array(
    // Verbal (10 pertanyaan)
    array(
        'question' => 'Apa yang Anda lakukan ketika mendapati seseorang kesulitan membaca?',
        'options' => array(
            'A' => 'Saya akan menawarkan bantuan untuk mengajarinya membaca.', // Verbal
            'B' => 'Saya akan memberinya buku yang mudah dibaca.', // Verbal
            'C' => 'Saya akan mengajaknya belajar bersama.', // Verbal
            'D' => 'Saya akan memintanya mencari bantuan profesional.' // Verbal
        )
    ),
    array(
        'question' => 'Apa kebalikan dari kata "besar"?',
        'options' => array(
            'A' => 'Tinggi',
            'B' => 'Kecil', // Verbal
            'C' => 'Lebar',
            'D' => 'Panjang'
        )
    ),
    array(
        'question' => 'Sebutkan sinonim dari kata "cepat":',
        'options' => array(
            'A' => 'Lambat',
            'B' => 'Pelan',
            'C' => 'Laju', // Verbal
            'D' => 'Kilatan'
        )
    ),
    array(
        'question' => 'Apa arti dari kata "antusias"?',
        'options' => array(
            'A' => 'Semangat', // Verbal
            'B' => 'Lambat',
            'C' => 'Malas',
            'D' => 'Ragu-ragu'
        )
    ),
    array(
        'question' => 'Mana yang merupakan kata benda?',
        'options' => array(
            'A' => 'Berjalan',
            'B' => 'Cepat',
            'C' => 'Pohon', // Verbal
            'D' => 'Biru'
        )
    ),
    array(
        'question' => 'Apa yang Anda lakukan jika melihat seseorang yang kesepian?',
        'options' => array(
            'A' => 'Mengajaknya berbicara', // Verbal
            'B' => 'Mengabaikannya',
            'C' => 'Menjauh darinya',
            'D' => 'Menceritakannya kepada orang lain'
        )
    ),
    array(
        'question' => 'Bagaimana Anda menggambarkan seseorang yang berpengetahuan luas?',
        'options' => array(
            'A' => 'Pintar', // Verbal
            'B' => 'Sopan',
            'C' => 'Lucu',
            'D' => 'Jujur'
        )
    ),
    array(
        'question' => 'Apa yang dimaksud dengan "komunikasi"?',
        'options' => array(
            'A' => 'Proses menyampaikan informasi', // Verbal
            'B' => 'Proses berpikir',
            'C' => 'Proses tidur',
            'D' => 'Proses makan'
        )
    ),
    array(
        'question' => 'Sebutkan antonim dari kata "naik":',
        'options' => array(
            'A' => 'Turun', // Verbal
            'B' => 'Cepat',
            'C' => 'Lambat',
            'D' => 'Lurus'
        )
    ),
    array(
        'question' => 'Apa yang Anda lakukan jika seseorang tidak mengerti apa yang Anda bicarakan?',
        'options' => array(
            'A' => 'Menjelaskannya dengan lebih sederhana', // Verbal
            'B' => 'Marah padanya',
            'C' => 'Mengabaikannya',
            'D' => 'Berbicara lebih cepat'
        )
    ),
    // Logika-Matematika (10 pertanyaan)
    array(
        'question' => 'Jika Anda memiliki dua apel dan membagi satu apel menjadi dua, berapa banyak apel yang Anda miliki sekarang?',
        'options' => array(
            'A' => 'Tiga apel',
            'B' => 'Satu apel',
            'C' => 'Dua setengah apel',
            'D' => 'Dua apel' // Logika-Matematika
        )
    ),
    array(
        'question' => 'Apa hasil dari 9 + 6 ÷ 3?',
        'options' => array(
            'A' => '5',
            'B' => '11', // Logika-Matematika
            'C' => '13',
            'D' => '15'
        )
    ),
    array(
        'question' => 'Apa hasil dari 12 ÷ 4 + 2?',
        'options' => array(
            'A' => '3',
            'B' => '5', // Logika-Matematika
            'C' => '8',
            'D' => '10'
        )
    ),
    array(
        'question' => 'Jika Anda memiliki 15 buah jeruk dan Anda memberikan 5 buah kepada teman Anda, berapa buah jeruk yang Anda miliki sekarang?',
        'options' => array(
            'A' => '10 buah', // Logika-Matematika
            'B' => '5 buah',
            'C' => '15 buah',
            'D' => '0 buah'
        )
    ),
    array(
        'question' => 'Apa hasil dari 5 × 3 - 4?',
        'options' => array(
            'A' => '11', // Logika-Matematika
            'B' => '15',
            'C' => '10',
            'D' => '5'
        )
    ),
    array(
        'question' => 'Jika Anda pergi ke toko dan membeli 2 apel seharga Rp3.000 masing-masing dan 1 pisang seharga Rp1.500, berapa total biaya yang Anda keluarkan?',
        'options' => array(
            'A' => 'Rp6.000',
            'B' => 'Rp7.500', // Logika-Matematika
            'C' => 'Rp9.000',
            'D' => 'Rp4.500'
        )
    ),
    array(
        'question' => 'Apa hasil dari 20 ÷ 5 + 3?',
        'options' => array(
            'A' => '7', // Logika-Matematika
            'B' => '4',
            'C' => '8',
            'D' => '9'
        )
    ),
    array(
        'question' => 'Jika sebuah kendaraan melaju dengan kecepatan 60 km/jam selama 2 jam, berapa jarak yang ditempuh?',
        'options' => array(
            'A' => '60 km',
            'B' => '120 km', // Logika-Matematika
            'C' => '100 km',
            'D' => '80 km'
        )
    ),
    array(
        'question' => 'Jika Anda pergi ke sekolah pada pukul 7:00 pagi dan pulang pada pukul 3:00 sore, berapa jam Anda berada di sekolah?',
        'options' => array(
            'A' => '6 jam',
            'B' => '7 jam',
            'C' => '8 jam', // Logika-Matematika
            'D' => '9 jam'
        )
    ),
    array(
        'question' => 'Apa hasil dari 3 × 7 - 5?',
        'options' => array(
            'A' => '16',
            'B' => '21',
            'C' => '20', // Logika-Matematika
            'D' => '15'
        )
    ),
    // Spasial (10 pertanyaan)
    array(
        'question' => 'Mana yang merupakan bentuk segitiga?',
        'options' => array(
            'A' => 'Bentuk dengan tiga sisi', // Spasial
            'B' => 'Bentuk dengan empat sisi',
            'C' => 'Bentuk dengan lima sisi',
            'D' => 'Bentuk dengan enam sisi'
        )
    ),
    array(
        'question' => 'Jika semua burung adalah hewan dan semua merpati adalah burung, maka:',
        'options' => array(
            'A' => 'Semua hewan adalah burung',
            'B' => 'Semua burung adalah merpati',
            'C' => 'Semua merpati adalah hewan', // Spasial
            'D' => 'Semua hewan adalah merpati'
        )
    ),
    array(
        'question' => 'Selesaikan pola angka berikut: 2, 4, 6, 8, ...',
        'options' => array(
            'A' => '10', // Spasial
            'B' => '12',
            'C' => '14',
            'D' => '16'
        )
    ),
    array(
        'question' => 'Mana yang merupakan buah?',
        'options' => array(
            'A' => 'Kentang',
            'B' => 'Apel', // Spasial
            'C' => 'Bayam',
            'D' => 'Brokoli'
        )
    ),
    array(
        'question' => 'Mana yang merupakan hewan mamalia?',
        'options' => array(
            'A' => 'Ikan',
            'B' => 'Kadal',
            'C' => 'Kanguru', // Spasial
            'D' => 'Ular'
        )
    ),
    array(
        'question' => 'Selesaikan pernyataan ini: Matahari terbit di sebelah ... dan terbenam di sebelah ...',
        'options' => array(
            'A' => 'Utara, Selatan',
            'B' => 'Timur, Barat', // Spasial
            'C' => 'Barat, Timur',
            'D' => 'Selatan, Utara'
        )
    ),
    array(
        'question' => 'Mana yang merupakan kegiatan olahraga?',
        'options' => array(
            'A' => 'Berenang', // Spasial
            'B' => 'Membaca',
            'C' => 'Menonton TV',
            'D' => 'Tidur'
        )
    ),
    array(
        'question' => 'Selesaikan pola berikut: Kotak, Lingkaran, Kotak, Lingkaran, ...',
        'options' => array(
            'A' => 'Kotak', // Spasial
            'B' => 'Segitiga',
            'C' => 'Lingkaran',
            'D' => 'Persegi panjang'
        )
    ),
    array(
        'question' => 'Jika Anda melihat peta, mana yang biasanya menunjukkan arah utara?',
        'options' => array(
            'A' => 'Bawah',
            'B' => 'Atas', // Spasial
            'C' => 'Kiri',
            'D' => 'Kanan'
        )
    ),
    array(
        'question' => 'Mana yang paling tidak sesuai dengan yang lain?',
        'options' => array(
            'A' => 'Buku', // Spasial
            'B' => 'Pensil',
            'C' => 'Pulpen',
            'D' => 'Penghapus'
        )
    ),
    // Penalaran (10 pertanyaan)
    array(
        'question' => 'Mana yang paling tidak terkait dengan yang lain?',
        'options' => array(
            'A' => 'Anjing',
            'B' => 'Kucing',
            'C' => 'Ikan', // Penalaran
            'D' => 'Burung'
        )
    ),
    array(
        'question' => 'Jika hari ini adalah hari Senin, hari apa 3 hari setelah besok?',
        'options' => array(
            'A' => 'Selasa',
            'B' => 'Rabu',
            'C' => 'Kamis', // Penalaran
            'D' => 'Jumat'
        )
    ),
    array(
        'question' => 'Apa hasil dari 3 × 7 - 5?',
        'options' => array(
            'A' => '16', // Penalaran
            'B' => '21',
            'C' => '20',
            'D' => '15'
        )
    ),
    array(
        'question' => 'Apa yang Anda lakukan jika mendapati seseorang jatuh dan terluka?',
        'options' => array(
            'A' => 'Berlari menjauh',
            'B' => 'Memberinya bantuan pertama', // Penalaran
            'C' => 'Menertawakannya',
            'D' => 'Mengabaikannya'
        )
    ),
    array(
        'question' => 'Jika Anda memiliki 10 kelereng dan Anda memberikan 3 kelereng kepada teman Anda, berapa banyak kelereng yang Anda miliki sekarang?',
        'options' => array(
            'A' => '7 kelereng', // Penalaran
            'B' => '3 kelereng',
            'C' => '10 kelereng',
            'D' => '0 kelereng'
        )
    ),
    array(
        'question' => 'Jika sebuah bus berangkat pukul 8:00 pagi dan tiba pada pukul 12:00 siang, berapa lama perjalanan tersebut?',
        'options' => array(
            'A' => '3 jam',
            'B' => '4 jam', // Penalaran
            'C' => '5 jam',
            'D' => '6 jam'
        )
    ),
    array(
        'question' => 'Mana yang merupakan aktivitas di luar ruangan?',
        'options' => array(
            'A' => 'Membaca buku',
            'B' => 'Bermain bola', // Penalaran
            'C' => 'Menonton TV',
            'D' => 'Tidur'
        )
    ),
    array(
        'question' => 'Jika Anda memotong kue menjadi 8 bagian dan memberi 3 bagian kepada teman, berapa bagian kue yang tersisa?',
        'options' => array(
            'A' => '5 bagian', // Penalaran
            'B' => '3 bagian',
            'C' => '8 bagian',
            'D' => '1 bagian'
        )
    ),
    array(
        'question' => 'Apa hasil dari 15 - 7 + 2?',
        'options' => array(
            'A' => '10', // Penalaran
            'B' => '8',
            'C' => '9',
            'D' => '6'
        )
    ),
    array(
        'question' => 'Jika Anda melihat seseorang kesulitan membawa barang berat, apa yang Anda lakukan?',
        'options' => array(
            'A' => 'Membantu membawakan barang tersebut', // Penalaran
            'B' => 'Mengabaikannya',
            'C' => 'Membuat lelucon tentangnya',
            'D' => 'Melaporkannya ke petugas keamanan'
        )
    ),
);
?>
