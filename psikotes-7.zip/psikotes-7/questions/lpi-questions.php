<?php
$questions = array(
    // Model the Way
    array(
        'question' => 'Saya menetapkan contoh melalui tindakan saya.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'model_the_way'
    ),
    array(
        'question' => 'Saya memastikan tujuan yang ditetapkan jelas.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'model_the_way'
    ),
    array(
        'question' => 'Saya mengikuti standar etika dan profesional yang tinggi.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'model_the_way'
    ),
    array(
        'question' => 'Saya memberikan arahan yang jelas.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'model_the_way'
    ),
    array(
        'question' => 'Saya mendemonstrasikan nilai-nilai yang saya harapkan dari orang lain.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'model_the_way'
    ),
    array(
        'question' => 'Saya menjaga integritas dan kejujuran dalam setiap tindakan.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'model_the_way'
    ),
    // Inspire a Shared Vision
    array(
        'question' => 'Saya menginspirasi orang lain dengan visi masa depan yang menarik.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'inspire_a_shared_vision'
    ),
    array(
        'question' => 'Saya memotivasi orang lain untuk berbagi visi yang sama.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'inspire_a_shared_vision'
    ),
    array(
        'question' => 'Saya membuat orang lain merasa antusias tentang masa depan.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'inspire_a_shared_vision'
    ),
    array(
        'question' => 'Saya berbagi pandangan tentang bagaimana masa depan bisa lebih baik.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'inspire_a_shared_vision'
    ),
    array(
        'question' => 'Saya membuat orang lain berkomitmen pada visi masa depan.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'inspire_a_shared_vision'
    ),
    array(
        'question' => 'Saya membuat visi masa depan menjadi hidup.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'inspire_a_shared_vision'
    ),
    // Challenge the Process
    array(
        'question' => 'Saya mencari peluang untuk inovasi dan perbaikan.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'challenge_the_process'
    ),
    array(
        'question' => 'Saya mengambil risiko yang diperhitungkan untuk mencapai tujuan.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'challenge_the_process'
    ),
    array(
        'question' => 'Saya belajar dari kesalahan dan kegagalan.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'challenge_the_process'
    ),
    array(
        'question' => 'Saya mencari cara baru untuk melakukan pekerjaan.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'challenge_the_process'
    ),
    array(
        'question' => 'Saya mempertanyakan status quo.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'challenge_the_process'
    ),
    array(
        'question' => 'Saya mendorong eksperimen dan mengambil risiko.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'challenge_the_process'
    ),
    // Enable Others to Act
    array(
        'question' => 'Saya memberdayakan orang lain untuk bertindak.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'enable_others_to_act'
    ),
    array(
        'question' => 'Saya mendorong kolaborasi dan kerja sama tim.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'enable_others_to_act'
    ),
    array(
        'question' => 'Saya memberikan dukungan dan sumber daya yang diperlukan.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'enable_others_to_act'
    ),
    array(
        'question' => 'Saya membangun rasa saling percaya dan rasa hormat.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'enable_others_to_act'
    ),
    array(
        'question' => 'Saya mengembangkan kompetensi orang lain.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'enable_others_to_act'
    ),
    array(
        'question' => 'Saya memberikan umpan balik yang konstruktif.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'enable_others_to_act'
    ),
    // Encourage the Heart
    array(
        'question' => 'Saya mengakui kontribusi orang lain.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'encourage_the_heart'
    ),
    array(
        'question' => 'Saya merayakan kemenangan tim.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'encourage_the_heart'
    ),
    array(
        'question' => 'Saya memberikan penghargaan dan pengakuan kepada orang lain.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'encourage_the_heart'
    ),
    array(
        'question' => 'Saya mengakui pencapaian orang lain secara publik.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'encourage_the_heart'
    ),
    array(
        'question' => 'Saya menginspirasi semangat tim dengan memberikan motivasi.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'encourage_the_heart'
    ),
    array(
        'question' => 'Saya menciptakan lingkungan kerja yang positif.',
        'options' => array(
            '1' => 'Jarang sekali',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Cukup sering',
            '5' => 'Sering',
            '6' => 'Sangat sering',
            '7' => 'Hampir selalu',
            '8' => 'Selalu'
        ),
        'scale' => 'encourage_the_heart'
    ),
);
?>
