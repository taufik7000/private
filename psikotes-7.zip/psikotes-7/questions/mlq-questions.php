<?php
$questions = array(
    // Kepemimpinan Transformasional
    array(
        'question' => 'Saya membuat orang lain merasa bangga untuk berasosiasi dengan saya.',
        'name' => 'mlq_1',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya berbicara tentang nilai dan keyakinan yang penting.',
        'name' => 'mlq_2',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya menekankan pentingnya memiliki rasa misi bersama.',
        'name' => 'mlq_3',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya menunjukkan standar etika yang tinggi dalam tindakan saya.',
        'name' => 'mlq_4',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mengkomunikasikan visi yang menarik tentang masa depan.',
        'name' => 'mlq_5',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mengekspresikan harapan bahwa tujuan dapat dicapai.',
        'name' => 'mlq_6',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mendorong bawahan untuk melihat masalah dari berbagai sudut pandang.',
        'name' => 'mlq_7',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mendorong inovasi dan kreativitas.',
        'name' => 'mlq_8',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya memberikan perhatian individu kepada bawahan yang membutuhkan.',
        'name' => 'mlq_9',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya menghabiskan waktu untuk mengajarkan dan membimbing.',
        'name' => 'mlq_10',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    
    // Kepemimpinan Transaksional
    array(
        'question' => 'Saya menjelaskan apa yang diharapkan dari bawahan saya.',
        'name' => 'mlq_11',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mengenali kontribusi yang baik dengan imbalan yang sesuai.',
        'name' => 'mlq_12',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya memantau kinerja dan mengambil tindakan korektif sebelum masalah muncul.',
        'name' => 'mlq_13',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mengawasi kesalahan dan penyimpangan dari standar.',
        'name' => 'mlq_14',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya hanya ikut campur ketika masalah sudah serius.',
        'name' => 'mlq_15',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya menunggu sampai sesuatu salah sebelum mengambil tindakan.',
        'name' => 'mlq_16',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    
    // Kepemimpinan Laissez-faire
    array(
        'question' => 'Saya menghindari pengambilan keputusan yang penting.',
        'name' => 'mlq_17',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya membiarkan bawahan menyelesaikan masalah mereka sendiri.',
        'name' => 'mlq_18',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    
    // Outcomes of Leadership
    array(
        'question' => 'Saya mendorong bawahan untuk berusaha lebih keras.',
        'name' => 'mlq_19',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya meningkatkan keinginan bawahan untuk berhasil.',
        'name' => 'mlq_20',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya efektif dalam memenuhi kebutuhan bawahan saya.',
        'name' => 'mlq_21',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya berhasil dalam mencapai tujuan organisasi.',
        'name' => 'mlq_22',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya membuat bawahan saya merasa puas dengan pekerjaan mereka.',
        'name' => 'mlq_23',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya menciptakan lingkungan kerja yang positif.',
        'name' => 'mlq_24',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya membuat bawahan merasa bahwa pekerjaan mereka penting.',
        'name' => 'mlq_25',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya meningkatkan moral dan semangat tim kerja.',
        'name' => 'mlq_26',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mendorong bawahan untuk berkontribusi pada keberhasilan organisasi.',
        'name' => 'mlq_27',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mengkomunikasikan harapan yang tinggi kepada bawahan saya.',
        'name' => 'mlq_28',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya memberikan umpan balik yang konstruktif dan membangun.',
        'name' => 'mlq_29',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mendorong bawahan untuk mencapai tujuan pribadi dan profesional mereka.',
        'name' => 'mlq_30',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya memastikan bahwa bawahan memiliki sumber daya yang diperlukan untuk berhasil.',
        'name' => 'mlq_31',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya membangun kepercayaan dan keandalan dengan bawahan saya.',
        'name' => 'mlq_32',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mendorong komunikasi terbuka dan jujur di tempat kerja.',
        'name' => 'mlq_33',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya menghargai kontribusi individu dalam tim.',
        'name' => 'mlq_34',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya memastikan bahwa semua orang diperlakukan dengan adil dan setara.',
        'name' => 'mlq_35',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mendukung pengembangan karir bawahan saya.',
        'name' => 'mlq_36',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya membantu bawahan mencapai keseimbangan antara pekerjaan dan kehidupan pribadi.',
        'name' => 'mlq_37',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mendorong bawahan untuk mengambil inisiatif dan tanggung jawab.',
        'name' => 'mlq_38',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya menciptakan lingkungan yang mendorong inovasi dan kreativitas.',
        'name' => 'mlq_39',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya memastikan bahwa tujuan dan harapan tim jelas.',
        'name' => 'mlq_40',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya memberikan umpan balik yang spesifik dan bermanfaat.',
        'name' => 'mlq_41',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya memastikan bahwa sumber daya yang diperlukan tersedia untuk mencapai tujuan.',
        'name' => 'mlq_42',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mendorong bawahan untuk belajar dan mengembangkan keterampilan baru.',
        'name' => 'mlq_43',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya memimpin dengan memberi contoh yang baik.',
        'name' => 'mlq_44',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    ),
    array(
        'question' => 'Saya mendorong kerja tim dan kolaborasi.',
        'name' => 'mlq_45',
        'options' => array(
            '1' => 'Sangat Jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat Sering'
        )
    )
);
?>