<?php
$questions = array(
    // Linguistic Intelligence
    array('question' => 'Saya suka membaca buku dan artikel.', 'options' => array('L' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya suka menulis cerita atau puisi.', 'options' => array('L' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya menikmati bermain dengan kata-kata.', 'options' => array('L' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya suka berbicara di depan umum.', 'options' => array('L' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya sering menceritakan lelucon atau cerita kepada teman-teman.', 'options' => array('L' => 'Setuju', 'N' => 'Tidak Setuju')),

    // Logical-Mathematical Intelligence
    array('question' => 'Saya suka memecahkan teka-teki dan masalah logika.', 'options' => array('LM' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya menikmati pelajaran matematika.', 'options' => array('LM' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya suka melakukan eksperimen ilmiah.', 'options' => array('LM' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya suka menganalisis data dan angka.', 'options' => array('LM' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya tertarik pada komputer dan teknologi.', 'options' => array('LM' => 'Setuju', 'N' => 'Tidak Setuju')),

    // Spatial Intelligence
    array('question' => 'Saya suka menggambar atau melukis.', 'options' => array('S' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya menikmati membuat model atau desain.', 'options' => array('S' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya suka bermain video game yang melibatkan ruang dan strategi.', 'options' => array('S' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya suka memecahkan teka-teki gambar.', 'options' => array('S' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya tertarik pada arsitektur dan desain interior.', 'options' => array('S' => 'Setuju', 'N' => 'Tidak Setuju')),

    // Bodily-Kinesthetic Intelligence
    array('question' => 'Saya suka olahraga dan aktivitas fisik.', 'options' => array('BK' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya merasa puas ketika bekerja dengan tangan saya.', 'options' => array('BK' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya suka menari atau bergerak mengikuti irama musik.', 'options' => array('BK' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya suka membuat kerajinan tangan.', 'options' => array('BK' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya tertarik pada pekerjaan yang melibatkan keterampilan fisik.', 'options' => array('BK' => 'Setuju', 'N' => 'Tidak Setuju')),

    // Musical Intelligence
    array('question' => 'Saya suka mendengarkan musik.', 'options' => array('M' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya suka bermain alat musik.', 'options' => array('M' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya suka bernyanyi.', 'options' => array('M' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya bisa mengingat nada dan melodi dengan mudah.', 'options' => array('M' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya tertarik pada teori musik.', 'options' => array('M' => 'Setuju', 'N' => 'Tidak Setuju')),

    // Interpersonal Intelligence
    array('question' => 'Saya suka bekerja dalam tim.', 'options' => array('IP' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya merasa puas ketika membantu orang lain.', 'options' => array('IP' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya suka berinteraksi dengan berbagai jenis orang.', 'options' => array('IP' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya sering menjadi pemimpin dalam kelompok.', 'options' => array('IP' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya tertarik pada psikologi dan memahami perilaku manusia.', 'options' => array('IP' => 'Setuju', 'N' => 'Tidak Setuju')),

    // Intrapersonal Intelligence
    array('question' => 'Saya suka merenung dan memahami diri sendiri.', 'options' => array('IA' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya menikmati waktu sendirian.', 'options' => array('IA' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya merasa puas ketika mencapai tujuan pribadi.', 'options' => array('IA' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya suka mengeksplorasi perasaan dan emosi saya.', 'options' => array('IA' => 'Setuju', 'N' => 'Tidak Setuju')),
    array('question' => 'Saya tertarik pada meditasi dan refleksi diri.', 'options' => array('IA' => 'Setuju', 'N' => 'Tidak Setuju')),

    // Naturalistic Intelligence
    array('question' => 'Saya suka berada di alam terbuka.', 'options' => array('N' => 'Setuju', 'NN' => 'Tidak Setuju')),
    array('question' => 'Saya tertarik pada binatang dan tumbuhan.', 'options' => array('N' => 'Setuju', 'NN' => 'Tidak Setuju')),
    array('question' => 'Saya suka berkebun atau merawat tanaman.', 'options' => array('N' => 'Setuju', 'NN' => 'Tidak Setuju')),
    array('question' => 'Saya menikmati kegiatan seperti hiking atau berkemah.', 'options' => array('N' => 'Setuju', 'NN' => 'Tidak Setuju')),
    array('question' => 'Saya tertarik pada ekologi dan lingkungan hidup.', 'options' => array('N' => 'Setuju', 'NN' => 'Tidak Setuju'))
);
?>
