<?php
$questions = array(
    array(
        'question' => 'Saya merasa lebih nyaman ketika:',
        'options' => array(
            'D' => 'Saya memimpin tim',
            'I' => 'Saya berinteraksi dengan banyak orang',
            'S' => 'Saya bekerja dalam lingkungan yang stabil',
            'C' => 'Saya mengikuti prosedur yang ada'
        )
    ),
    array(
        'question' => 'Saya lebih suka:',
        'options' => array(
            'D' => 'Mengambil keputusan cepat',
            'I' => 'Membuat suasana menyenangkan',
            'S' => 'Menjaga harmoni',
            'C' => 'Menganalisis informasi'
        )
    ),
    array(
        'question' => 'Saya biasanya:',
        'options' => array(
            'D' => 'Mengambil inisiatif dalam proyek',
            'I' => 'Berbicara dengan banyak orang',
            'S' => 'Mengikuti rencana yang telah ditentukan',
            'C' => 'Memeriksa setiap detail'
        )
    ),
    array(
        'question' => 'Dalam situasi konflik, saya:',
        'options' => array(
            'D' => 'Berusaha untuk mengendalikan situasi',
            'I' => 'Mencari dukungan dan konsensus',
            'S' => 'Berusaha menghindari konfrontasi',
            'C' => 'Menganalisis penyebab konflik secara mendalam'
        )
    ),
    array(
        'question' => 'Saat bekerja dalam tim, saya:',
        'options' => array(
            'D' => 'Mengambil peran sebagai pemimpin',
            'I' => 'Menghibur dan memotivasi anggota tim',
            'S' => 'Menyediakan dukungan dan stabilitas',
            'C' => 'Memastikan semuanya mengikuti prosedur yang benar'
        )
    ),
    array(
        'question' => 'Saya merasa stres ketika:',
        'options' => array(
            'D' => 'Tidak ada arah yang jelas',
            'I' => 'Saya merasa diabaikan',
            'S' => 'Lingkungan tidak stabil',
            'C' => 'Standar kerja tidak diikuti'
        )
    ),
    array(
        'question' => 'Saya lebih termotivasi oleh:',
        'options' => array(
            'D' => 'Pencapaian dan hasil',
            'I' => 'Pengakuan dan persetujuan sosial',
            'S' => 'Stabilitas dan keamanan',
            'C' => 'Akurasi dan ketepatan'
        )
    ),
    array(
        'question' => 'Saya lebih suka menghabiskan waktu saya:',
        'options' => array(
            'D' => 'Mengambil keputusan strategis',
            'I' => 'Berbicara dengan orang lain',
            'S' => 'Mengikuti rutinitas yang teratur',
            'C' => 'Menganalisis data dan informasi'
        )
    ),
    array(
        'question' => 'Saya paling menikmati:',
        'options' => array(
            'D' => 'Mengendalikan situasi',
            'I' => 'Berinteraksi dengan orang baru',
            'S' => 'Menjaga lingkungan yang harmonis',
            'C' => 'Mengikuti prosedur yang benar'
        )
    ),
    array(
        'question' => 'Saya merasa frustrasi ketika:',
        'options' => array(
            'D' => 'Orang lain tidak sejalan dengan visi saya',
            'I' => 'Tidak ada kesempatan untuk berinteraksi',
            'S' => 'Situasi tidak dapat diprediksi',
            'C' => 'Standar tidak dipenuhi'
        )
    ),
    array(
        'question' => 'Dalam situasi yang penuh tekanan, saya:',
        'options' => array(
            'D' => 'Mengambil alih dan membuat keputusan',
            'I' => 'Mencari dukungan sosial',
            'S' => 'Berusaha menenangkan diri dan orang lain',
            'C' => 'Menganalisis situasi dengan hati-hati'
        )
    ),
    array(
        'question' => 'Saya merasa paling berhasil ketika:',
        'options' => array(
            'D' => 'Mencapai tujuan yang sulit',
            'I' => 'Diterima dan disukai oleh banyak orang',
            'S' => 'Menjaga lingkungan yang stabil',
            'C' => 'Menghasilkan kerja yang akurat'
        )
    ),
    array(
        'question' => 'Ketika menghadapi masalah, saya:',
        'options' => array(
            'D' => 'Mengambil keputusan cepat untuk mengatasinya',
            'I' => 'Membicarakannya dengan orang lain',
            'S' => 'Mengikuti pendekatan yang telah terbukti',
            'C' => 'Menganalisis semua pilihan dengan hati-hati'
        )
    ),
    array(
        'question' => 'Saya merasa puas ketika:',
        'options' => array(
            'D' => 'Mengatasi tantangan besar',
            'I' => 'Berinteraksi dan membangun hubungan',
            'S' => 'Menjaga ketenangan dan kestabilan',
            'C' => 'Mencapai hasil yang sangat akurat'
        )
    ),
    array(
        'question' => 'Saya lebih suka bekerja dalam lingkungan yang:',
        'options' => array(
            'D' => 'Berorientasi pada hasil',
            'I' => 'Berorientasi pada orang',
            'S' => 'Berorientasi pada proses',
            'C' => 'Berorientasi pada detail'
        )
    ),
    array(
        'question' => 'Saya lebih suka mendapatkan umpan balik yang:',
        'options' => array(
            'D' => 'Langsung dan to the point',
            'I' => 'Penuh pujian dan dukungan',
            'S' => 'Tenang dan konstruktif',
            'C' => 'Detail dan spesifik'
        )
    ),
    array(
        'question' => 'Saya cenderung:',
        'options' => array(
            'D' => 'Berbicara dengan tegas dan langsung',
            'I' => 'Berbicara dengan antusias dan ramah',
            'S' => 'Berbicara dengan tenang dan penuh perhatian',
            'C' => 'Berbicara dengan hati-hati dan detail'
        )
    ),
    array(
        'question' => 'Ketika bekerja di bawah tekanan, saya:',
        'options' => array(
            'D' => 'Tetap fokus pada tujuan akhir',
            'I' => 'Mencari dukungan dari orang lain',
            'S' => 'Berusaha menjaga kestabilan dan ketenangan',
            'C' => 'Mengikuti prosedur dan memastikan akurasi'
        )
    ),
    array(
        'question' => 'Saya merasa berhasil ketika:',
        'options' => array(
            'D' => 'Mencapai target ambisius',
            'I' => 'Membangun jaringan luas',
            'S' => 'Menciptakan lingkungan yang harmonis',
            'C' => 'Menghasilkan pekerjaan berkualitas tinggi'
        )
    ),
    array(
        'question' => 'Saya lebih suka bekerja dengan orang yang:',
        'options' => array(
            'D' => 'Berorientasi pada hasil dan tindakan',
            'I' => 'Bersemangat dan sosial',
            'S' => 'Kooperatif dan stabil',
            'C' => 'Teliti dan teratur'
        )
    ),
    array(
        'question' => 'Saya lebih suka mengatasi masalah dengan:',
        'options' => array(
            'D' => 'Mengambil keputusan tegas',
            'I' => 'Melibatkan orang lain dalam diskusi',
            'S' => 'Mengikuti metode yang sudah ada',
            'C' => 'Menganalisis semua informasi yang tersedia'
        )
    ),
    array(
        'question' => 'Saya merasa paling percaya diri ketika:',
        'options' => array(
            'D' => 'Mengendalikan situasi',
            'I' => 'Berinteraksi dengan banyak orang',
            'S' => 'Lingkungan kerja stabil',
            'C' => 'Semua detail diperhatikan'
        )
    ),
    array(
        'question' => 'Saya lebih suka bekerja dengan gaya yang:',
        'options' => array(
            'D' => 'Cepat dan efisien',
            'I' => 'Interaktif dan kolaboratif',
            'S' => 'Tenang dan metodis',
            'C' => 'Sistematis dan akurat'
        )
    ),
    array(
        'question' => 'Dalam rapat tim, saya:',
        'options' => array(
            'D' => 'Mengarahkan diskusi dan keputusan',
            'I' => 'Mendorong partisipasi dan ide kreatif',
            'S' => 'Mendukung dan mendengarkan orang lain',
            'C' => 'Mencatat dan memastikan kepatuhan pada agenda'
        )
    ),
    array(
        'question' => 'Ketika membuat keputusan penting, saya:',
        'options' => array(
            'D' => 'Mengambil tindakan cepat dan tegas',
            'I' => 'Meminta pendapat banyak orang',
            'S' => 'Mengikuti pendekatan yang sudah ada',
            'C' => 'Menganalisis semua kemungkinan'
        )
    ),
    array(
        'question' => 'Saya merasa nyaman ketika:',
        'options' => array(
            'D' => 'Mencapai hasil yang nyata',
            'I' => 'Berinteraksi dengan orang lain',
            'S' => 'Lingkungan kerja tenang dan stabil',
            'C' => 'Semua berjalan sesuai rencana'
        )
    ),
    array(
        'question' => 'Saya cenderung berperilaku:',
        'options' => array(
            'D' => 'Tegas dan berorientasi pada tujuan',
            'I' => 'Ramah dan sosial',
            'S' => 'Tenang dan kooperatif',
            'C' => 'Analitis dan teliti'
        )
    ),
    array(
        'question' => 'Saya merasa paling berenergi ketika:',
        'options' => array(
            'D' => 'Memimpin proyek besar',
            'I' => 'Berinteraksi dengan banyak orang',
            'S' => 'Menjaga kestabilan tim',
            'C' => 'Memastikan semua detail tepat'
        )
    ),
);
?>
