<?php
$questions = array(
    array(
        'question' => 'Seberapa sering Anda merasa puas dengan hubungan Anda?',
        'options' => array(
            '1' => 'Sangat sering',
            '2' => 'Sering',
            '3' => 'Kadang-kadang',
            '4' => 'Jarang',
            '5' => 'Sangat jarang'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda dan pasangan Anda bertengkar?',
        'options' => array(
            '1' => 'Sangat sering',
            '2' => 'Sering',
            '3' => 'Kadang-kadang',
            '4' => 'Jarang',
            '5' => 'Sangat jarang'
        )
    ),
    array(
        'question' => 'Seberapa baik Anda dan pasangan Anda berkomunikasi?',
        'options' => array(
            '1' => 'Sangat buruk',
            '2' => 'Buruk',
            '3' => 'Cukup baik',
            '4' => 'Baik',
            '5' => 'Sangat baik'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda merasa didukung oleh pasangan Anda?',
        'options' => array(
            '1' => 'Sangat jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda dan pasangan Anda menghabiskan waktu berkualitas bersama?',
        'options' => array(
            '1' => 'Sangat jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa puas Anda dengan keintiman emosional dalam hubungan Anda?',
        'options' => array(
            '1' => 'Sangat tidak puas',
            '2' => 'Tidak puas',
            '3' => 'Cukup puas',
            '4' => 'Puas',
            '5' => 'Sangat puas'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda dan pasangan Anda saling mendukung dalam mencapai tujuan pribadi?',
        'options' => array(
            '1' => 'Sangat jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda merasa dihargai dalam hubungan Anda?',
        'options' => array(
            '1' => 'Sangat jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa baik Anda dan pasangan Anda menangani perbedaan pendapat?',
        'options' => array(
            '1' => 'Sangat buruk',
            '2' => 'Buruk',
            '3' => 'Cukup baik',
            '4' => 'Baik',
            '5' => 'Sangat baik'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda merasa pasangan Anda mendengarkan Anda dengan penuh perhatian?',
        'options' => array(
            '1' => 'Sangat jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat sering'
        )
    ),
    array(
        'question' => 'Seberapa puas Anda dengan keseimbangan tanggung jawab dalam hubungan Anda?',
        'options' => array(
            '1' => 'Sangat tidak puas',
            '2' => 'Tidak puas',
            '3' => 'Cukup puas',
            '4' => 'Puas',
            '5' => 'Sangat puas'
        )
    ),
    array(
        'question' => 'Seberapa sering Anda merasa hubungan Anda memberi Anda kebahagiaan?',
        'options' => array(
            '1' => 'Sangat jarang',
            '2' => 'Jarang',
            '3' => 'Kadang-kadang',
            '4' => 'Sering',
            '5' => 'Sangat sering'
        )
    )
);
?>
