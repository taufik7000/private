<?php
$questions = array(
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda merasa gugup, cemas, atau tegang?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'gad7'
    ),
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda merasa tidak bisa berhenti atau mengendalikan kekhawatiran?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'gad7'
    ),
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda merasa khawatir berlebihan tentang berbagai hal?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'gad7'
    ),
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda merasa kesulitan untuk rileks?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'gad7'
    ),
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda merasa begitu gelisah sehingga sulit untuk duduk diam?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'gad7'
    ),
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda merasa mudah tersinggung atau marah?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'gad7'
    ),
    array(
        'question' => 'Selama dua minggu terakhir, seberapa sering Anda merasa takut seolah sesuatu yang buruk akan terjadi?',
        'options' => array(
            '0' => 'Tidak sama sekali',
            '1' => 'Beberapa hari',
            '2' => 'Lebih dari setengah hari',
            '3' => 'Hampir setiap hari'
        ),
        'scale' => 'gad7'
    ),
);
?>
