<?php
require_once __DIR__ . '/vendor/autoload.php';

\Midtrans\Config::$serverKey = 'SB-Mid-server-DSpG9ZVOAkyhgsgWXLjT8DRU';
\Midtrans\Config::$isProduction = false; // Ubah ke true untuk produksi
\Midtrans\Config::$isSanitized = true;
\Midtrans\Config::$is3ds = true;
