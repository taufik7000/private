<?php
/*
Plugin Name: Golife Psikotes Plugin
Description: Plugin Psikotes Untuk WORDPRESS
Version: 1.0
Author: Muhammad Taufik
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class PsikotesPlugin {
    private $premium_tests = ['phq9', 'gad7', 'bigfive']; // Daftar tes premium

    public function __construct() {
        add_shortcode('psikotes_test', array($this, 'display_test'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
        add_action('wp_ajax_submit_test', array($this, 'handle_test_submission'));
        add_action('wp_ajax_nopriv_submit_test', array($this, 'handle_test_submission'));
        add_action('wp_ajax_nopriv_midtrans_payment', array($this, 'handle_midtrans_payment'));
        add_action('wp_ajax_midtrans_payment', array($this, 'handle_midtrans_payment'));
    }

    public function enqueue_styles() {
        wp_enqueue_style('psikotes-style', plugin_dir_url(__FILE__) . 'style.css');
        wp_enqueue_script('psikotes-script', plugin_dir_url(__FILE__) . 'multi-test-script.js', array('jquery'), null, true);
        wp_localize_script('psikotes-script', 'psikotes_ajax', array('ajax_url' => admin_url('admin-ajax.php')));
    }

    public function display_test($atts) {
        $test_slug = isset($atts['test']) ? $atts['test'] : 'mbti';
        $test_file = plugin_dir_path(__FILE__) . "tests/$test_slug.php";

        if (!is_user_logged_in()) {
            echo 'Anda harus login untuk mengakses tes ini.';
            return;
        }

        $user_id = get_current_user_id();
        $is_premium = $this->check_premium_status($user_id);

        // Simpan URL tes ke dalam sesi jika tes adalah premium
        if (in_array($test_slug, $this->premium_tests)) {
            session_start();
            $_SESSION['tes_url'] = home_url("/psikotes/tes-$test_slug"); // Ubah sesuai URL tes yang relevan
        }

        if (file_exists($test_file)) {
            if (in_array($test_slug, $this->premium_tests) && !$is_premium) {
                include plugin_dir_path(__FILE__) . 'template-payment.php';
            } else {
                include $test_file;
            }
        } else {
            echo "Tes tidak ditemukan.";
        }
    }

    private function check_premium_status($user_id) {
        return get_user_meta($user_id, 'is_premium', true);
    }

    public function handle_test_submission() {
        $test = isset($_POST['test']) ? $_POST['test'] : 'mbti';
        $handler_file = plugin_dir_path(__FILE__) . "handlers/{$test}-handler.php";

        if (file_exists($handler_file)) {
            include $handler_file;
        } else {
            wp_send_json_error('Test handler not found.');
        }
    }

    public function handle_midtrans_payment() {
        $order_id = isset($_POST['order_id']) ? sanitize_text_field($_POST['order_id']) : '';
        $status_code = isset($_POST['status_code']) ? sanitize_text_field($_POST['status_code']) : '';
        $transaction_status = isset($_POST['transaction_status']) ? sanitize_text_field($_POST['transaction_status']) : '';

        if ($transaction_status == 'settlement' && $status_code == '200') {
            // Pembayaran berhasil, perbarui status pengguna menjadi premium
            $user_id = get_current_user_id();
            update_user_meta($user_id, 'is_premium', 1);

            // Kirim respons sukses
            wp_send_json_success('Payment processed successfully');
        } else {
            // Pembayaran gagal, kirim respons error
            wp_send_json_error('Payment failed');
        }
    }
}

new PsikotesPlugin();


?>
