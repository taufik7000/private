<?php
/* Template Name: Purchase Confirmation */

get_header();

$order_id = $_GET['order_id'];
$status_code = $_GET['status_code'];
$transaction_status = $_GET['transaction_status'];

if ($transaction_status == 'settlement' && $status_code == '200') {
    echo '<h1>Transaksi Berhasil!</h1>';
    echo '<p>Order ID: ' . htmlspecialchars($order_id) . '</p>';
    echo '<p>Status Transaksi: ' . htmlspecialchars($transaction_status) . '</p>';
    echo '<p>Terima kasih atas pembelian Anda. Status akun Anda telah diperbarui menjadi premium.</p>';
} else {
    echo '<h1>Transaksi Gagal!</h1>';
    echo '<p>Order ID: ' . htmlspecialchars($order_id) . '</p>';
    echo '<p>Status Transaksi: ' . htmlspecialchars($transaction_status) . '</p>';
    echo '<p>Mohon maaf, transaksi Anda tidak berhasil. Silakan coba lagi.</p>';
}

get_footer();
