<div class="payment-container">
    <h1>Akses Tes Premium</h1>
    <p>Untuk mengakses tes premium, Anda perlu melakukan pembayaran. Dengan menjadi pengguna premium, Anda dapat mengakses tes berikut:</p>
    <div class="premium-test-list">
        <ul>
            <li><?php echo strtoupper($test_slug); ?> (Deskripsi Tes)</li>
            <!-- Anda dapat menambahkan logika untuk menampilkan deskripsi dinamis jika diperlukan -->
        </ul>
    </div>
    <button id="pay-button" class="pay-button">Bayar Sekarang</button>
</div>
<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="SB-Mid-client-tpVvvRI9DM0gVLsC"></script>
<script type="text/javascript">
    document.getElementById('pay-button').onclick = function () {
        fetch('<?php echo plugins_url('create_transaction.php', __FILE__); ?>')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    alert('Error: ' + data.error);
                } else {
                    snap.pay(data.token);
                }
            })
            .catch(error => {
                console.error('There was a problem with the fetch operation:', error);
            });
    };
</script>
