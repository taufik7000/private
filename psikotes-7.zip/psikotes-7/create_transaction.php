<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/midtrans_config.php';

// Debugging awal
file_put_contents(__DIR__ . '/debug.txt', "Script executed\n", FILE_APPEND);

header('Content-Type: application/json');

$orderId = rand();
$params = array(
    'transaction_details' => array(
        'order_id' => $orderId,
        'gross_amount' => 10000, // Nominal transaksi
    ),
    'customer_details' => array(
        'first_name' => 'John',
        'last_name' => 'Doe',
        'email' => 'john.doe@example.com',
        'phone' => '081234567890',
    ),
);

try {
    // Generate Snap token
    $snapToken = \Midtrans\Snap::getSnapToken($params);
    file_put_contents(__DIR__ . '/debug.txt', "Snap token: $snapToken\n", FILE_APPEND);
    echo json_encode(['token' => $snapToken]);
} catch (Exception $e) {
    // Handle error
    file_put_contents(__DIR__ . '/debug.txt', "Error: " . $e->getMessage() . "\n", FILE_APPEND);
    echo json_encode(['error' => $e->getMessage()]);
}
