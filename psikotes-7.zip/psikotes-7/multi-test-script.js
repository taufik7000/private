jQuery(document).ready(function($) {
    var currentQuestion = 1;
    var totalQuestions = parseInt($('#test-form').data('total-questions'));

    function showQuestion(index) {
        $('.test-question').hide();
        $('#question_' + index).show();
        updateProgressBar(index, totalQuestions);
    }

    function updateProgressBar(current, total) {
        var progress = (current / total) * 100;
        $('#progress-bar').css('width', progress + '%');
        $('#progress-percentage').text(Math.round(progress) + '%');
    }

    $('.next-button').on('click', function() {
        var question = $(this).data('question');
        if ($('#question_' + question).find('input[type="radio"]:checked').length > 0) {
            currentQuestion++;
            showQuestion(currentQuestion);
        } else {
            alert('Silakan pilih salah satu opsi.');
        }
    });

    $('.back-button').on('click', function() {
        currentQuestion--;
        showQuestion(currentQuestion);
    });

    $('#test-form').on('submit', function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        
        // Show the spinner
        $('#loading-spinner').show();
        $('#test-form').hide();
        
        $.post(psikotes_ajax.ajax_url, formData + '&action=submit_test', function(response) {
            if (response.success) {
                $('.test-question').hide();
                $('input[type="radio"]').prop('checked', false);
                $('#result-text').html(response.data);
                $('#loading-spinner').hide();
                $('#test-result').show();
            } else {
                $('#result-text').text('Terjadi kesalahan. Silakan coba lagi.');
                $('#loading-spinner').hide();
                $('#test-form').show();
            }
        });
    });

    $('#retry-button').on('click', function() {
        currentQuestion = 1;
        $('input[type="radio"]').prop('checked', false);
        $('#test-result').hide();
        showQuestion(currentQuestion);
        $('#test-form').show();
    });

    // Initial call to show the first question
    showQuestion(currentQuestion);
});
