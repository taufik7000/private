<?php
require_once __DIR__ . '/wp-content/plugins/psikotes/midtrans_config.php';

// Debugging awal
file_put_contents(__DIR__ . '/debug_notification.txt', "Notification received\n", FILE_APPEND);

$notif = new \Midtrans\Notification();

$transaction = $notif->transaction_status;
$type = $notif->payment_type;
$order_id = $notif->order_id;
$fraud = $notif->fraud_status;

file_put_contents(__DIR__ . '/debug_notification.txt', "Order ID: $order_id\n", FILE_APPEND);
file_put_contents(__DIR__ . '/debug_notification.txt', "Transaction Status: $transaction\n", FILE_APPEND);

if ($transaction == 'capture') {
    if ($type == 'credit_card') {
        if ($fraud == 'challenge') {
            update_transaction_status($order_id, 'challenge');
        } else {
            update_transaction_status($order_id, 'success');
        }
    }
} else if ($transaction == 'settlement') {
    update_transaction_status($order_id, 'settlement');
} else if ($transaction == 'pending') {
    update_transaction_status($order_id, 'pending');
} else if ($transaction == 'deny') {
    update_transaction_status($order_id, 'deny');
} else if ($transaction == 'expire') {
    update_transaction_status($order_id, 'expire');
} else if ($transaction == 'cancel') {
    update_transaction_status($order_id, 'cancel');
}

function update_transaction_status($order_id, $status) {
    global $wpdb;

    // Update transaction status in database
    $wpdb->update(
        "{$wpdb->prefix}transactions",
        array('status' => $status),
        array('order_id' => $order_id)
    );

    // If transaction is successful, update user to premium
    if ($status == 'settlement' || $status == 'capture') {
        $user_id = $wpdb->get_var($wpdb->prepare("SELECT user_id FROM {$wpdb->prefix}transactions WHERE order_id = %s", $order_id));
        $wpdb->update(
            "{$wpdb->prefix}users",
            array('is_premium' => 1),
            array('ID' => $user_id)
        );
        file_put_contents(__DIR__ . '/debug_notification.txt', "User ID $user_id updated to premium\n", FILE_APPEND);
    }
}
