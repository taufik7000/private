<?php
$total_score = 0;

foreach ($_POST as $key => $value) {
    if (is_numeric($value)) {
        $total_score += intval($value);
    }
}

$average_score = $total_score / count($_POST);

// Meng-include file analisis
include_once plugin_dir_path(__FILE__) . '../analyses/ras-analysis.php';

$analysis = get_ras_analysis($average_score);

wp_send_json_success('Skor Rata-rata Anda: ' . $average_score . '<br><br>' . $analysis);
?>
