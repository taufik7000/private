<?php
// Inisialisasi skor untuk setiap dimensi
$answers = array(
    'E' => 0,
    'I' => 0,
    'S' => 0,
    'N' => 0,
    'T' => 0,
    'F' => 0,
    'J' => 0,
    'P' => 0,
);

// Debugging: Tambahkan log untuk memeriksa data post
error_log('Data POST: ' . print_r($_POST, true));

// Iterasi melalui jawaban dan tambahkan skor yang sesuai
foreach ($_POST as $key => $value) {
    if (isset($answers[$value])) {
        $answers[$value]++;
    }
}

// Tentukan hasil akhir berdasarkan skor yang lebih tinggi dalam setiap pasangan
$result = '';
$result .= ($answers['E'] > $answers['I']) ? 'E' : 'I';
$result .= ($answers['S'] > $answers['N']) ? 'S' : 'N';
$result .= ($answers['T'] > $answers['F']) ? 'T' : 'F';
$result .= ($answers['J'] > $answers['P']) ? 'J' : 'P';

// Debugging: Tambahkan log untuk memeriksa hasil
error_log('Hasil: ' . $result);

// Meng-include file analisis
include_once plugin_dir_path(__FILE__) . '../analyses/mbti-analysis.php';

// Panggil fungsi analisis dengan hasil yang diperoleh
$analysis = get_mbti_analysis($result);

// Debugging: Tambahkan log untuk memeriksa analisis
error_log('Analisis: ' . $analysis);

// Kirimkan respons sukses dengan hasil tes dan analisis
wp_send_json_success('Hasil Tes Anda: ' . $result . '<br><br>' . $analysis);
?>
