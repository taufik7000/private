<?php

// Jumlah pertanyaan untuk setiap trait
$traitQuestions = array(
    'O' => 20,
    'C' => 20,
    'E' => 20,
    'A' => 20,
    'N' => 20,
);

$answers = array(
    'O' => 0,
    'C' => 0,
    'E' => 0,
    'A' => 0,
    'N' => 0,
);

// Menghitung jumlah jawaban untuk setiap trait
foreach ($_POST as $key => $value) {
    if (isset($answers[$value])) {
        $answers[$value]++;
    }
}

// Memastikan file analysis disertakan
include_once plugin_dir_path(__FILE__) . '../analyses/bigfive-analysis.php';

// Memastikan total persentase tidak melebihi 100%
$analysis = get_bigfive_analysis($answers, $traitQuestions);

wp_send_json_success($analysis);
?>
