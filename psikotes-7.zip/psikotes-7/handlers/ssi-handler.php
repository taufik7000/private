<?php
$emotional_expressivity_score = 0;
$emotional_sensitivity_score = 0;
$emotional_control_score = 0;
$social_expressivity_score = 0;
$social_sensitivity_score = 0;
$social_control_score = 0;

$emotional_expressivity_questions = 6;
$emotional_sensitivity_questions = 6;
$emotional_control_questions = 6;
$social_expressivity_questions = 6;
$social_sensitivity_questions = 6;
$social_control_questions = 6;

foreach ($_POST as $key => $value) {
    if (is_numeric($value)) {
        if (strpos($key, 'emotional_expressivity') !== false) {
            $emotional_expressivity_score += intval($value);
        } elseif (strpos($key, 'emotional_sensitivity') !== false) {
            $emotional_sensitivity_score += intval($value);
        } elseif (strpos($key, 'emotional_control') !== false) {
            $emotional_control_score += intval($value);
        } elseif (strpos($key, 'social_expressivity') !== false) {
            $social_expressivity_score += intval($value);
        } elseif (strpos($key, 'social_sensitivity') !== false) {
            $social_sensitivity_score += intval($value);
        } elseif (strpos($key, 'social_control') !== false) {
            $social_control_score += intval($value);
        }
    }
}

$emotional_expressivity_average = $emotional_expressivity_score / $emotional_expressivity_questions;
$emotional_sensitivity_average = $emotional_sensitivity_score / $emotional_sensitivity_questions;
$emotional_control_average = $emotional_control_score / $emotional_control_questions;
$social_expressivity_average = $social_expressivity_score / $social_expressivity_questions;
$social_sensitivity_average = $social_sensitivity_score / $social_sensitivity_questions;
$social_control_average = $social_control_score / $social_control_questions;

// Meng-include file analisis
include_once plugin_dir_path(__FILE__) . '../analyses/ssi-analysis.php';

$analysis = get_ssi_analysis($emotional_expressivity_average, $emotional_sensitivity_average, $emotional_control_average, $social_expressivity_average, $social_sensitivity_average, $social_control_average);

wp_send_json_success($analysis);
?>
