<?php
$consensus_score = 0;
$satisfaction_score = 0;
$cohesion_score = 0;
$affectional_expression_score = 0;

$consensus_questions = 5;
$satisfaction_questions = 5;
$cohesion_questions = 5;
$affectional_expression_questions = 5;

foreach ($_POST as $key => $value) {
    if (is_numeric($value)) {
        if (strpos($key, 'consensus') !== false) {
            $consensus_score += intval($value);
        } elseif (strpos($key, 'satisfaction') !== false) {
            $satisfaction_score += intval($value);
        } elseif (strpos($key, 'cohesion') !== false) {
            $cohesion_score += intval($value);
        } elseif (strpos($key, 'affectional_expression') !== false) {
            $affectional_expression_score += intval($value);
        }
    }
}

$consensus_average = $consensus_score / $consensus_questions;
$satisfaction_average = $satisfaction_score / $satisfaction_questions;
$cohesion_average = $cohesion_score / $cohesion_questions;
$affectional_expression_average = $affectional_expression_score / $affectional_expression_questions;

// Meng-include file analisis
include_once plugin_dir_path(__FILE__) . '../analyses/das-analysis.php';

$analysis = get_das_analysis($consensus_average, $satisfaction_average, $cohesion_average, $affectional_expression_average);

wp_send_json_success($analysis);
?>
