<?php
$score = array(
    'perceiving_emotions' => 0,
    'using_emotions' => 0,
    'understanding_emotions' => 0,
    'managing_emotions' => 0,
);

// Debugging: Tambahkan log untuk memeriksa data POST
error_log('Data POST: ' . print_r($_POST, true));

// Pemetaan jawaban benar
$correct_answers = array(
    'perceiving_emotions_1' => 'A',
    'perceiving_emotions_2' => 'B',
    'perceiving_emotions_3' => 'C',
    'perceiving_emotions_4' => 'D',
    'perceiving_emotions_5' => 'D',
    'perceiving_emotions_6' => 'A',
    'perceiving_emotions_7' => 'B',
    'perceiving_emotions_8' => 'C',
    'perceiving_emotions_9' => 'D',
    'perceiving_emotions_10' => 'D',
    'perceiving_emotions_11' => 'A',
    'perceiving_emotions_12' => 'B',
    'perceiving_emotions_13' => 'C',
    'perceiving_emotions_14' => 'D',
    'perceiving_emotions_15' => 'D',
    'perceiving_emotions_16' => 'A',
    'perceiving_emotions_17' => 'B',
    'perceiving_emotions_18' => 'C',
    'perceiving_emotions_19' => 'D',
    'perceiving_emotions_20' => 'D',
    'using_emotions_1' => 'A',
    'using_emotions_2' => 'A',
    'using_emotions_3' => 'A',
    'using_emotions_4' => 'A',
    'using_emotions_5' => 'A',
    'using_emotions_6' => 'A',
    'using_emotions_7' => 'A',
    'using_emotions_8' => 'A',
    'using_emotions_9' => 'A',
    'using_emotions_10' => 'A',
    'using_emotions_11' => 'A',
    'using_emotions_12' => 'A',
    'using_emotions_13' => 'A',
    'using_emotions_14' => 'A',
    'using_emotions_15' => 'A',
    'using_emotions_16' => 'A',
    'using_emotions_17' => 'A',
    'using_emotions_18' => 'A',
    'using_emotions_19' => 'A',
    'using_emotions_20' => 'A',
    'understanding_emotions_1' => 'B',
    'understanding_emotions_2' => 'A',
    'understanding_emotions_3' => 'B',
    'understanding_emotions_4' => 'A',
    'understanding_emotions_5' => 'B',
    'understanding_emotions_6' => 'A',
    'understanding_emotions_7' => 'A',
    'understanding_emotions_8' => 'A',
    'understanding_emotions_9' => 'B',
    'understanding_emotions_10' => 'A',
    'understanding_emotions_11' => 'B',
    'understanding_emotions_12' => 'A',
    'understanding_emotions_13' => 'B',
    'understanding_emotions_14' => 'A',
    'understanding_emotions_15' => 'D',
    'understanding_emotions_16' => 'A',
    'understanding_emotions_17' => 'A',
    'understanding_emotions_18' => 'B',
    'understanding_emotions_19' => 'A',
    'understanding_emotions_20' => 'B',
    'managing_emotions_1' => 'B',
    'managing_emotions_2' => 'B',
    'managing_emotions_3' => 'A',
    'managing_emotions_4' => 'B',
    'managing_emotions_5' => 'A',
    'managing_emotions_6' => 'A',
    'managing_emotions_7' => 'A',
    'managing_emotions_8' => 'A',
    'managing_emotions_9' => 'B',
    'managing_emotions_10' => 'C',
    'managing_emotions_11' => 'B',
    'managing_emotions_12' => 'A',
    'managing_emotions_13' => 'A',
    'managing_emotions_14' => 'A',
    'managing_emotions_15' => 'A',
    'managing_emotions_16' => 'B',
    'managing_emotions_17' => 'A',
    'managing_emotions_18' => 'A',
    'managing_emotions_19' => 'A',
    'managing_emotions_20' => 'B'
);

foreach ($_POST as $key => $value) {
    error_log("Processing question: $key with answer: $value"); // Log setiap jawaban
    if (isset($correct_answers[$key]) && $correct_answers[$key] === $value) {
        // Tambahkan skor berdasarkan kategori
        if (strpos($key, 'perceiving_emotions') !== false) {
            $score['perceiving_emotions']++;
        } elseif (strpos($key, 'using_emotions') !== false) {
            $score['using_emotions']++;
        } elseif (strpos($key, 'understanding_emotions') !== false) {
            $score['understanding_emotions']++;
        } elseif (strpos($key, 'managing_emotions') !== false) {
            $score['managing_emotions']++;
        }
    }
}

// Log skor yang dihitung
error_log('Scores: ' . print_r($score, true));

include_once plugin_dir_path(__FILE__) . '../analyses/msceit-analysis.php';
$analysis = get_msceit_analysis($score);

// Log hasil analisis
error_log('Analysis: ' . print_r($analysis, true));

// Format hasil untuk dikirimkan kembali ke pengguna
$formatted_analysis = $analysis;

wp_send_json_success('Hasil Tes Anda:<br><br>' . $formatted_analysis);
?>
