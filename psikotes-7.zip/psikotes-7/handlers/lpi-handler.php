<?php
$scores = array(
    'model_the_way' => 0,
    'inspire_a_shared_vision' => 0,
    'challenge_the_process' => 0,
    'enable_others_to_act' => 0,
    'encourage_the_heart' => 0,
);

foreach ($_POST as $key => $value) {
    if (strpos($key, 'question') !== false) {
        $scale = $_POST[$key . '_scale'];
        $scores[$scale] += intval($value);
    }
}

include_once plugin_dir_path(__FILE__) . '../analyses/lpi-analysis.php';
$analysis = get_lpi_analysis($scores);

wp_send_json_success('Hasil Tes Anda:<br><br>' . $analysis);
?>
