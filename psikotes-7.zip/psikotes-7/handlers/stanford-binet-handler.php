<?php
$answers = array(
    'verbal' => 0,
    'matematika' => 0,
    'spasial' => 0,
    'penalaran' => 0,
);

// Debugging: Tambahkan log untuk memeriksa data POST
error_log('Data POST: ' . print_r($_POST, true));

// Pemetaan skor berdasarkan jawaban
$score_mapping = array(
    'A' => 'verbal',
    'B' => 'matematika',
    'C' => 'spasial',
    'D' => 'penalaran'
);

foreach ($_POST as $key => $value) {
    if (isset($score_mapping[$value])) {
        $answers[$score_mapping[$value]]++;
    }
}

include_once plugin_dir_path(__FILE__) . '../analyses/stanford-binet-analysis.php';
$analysis = get_stanford_binet_analysis($answers);

// Format hasil untuk dikirimkan kembali ke pengguna
$formatted_analysis = '';
foreach ($analysis as $category => $description) {
    $formatted_analysis .= '<b>' . ucfirst($category) . ':</b> ' . $description . '<br>';
}

wp_send_json_success('Hasil Tes Anda:<br><br>' . $formatted_analysis);
?>
