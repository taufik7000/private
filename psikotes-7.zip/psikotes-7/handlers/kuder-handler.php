<?php
$answers = array(
    'realistic' => 0,
    'investigative' => 0,
    'artistic' => 0,
    'social' => 0,
    'enterprising' => 0,
    'conventional' => 0,
);

foreach ($_POST as $key => $value) {
    foreach ($questions as $index => $question) {
        if ($value == 'Y' && $question['scale'] == $key) {
            $answers[$question['scale']]++;
        }
    }
}

include_once plugin_dir_path(__FILE__) . '../analyses/kuder-analysis.php';
$analysis = get_kuder_analysis($answers);

wp_send_json_success('Hasil Tes Anda:<br><br>' . $analysis);
?>
