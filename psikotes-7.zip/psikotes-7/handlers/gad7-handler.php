<?php
$total_score = 0;

foreach ($_POST as $key => $value) {
    if (strpos($key, 'question') !== false) {
        $total_score += intval($value);
    }
}

include_once plugin_dir_path(__FILE__) . '../analyses/gad7-analysis.php';
$analysis = get_gad7_analysis($total_score);

wp_send_json_success('Hasil Tes Anda:<br><br>' . $analysis);
?>
