<?php
$score = array(
    'verbal' => 0,
    'arithmetics' => 0,
    'visual' => 0,
    'memory' => 0,
    'processing' => 0,
);

foreach ($_POST as $key => $value) {
    if (strpos($key, 'question_') !== false) {
        $question_number = intval(explode('_', $key)[1]);

        // Pemahaman Verbal: Pertanyaan 1-10
        if ($question_number >= 1 && $question_number <= 10) {
            if ($value == 'A' || $value == 'B') { // Sesuaikan jawaban benar
                $score['verbal']++;
            }
        }

        // Kemampuan Aritmetika: Pertanyaan 11-20
        if ($question_number >= 11 && $question_number <= 20) {
            if ($value == 'B' || $value == 'C') { // Sesuaikan jawaban benar
                $score['arithmetics']++;
            }
        }

        // Pemahaman Ruang Visual: Pertanyaan 21-30
        if ($question_number >= 21 && $question_number <= 30) {
            if ($value == 'B' || $value == 'C') { // Sesuaikan jawaban benar
                $score['visual']++;
            }
        }

        // Memori Kerja: Pertanyaan 31-40
        if ($question_number >= 31 && $question_number <= 40) {
            if ($value == 'B' || $value == 'C') { // Sesuaikan jawaban benar
                $score['memory']++;
            }
        }

        // Kecepatan Pemrosesan: Pertanyaan 41-50
        if ($question_number >= 41 && $question_number <= 50) {
            if ($value == 'B' || $value == 'C') { // Sesuaikan jawaban benar
                $score['processing']++;
            }
        }
    }
}

$total_score = array_sum($score);

// Meng-include file analisis
include_once plugin_dir_path(__FILE__) . '../analyses/wais-analysis.php';

$analysis = get_analysis($score);

wp_send_json_success('Hasil Tes Anda: ' . $total_score . '<br><br>' . $analysis);
