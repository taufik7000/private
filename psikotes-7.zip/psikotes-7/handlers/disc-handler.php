<?php
$answers = array(
    'D' => 0,
    'I' => 0,
    'S' => 0,
    'C' => 0,
);

// Debugging: Tambahkan log untuk memeriksa data POST
error_log('Data POST: ' . print_r($_POST, true));

foreach ($_POST as $key => $value) {
    if (isset($answers[$value])) {
        $answers[$value]++;
    }
}

// Debugging: Tambahkan log untuk memeriksa jawaban yang dihitung
error_log('Jawaban yang dihitung: ' . print_r($answers, true));

$max_value = max($answers);
$result = '';
foreach ($answers as $key => $value) {
    if ($value == $max_value) {
        $result = $key;
        break;
    }
}

// Debugging: Tambahkan log untuk memeriksa hasil
error_log('Hasil: ' . $result);

if ($result == '') {
    wp_send_json_error('Hasil tes tidak ditemukan.');
    exit;
}

// Meng-include file analisis
include_once plugin_dir_path(__FILE__) . '../analyses/disc-analysis.php';

$analysis = get_disc_analysis($answers); // Mengirimkan array $answers untuk mendapatkan analisis lengkap

// Debugging: Tambahkan log untuk memeriksa analisis
error_log('Analisis: ' . $analysis);

wp_send_json_success('Hasil Tes Anda: <br><br>' . $analysis);
?>
