<?php
$transformational_score = 0;
$transactional_score = 0;
$laissez_faire_score = 0;

$transformational_questions = 20;
$transactional_questions = 12;
$laissez_faire_questions = 4;

foreach ($_POST as $key => $value) {
    if (is_numeric($value)) {
        if (strpos($key, 'transformational') !== false) {
            $transformational_score += intval($value);
        } elseif (strpos($key, 'transactional') !== false) {
            $transactional_score += intval($value);
        } elseif (strpos($key, 'laissez_faire') !== false) {
            $laissez_faire_score += intval($value);
        }
    }
}

$transformational_average = $transformational_score / $transformational_questions;
$transactional_average = $transactional_score / $transactional_questions;
$laissez_faire_average = $laissez_faire_score / $laissez_faire_questions;

// Meng-include file analisis
include_once plugin_dir_path(__FILE__) . '../analyses/mlq-analysis.php';

$analysis = get_mlq_analysis($transformational_average, $transactional_average, $laissez_faire_average);

wp_send_json_success($analysis);
?>
