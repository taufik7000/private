<?php
$answers = array(
    'R' => 0,
    'I' => 0,
    'A' => 0,
    'S' => 0,
    'E' => 0,
    'C' => 0,
    'N' => 0, // Tambahkan ini untuk opsi "Tidak Setuju"
);

foreach ($_POST as $key => $value) {
    if (isset($answers[$value])) {
        $answers[$value]++;
    }
}

unset($answers['N']); // Jangan hitung 'N' (Tidak Setuju) dalam hasil akhir

$result = array_search(max($answers), $answers);
$analysis = get_holland_analysis($result);

wp_send_json_success('Hasil Tes Anda: ' . $result . '<br><br>' . $analysis);

function get_holland_analysis($result) {
    $analyses = array(
        'R' => 'Anda cocok untuk pekerjaan yang melibatkan keterampilan teknis atau kerja fisik.',
        'I' => 'Anda cocok untuk pekerjaan yang melibatkan penelitian dan analisis.',
        'A' => 'Anda cocok untuk pekerjaan yang melibatkan kreativitas dan seni.',
        'S' => 'Anda cocok untuk pekerjaan yang melibatkan interaksi sosial dan membantu orang lain.',
        'E' => 'Anda cocok untuk pekerjaan yang melibatkan kepemimpinan dan bisnis.',
        'C' => 'Anda cocok untuk pekerjaan yang melibatkan detail dan data.'
    );

    return isset($analyses[$result]) ? $analyses[$result] : 'Hasil analisis tidak ditemukan.';
}
?>
