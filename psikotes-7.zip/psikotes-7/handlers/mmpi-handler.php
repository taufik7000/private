<?php
$answers = array(
    'hypochondriasis' => 0,
    'depression' => 0,
    'hysteria' => 0,
    'psychopathic_deviate' => 0,
    'masculinity_femininity' => 0,
    'paranoia' => 0,
    'psychasthenia' => 0,
    'schizophrenia' => 0,
    'hypomania' => 0,
    'social_introversion' => 0,
);

foreach ($_POST as $key => $value) {
    foreach ($questions as $index => $question) {
        if ($value == 'T' && $question['scale'] == $key) {
            $answers[$question['scale']]++;
        }
    }
}

include_once plugin_dir_path(__FILE__) . '../analyses/mmpi-analysis.php';
$analysis = get_mmpi_analysis($answers);

wp_send_json_success('Hasil Tes Anda:<br><br>' . $analysis);
?>
