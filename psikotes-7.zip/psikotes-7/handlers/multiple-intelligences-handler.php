<?php
$answers = array(
    'L' => 0, // Linguistic
    'LM' => 0, // Logical-Mathematical
    'S' => 0, // Spatial
    'BK' => 0, // Bodily-Kinesthetic
    'M' => 0, // Musical
    'IP' => 0, // Interpersonal
    'IA' => 0, // Intrapersonal
    'N' => 0, // Naturalistic
    'NN' => 0 // Not applicable
);

// Debugging: Tambahkan log untuk memeriksa data POST
error_log('Data POST: ' . print_r($_POST, true));

foreach ($_POST as $key => $value) {
    if (isset($answers[$value])) {
        $answers[$value]++;
    }
}

unset($answers['NN']); // Jangan hitung 'NN' (Tidak Setuju) dalam hasil akhir

arsort($answers); // Mengurutkan berdasarkan nilai tertinggi
$topIntelligences = array_keys($answers, max($answers)); // Mengambil kecerdasan dengan nilai tertinggi

// Meng-include file analisis
include_once plugin_dir_path(__FILE__) . '../analyses/multiple-intelligences-analysis.php';

// Mendapatkan analisis untuk setiap kecerdasan dengan nilai tertinggi
$analysis = '';
foreach ($topIntelligences as $intelligence) {
    $analysis .= get_multiple_intelligences_analysis($intelligence) . '<br>';
}

// Debugging: Tambahkan log untuk memeriksa hasil
error_log('Hasil: ' . implode(', ', $topIntelligences));

// Debugging: Tambahkan log untuk memeriksa analisis
error_log('Analisis: ' . $analysis);

wp_send_json_success('Hasil Tes Anda: ' . implode(', ', $topIntelligences) . '<br><br>' . $analysis);
?>
