<?php
$scores = array(
    'directing' => 0,
    'coaching' => 0,
    'supporting' => 0,
    'delegating' => 0,
);

foreach ($_POST as $key => $value) {
    if (strpos($key, 'question') !== false) {
        $scores[$value] += 1;
    }
}

include_once plugin_dir_path(__FILE__) . '../analyses/slq-analysis.php';
$analysis = get_slq_analysis($scores);

wp_send_json_success('Hasil Tes Anda:<br><br>' . $analysis);
?>
