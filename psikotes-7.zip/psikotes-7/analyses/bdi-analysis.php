<?php
function get_bdi_analysis($total_score) {
    $analysis = '';

    if ($total_score <= 13) {
        $analysis .= '<b>Depresi Minimal:</b> Anda tidak menunjukkan gejala depresi yang signifikan. Kondisi Anda dalam batas normal.<br><br>';
    } elseif ($total_score <= 19) {
        $analysis .= '<b>Depresi Ringan:</b> Anda menunjukkan beberapa gejala depresi ringan. Disarankan untuk memonitor kondisi Anda dan mungkin berkonsultasi dengan profesional kesehatan mental.<br><br>';
    } elseif ($total_score <= 28) {
        $analysis .= '<b>Depresi Sedang:</b> Anda menunjukkan gejala depresi sedang. Disarankan untuk berkonsultasi dengan profesional kesehatan mental untuk evaluasi dan saran lebih lanjut.<br><br>';
    } else {
        $analysis .= '<b>Depresi Berat:</b> Anda menunjukkan gejala depresi yang berat. Sangat disarankan untuk segera berkonsultasi dengan profesional kesehatan mental untuk mendapatkan bantuan yang diperlukan.<br><br>';
    }

    return $analysis;
}
?>
