<?php
function get_das_analysis($consensus, $satisfaction, $cohesion, $affectional_expression) {
    $analysis = "";

    // Analisis untuk Consensus
    if ($consensus >= 3.5) {
        $analysis .= "Anda dan pasangan Anda memiliki tingkat kesepakatan yang tinggi pada berbagai isu. Ini menunjukkan komunikasi yang baik dan pemahaman bersama yang kuat.<br>";
    } elseif ($consensus >= 2.5) {
        $analysis .= "Anda dan pasangan Anda memiliki tingkat kesepakatan yang cukup baik. Namun, ada beberapa area yang mungkin memerlukan diskusi lebih lanjut.<br>";
    } else {
        $analysis .= "Anda dan pasangan Anda memiliki tingkat kesepakatan yang rendah. Disarankan untuk lebih sering berdiskusi dan mencoba memahami pandangan satu sama lain.<br>";
    }

    // Analisis untuk Satisfaction
    if ($satisfaction >= 3.5) {
        $analysis .= "Anda sangat puas dengan hubungan Anda secara keseluruhan. Ini menunjukkan tingkat kebahagiaan dan stabilitas yang tinggi dalam hubungan Anda.<br>";
    } elseif ($satisfaction >= 2.5) {
        $analysis .= "Anda cukup puas dengan hubungan Anda. Namun, ada beberapa area yang mungkin bisa ditingkatkan untuk mencapai kepuasan yang lebih tinggi.<br>";
    } else {
        $analysis .= "Anda kurang puas dengan hubungan Anda. Disarankan untuk mengevaluasi apa yang menyebabkan ketidakpuasan dan mencari solusi bersama pasangan.<br>";
    }

    // Analisis untuk Cohesion
    if ($cohesion >= 3.5) {
        $analysis .= "Anda dan pasangan Anda memiliki tingkat keintiman dan kedekatan emosional yang tinggi. Ini menunjukkan hubungan yang erat dan saling mendukung.<br>";
    } elseif ($cohesion >= 2.5) {
        $analysis .= "Anda dan pasangan Anda memiliki keintiman yang cukup baik. Namun, Anda mungkin bisa mencari cara untuk lebih sering menghabiskan waktu berkualitas bersama.<br>";
    } else {
        $analysis .= "Anda dan pasangan Anda memiliki keintiman yang rendah. Disarankan untuk mencari waktu lebih banyak untuk beraktivitas bersama dan memperkuat hubungan emosional.<br>";
    }

    // Analisis untuk Affectional Expression
    if ($affectional_expression >= 3.5) {
        $analysis .= "Anda dan pasangan Anda memiliki tingkat ekspresi kasih sayang yang tinggi. Ini menunjukkan bahwa Anda sering menunjukkan perasaan cinta dan penghargaan satu sama lain.<br>";
    } elseif ($affectional_expression >= 2.5) {
        $analysis .= "Anda dan pasangan Anda memiliki ekspresi kasih sayang yang cukup baik. Namun, meningkatkan frekuensi dan kualitas ekspresi kasih sayang bisa membawa hubungan ke tingkat yang lebih baik.<br>";
    } else {
        $analysis .= "Anda dan pasangan Anda memiliki ekspresi kasih sayang yang rendah. Disarankan untuk lebih sering menunjukkan rasa cinta dan penghargaan satu sama lain.<br>";
    }

    return $analysis;
}
?>
