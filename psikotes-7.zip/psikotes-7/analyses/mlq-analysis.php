<?php
function get_mlq_analysis($transformational, $transactional, $laissez_faire) {
    $analysis = "";

    // Analisis untuk Transformational Leadership
    if ($transformational >= 3.5) {
        $analysis .= "Anda menunjukkan kepemimpinan transformasional yang tinggi. Anda mampu menginspirasi dan memotivasi bawahan dengan visi yang jelas dan nilai-nilai yang kuat.<br>";
    } elseif ($transformational >= 2.5) {
        $analysis .= "Anda memiliki tingkat kepemimpinan transformasional yang cukup baik. Namun, ada beberapa area yang bisa ditingkatkan untuk menjadi lebih efektif dalam memotivasi bawahan.<br>";
    } else {
        $analysis .= "Anda memiliki tingkat kepemimpinan transformasional yang rendah. Disarankan untuk lebih fokus pada pengembangan visi yang jelas dan menginspirasi bawahan Anda.<br>";
    }

    // Analisis untuk Transactional Leadership
    if ($transactional >= 3.5) {
        $analysis .= "Anda menunjukkan kepemimpinan transaksional yang tinggi. Anda mampu menetapkan tujuan yang jelas dan memberikan imbalan yang sesuai.<br>";
    } elseif ($transactional >= 2.5) {
        $analysis .= "Anda memiliki tingkat kepemimpinan transaksional yang cukup baik. Namun, ada beberapa area yang bisa ditingkatkan untuk menjadi lebih efektif dalam memberikan imbalan.<br>";
    } else {
        $analysis .= "Anda memiliki tingkat kepemimpinan transaksional yang rendah. Disarankan untuk lebih fokus pada menetapkan tujuan yang jelas dan memberikan imbalan yang sesuai.<br>";
    }

    // Analisis untuk Laissez-faire Leadership
    if ($laissez_faire >= 3.5) {
        $analysis .= "Anda menunjukkan gaya kepemimpinan laissez-faire yang tinggi. Anda cenderung membiarkan bawahan menyelesaikan masalah mereka sendiri tanpa campur tangan.<br>";
    } elseif ($laissez_faire >= 2.5) {
        $analysis .= "Anda memiliki tingkat kepemimpinan laissez-faire yang cukup baik. Namun, ada beberapa area yang bisa ditingkatkan untuk lebih aktif dalam pengambilan keputusan.<br>";
    } else {
        $analysis .= "Anda memiliki tingkat kepemimpinan laissez-faire yang rendah. Disarankan untuk lebih fokus pada pengambilan keputusan dan memberikan arahan kepada bawahan.<br>";
    }

    return $analysis;
}
?>
