<?php
function get_lpi_analysis($scores) {
    $analysis = '';

    // Model the Way
    $model_the_way_score = $scores['model_the_way'] / 6;
    $analysis .= '<b>Model the Way:</b> ';
    if ($model_the_way_score >= 7) {
        $analysis .= 'Anda sangat baik dalam menetapkan contoh melalui tindakan Anda dan menjaga integritas serta kejujuran.<br>';
    } elseif ($model_the_way_score >= 4) {
        $analysis .= 'Anda cukup baik dalam menetapkan contoh dan menjaga integritas. Ada beberapa area yang dapat ditingkatkan.<br>';
    } else {
        $analysis .= 'Anda mungkin perlu lebih fokus pada menetapkan contoh dan menjaga standar etika yang tinggi.<br>';
    }

    // Inspire a Shared Vision
    $inspire_a_shared_vision_score = $scores['inspire_a_shared_vision'] / 6;
    $analysis .= '<b>Inspire a Shared Vision:</b> ';
    if ($inspire_a_shared_vision_score >= 7) {
        $analysis .= 'Anda sangat baik dalam menginspirasi orang lain dengan visi masa depan yang menarik.<br>';
    } elseif ($inspire_a_shared_vision_score >= 4) {
        $analysis .= 'Anda cukup baik dalam menginspirasi dan memotivasi orang lain. Ada beberapa area yang dapat ditingkatkan.<br>';
    } else {
        $analysis .= 'Anda mungkin perlu lebih fokus pada menginspirasi dan berbagi visi masa depan.<br>';
    }

    // Challenge the Process
    $challenge_the_process_score = $scores['challenge_the_process'] / 6;
    $analysis .= '<b>Challenge the Process:</b> ';
    if ($challenge_the_process_score >= 7) {
        $analysis .= 'Anda sangat baik dalam mencari peluang untuk inovasi dan perbaikan.<br>';
    } elseif ($challenge_the_process_score >= 4) {
        $analysis .= 'Anda cukup baik dalam mencari cara baru dan mengambil risiko. Ada beberapa area yang dapat ditingkatkan.<br>';
    } else {
        $analysis .= 'Anda mungkin perlu lebih fokus pada inovasi dan mengambil risiko yang diperhitungkan.<br>';
    }

    // Enable Others to Act
    $enable_others_to_act_score = $scores['enable_others_to_act'] / 6;
    $analysis .= '<b>Enable Others to Act:</b> ';
    if ($enable_others_to_act_score >= 7) {
        $analysis .= 'Anda sangat baik dalam memberdayakan orang lain untuk bertindak dan bekerja sama.<br>';
    } elseif ($enable_others_to_act_score >= 4) {
        $analysis .= 'Anda cukup baik dalam mendorong kolaborasi dan memberikan dukungan. Ada beberapa area yang dapat ditingkatkan.<br>';
    } else {
        $analysis .= 'Anda mungkin perlu lebih fokus pada pemberdayaan dan kolaborasi.<br>';
    }

    // Encourage the Heart
    $encourage_the_heart_score = $scores['encourage_the_heart'] / 6;
    $analysis .= '<b>Encourage the Heart:</b> ';
    if ($encourage_the_heart_score >= 7) {
        $analysis .= 'Anda sangat baik dalam mengakui kontribusi dan merayakan kemenangan tim.<br>';
    } elseif ($encourage_the_heart_score >= 4) {
        $analysis .= 'Anda cukup baik dalam memberikan penghargaan dan pengakuan. Ada beberapa area yang dapat ditingkatkan.<br>';
    } else {
        $analysis .= 'Anda mungkin perlu lebih fokus pada mengakui dan merayakan pencapaian orang lain.<br>';
    }

    return $analysis;
}
?>
