<?php
function get_msceit_analysis($scores) {
    $categories = [
        'perceiving_emotions' => 'merasakan emosi',
        'using_emotions' => 'menggunakan emosi',
        'understanding_emotions' => 'memahami emosi',
        'managing_emotions' => 'mengelola emosi'
    ];

    $templates = [
        'perceiving_emotions' => [
            'high' => 'Anda sangat baik dalam mengenali emosi orang lain, membantu Anda memahami perasaan mereka dan merespons dengan tepat.',
            'medium' => 'Anda cukup baik dalam mengenali emosi orang lain. Dengan lebih banyak perhatian pada ekspresi emosional, kemampuan ini dapat meningkat.',
            'low' => 'Anda mungkin kesulitan dalam mengenali emosi orang lain. Lebih memperhatikan isyarat non-verbal dan ekspresi wajah dapat membantu.'
        ],
        'using_emotions' => [
            'high' => 'Anda sangat baik dalam menggunakan emosi untuk mencapai tujuan, menjaga motivasi dan produktivitas.',
            'medium' => 'Anda cukup baik dalam menggunakan emosi untuk mencapai tujuan. Refleksi diri dapat membantu meningkatkan kemampuan ini.',
            'low' => 'Anda mungkin menemukan tantangan dalam menggunakan emosi untuk mencapai tujuan. Memahami lebih dalam pengaruh emosi pada kinerja dapat membantu.'
        ],
        'understanding_emotions' => [
            'high' => 'Anda sangat baik dalam memahami dan menganalisis emosi, memungkinkan Anda membuat keputusan yang baik dalam situasi emosional.',
            'medium' => 'Anda cukup baik dalam memahami dan menganalisis emosi. Mempelajari lebih lanjut tentang psikologi emosi dapat memperdalam kemampuan ini.',
            'low' => 'Anda mungkin kesulitan dalam memahami dan menganalisis emosi. Belajar lebih banyak tentang bagaimana emosi bekerja dapat membantu.'
        ],
        'managing_emotions' => [
            'high' => 'Anda sangat baik dalam mengelola emosi, membantu menjaga kesejahteraan emosional dan hubungan yang sehat.',
            'medium' => 'Anda cukup baik dalam mengelola emosi. Berlatih teknik manajemen stres dan emosi dapat meningkatkan kemampuan ini.',
            'low' => 'Anda mungkin menemukan tantangan dalam mengelola emosi. Teknik manajemen stres dan emosi dapat membantu meningkatkan kesejahteraan emosional.'
        ]
    ];

    $details = [];

    foreach ($scores as $category => $score) {
        if ($score > 3) {
            $level = 'high';
        } elseif ($score > 1) {
            $level = 'medium';
        } else {
            $level = 'low';
        }

        $details[] = $templates[$category][$level] . ' Kemampuan Anda untuk ' . $categories[$category] . ' berada pada tingkat ' . ($level == 'high' ? 'sangat baik' : ($level == 'medium' ? 'cukup baik' : 'kurang baik')) . '.';
    }

    $analysis = 'Berdasarkan hasil tes MSCEIT Anda, kami menemukan bahwa ' . implode('<br><br>', $details);

    return $analysis;
}
?>
