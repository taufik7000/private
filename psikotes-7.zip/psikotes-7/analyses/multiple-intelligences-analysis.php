<?php
function get_multiple_intelligences_analysis($result) {
    $analyses = array(
        'L' => 'Anda memiliki kecerdasan linguistik tinggi, yang berarti Anda sangat baik dalam bahasa, membaca, menulis, dan berbicara.',
        'LM' => 'Anda memiliki kecerdasan logika-matematika tinggi, yang berarti Anda sangat baik dalam pemecahan masalah, matematika, dan analisis logis.',
        'S' => 'Anda memiliki kecerdasan spasial tinggi, yang berarti Anda sangat baik dalam visualisasi, desain, dan orientasi ruang.',
        'BK' => 'Anda memiliki kecerdasan kinestetik tinggi, yang berarti Anda sangat baik dalam gerakan fisik, koordinasi, dan keterampilan tangan.',
        'M' => 'Anda memiliki kecerdasan musikal tinggi, yang berarti Anda sangat baik dalam memahami, membuat, dan mengekspresikan musik.',
        'IP' => 'Anda memiliki kecerdasan interpersonal tinggi, yang berarti Anda sangat baik dalam memahami dan berinteraksi dengan orang lain.',
        'IA' => 'Anda memiliki kecerdasan intrapersonal tinggi, yang berarti Anda sangat baik dalam memahami diri sendiri, refleksi diri, dan introspeksi.',
        'N' => 'Anda memiliki kecerdasan naturalistik tinggi, yang berarti Anda sangat baik dalam memahami dan bekerja dengan alam, tumbuhan, dan hewan.'
    );

    return isset($analyses[$result]) ? $analyses[$result] : 'Analisis tidak ditemukan.';
}
?>
