<?php
function get_stanford_binet_analysis($scores) {
    // Definisikan deskripsi hasil berdasarkan rentang skor
    $analyses = array(
        'verbal' => array(
            'low' => 'Anda mungkin menghadapi kesulitan dalam memahami dan menggunakan bahasa. Disarankan untuk meningkatkan kemampuan membaca dan berbicara.',
            'medium' => 'Anda memiliki kemampuan verbal yang cukup baik, namun masih ada ruang untuk perbaikan.',
            'high' => 'Anda memiliki kecerdasan verbal yang sangat baik, mampu memahami dan menggunakan bahasa dengan efektif.'
        ),
        'matematika' => array(
            'low' => 'Anda mungkin menghadapi kesulitan dalam memahami konsep matematika dan melakukan perhitungan. Disarankan untuk berlatih lebih sering.',
            'medium' => 'Anda memiliki kemampuan matematika yang cukup baik, namun masih ada ruang untuk perbaikan.',
            'high' => 'Anda memiliki kecerdasan matematika yang sangat baik, mampu memahami konsep matematika dan melakukan perhitungan dengan baik.'
        ),
        'spasial' => array(
            'low' => 'Anda mungkin menghadapi kesulitan dalam memahami dan memanipulasi bentuk dan ruang. Disarankan untuk berlatih dengan kegiatan visual seperti menggambar.',
            'medium' => 'Anda memiliki kemampuan spasial yang cukup baik, namun masih ada ruang untuk perbaikan.',
            'high' => 'Anda memiliki kecerdasan spasial yang sangat baik, mampu memahami dan memanipulasi bentuk dan ruang dengan baik.'
        ),
        'penalaran' => array(
            'low' => 'Anda mungkin menghadapi kesulitan dalam menganalisis dan memahami hubungan antar konsep. Disarankan untuk berlatih dengan teka-teki dan permainan logika.',
            'medium' => 'Anda memiliki kemampuan penalaran yang cukup baik, namun masih ada ruang untuk perbaikan.',
            'high' => 'Anda memiliki kemampuan penalaran yang sangat baik, mampu menganalisis dan memahami hubungan antar konsep.'
        )
    );

    // Tentukan hasil berdasarkan skor
    $results = array();
    foreach ($scores as $category => $score) {
        if ($score <= 3) {
            $results[$category] = $analyses[$category]['low'];
        } elseif ($score <= 7) {
            $results[$category] = $analyses[$category]['medium'];
        } else {
            $results[$category] = $analyses[$category]['high'];
        }
    }

    return $results;
}
?>
