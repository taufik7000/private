<?php
function get_phq9_analysis($total_score) {
    $analysis = '';

    if ($total_score <= 4) {
        $analysis .= '<b>Depresi Minimal atau Tidak Ada:</b> Anda tidak menunjukkan gejala depresi yang signifikan. Kondisi Anda dalam batas normal.<br><br>';
    } elseif ($total_score <= 9) {
        $analysis .= '<b>Depresi Ringan:</b> Anda menunjukkan beberapa gejala depresi ringan. Disarankan untuk memonitor kondisi Anda dan mungkin berkonsultasi dengan profesional kesehatan mental.<br><br>';
    } elseif ($total_score <= 14) {
        $analysis .= '<b>Depresi Sedang:</b> Anda menunjukkan gejala depresi sedang. Disarankan untuk berkonsultasi dengan profesional kesehatan mental untuk evaluasi dan saran lebih lanjut.<br><br>';
    } elseif ($total_score <= 19) {
        $analysis .= '<b>Depresi Sedang Berat:</b> Anda menunjukkan gejala depresi yang cukup berat. Sangat disarankan untuk segera berkonsultasi dengan profesional kesehatan mental untuk mendapatkan bantuan yang diperlukan.<br><br>';
    } else {
        $analysis .= '<b>Depresi Berat:</b> Anda menunjukkan gejala depresi yang sangat berat. Sangat disarankan untuk segera berkonsultasi dengan profesional kesehatan mental untuk mendapatkan bantuan yang diperlukan.<br><br>';
    }

    return $analysis;
}
?>
