<?php
function get_ras_analysis($average_score) {
    if ($average_score >= 4.5) {
        return 'Anda sangat puas dengan hubungan Anda. 
        Hubungan Anda tampaknya sangat kuat dan memuaskan. 
        Teruslah menjaga komunikasi yang baik dan dukungan satu sama lain. 
        Untuk mempertahankan kualitas ini, cobalah untuk tetap terbuka dalam berkomunikasi dan terus mencari waktu berkualitas bersama.';
    } elseif ($average_score >= 3.5) {
        return 'Anda cukup puas dengan hubungan Anda. 
        Meskipun hubungan Anda umumnya memuaskan, ada beberapa area yang mungkin memerlukan perhatian lebih. 
        Pertimbangkan untuk memperbaiki aspek-aspek kecil yang mungkin mengganggu Anda. 
        Diskusikan perasaan Anda dengan pasangan untuk memastikan bahwa keduanya merasa didengar dan dihargai.';
    } elseif ($average_score >= 2.5) {
        return 'Anda merasa hubungan Anda cukup baik, namun ada beberapa hal yang perlu diperbaiki. 
        Mungkin ada beberapa ketidaksepakatan atau kurangnya komunikasi yang perlu diatasi. 
        Pertimbangkan untuk mengikuti sesi konseling hubungan atau mencari sumber daya untuk membantu memperkuat komunikasi dan resolusi konflik.';
    } elseif ($average_score >= 1.5) {
        return 'Anda merasa hubungan Anda kurang memuaskan dan perlu banyak perbaikan. 
        Ada beberapa masalah signifikan yang mungkin memerlukan perhatian segera. 
        Pertimbangkan untuk berbicara dengan pasangan Anda secara terbuka tentang perasaan Anda. 
        Jika diperlukan, carilah bantuan dari konselor profesional untuk membantu mengatasi masalah yang lebih dalam dan menemukan cara untuk memperbaiki hubungan Anda.';
    } else {
        return 'Anda sangat tidak puas dengan hubungan Anda. 
        Hubungan Anda mungkin menghadapi banyak tantangan dan membutuhkan perubahan besar. 
        Sangat penting untuk mencari bantuan profesional, seperti konselor hubungan, untuk membantu Anda dan pasangan memahami masalah yang dihadapi dan mencari solusi yang efektif. 
        Jangan ragu untuk mencari dukungan dari teman atau keluarga terdekat selama proses ini.';
    }
}
?>
