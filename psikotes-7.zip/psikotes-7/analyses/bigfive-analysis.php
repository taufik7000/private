<?php
function get_bigfive_analysis($answers, $traitQuestions) {
    $descriptions = array(
        'O' => 'Openness to Experience',
        'C' => 'Conscientiousness',
        'E' => 'Extraversion',
        'A' => 'Agreeableness',
        'N' => 'Neuroticism'
    );

    $details = array(
        'O' => array(
            'low' => 'Kamu cenderung konservatif dan lebih suka rutinitas daripada perubahan dan inovasi.',
            'medium' => 'Kamu terbuka terhadap pengalaman baru tetapi tetap menghargai stabilitas dan rutinitas.',
            'high' => 'Kamu sangat terbuka terhadap pengalaman baru, ide-ide kreatif, dan memiliki imajinasi yang kaya.'
        ),
        'C' => array(
            'low' => 'Kamu mungkin cenderung kurang terorganisir dan kurang bertanggung jawab dalam mencapai tujuan.',
            'medium' => 'Kamu terorganisir dan bertanggung jawab, tetapi juga bisa fleksibel dan mudah beradaptasi.',
            'high' => 'Kamu sangat teliti, terorganisir, dan memiliki dorongan yang kuat untuk mencapai tujuan.'
        ),
        'E' => array(
            'low' => 'Kamu mungkin lebih introvert, lebih suka lingkungan yang tenang dan aktivitas soliter.',
            'medium' => 'Kamu seimbang antara bersosialisasi dan menikmati waktu sendiri.',
            'high' => 'Kamu sangat energik, suka berinteraksi dengan orang lain, dan merasa nyaman dalam situasi sosial.'
        ),
        'A' => array(
            'low' => 'Kamu mungkin cenderung kompetitif dan kurang memperhatikan kesejahteraan orang lain.',
            'medium' => 'Kamu seimbang antara bersikap kooperatif dan menjaga kepentingan pribadi.',
            'high' => 'Kamu sangat kooperatif, penyayang, dan memiliki perhatian terhadap kesejahteraan orang lain.'
        ),
        'N' => array(
            'low' => 'Kamu cenderung stabil secara emosional dan jarang mengalami emosi negatif.',
            'medium' => 'Kamu mengalami emosi negatif dari waktu ke waktu tetapi bisa mengatasinya dengan baik.',
            'high' => 'Kamu mungkin sering mengalami emosi negatif seperti kecemasan, kemarahan, atau depresi.'
        )
    );

    $suggestions = array(
        'O' => array(
            'low' => 'Cobalah untuk terbuka terhadap pengalaman baru dengan mencoba hal-hal kecil yang berbeda dari rutinitasmu.',
            'medium' => 'Lanjutkan keseimbangan antara rutinitas dan mencoba hal-hal baru. Jangan takut untuk mengeksplorasi ide-ide baru.',
            'high' => 'Teruslah mengeksplorasi dan mencoba hal-hal baru, tetapi pastikan untuk tidak mengabaikan stabilitas dan rutinitas yang ada.'
        ),
        'C' => array(
            'low' => 'Cobalah untuk lebih terorganisir dengan membuat daftar tugas harian dan menetapkan tujuan jangka pendek.',
            'medium' => 'Pertahankan keseimbangan antara fleksibilitas dan keteraturan. Pastikan untuk tetap terorganisir dalam tugas-tugas penting.',
            'high' => 'Teruslah bekerja dengan teliti dan terorganisir, tetapi ingat untuk juga memberikan waktu untuk relaksasi dan fleksibilitas.'
        ),
        'E' => array(
            'low' => 'Cobalah untuk lebih berinteraksi dengan orang lain dan bergabung dalam aktivitas sosial yang menyenangkan.',
            'medium' => 'Pertahankan keseimbangan antara waktu sosial dan waktu pribadi. Jangan ragu untuk berpartisipasi dalam kegiatan sosial yang menarik.',
            'high' => 'Nikmati energi sosialmu dan terus berinteraksi dengan orang lain. Pastikan juga untuk memberikan waktu untuk diri sendiri untuk mengisi ulang energi.'
        ),
        'A' => array(
            'low' => 'Cobalah untuk lebih memperhatikan kebutuhan dan perasaan orang lain dalam interaksi sehari-hari.',
            'medium' => 'Pertahankan sikap kooperatif dan ramah. Jangan ragu untuk menunjukkan perhatian dan kepedulian kepada orang lain.',
            'high' => 'Teruslah menunjukkan empati dan perhatian kepada orang lain. Pastikan juga untuk menjaga keseimbangan dengan kepentingan pribadimu.'
        ),
        'N' => array(
            'low' => 'Teruslah menjaga stabilitas emosionalmu. Cobalah untuk berbagi kebahagiaan dan ketenangan dengan orang lain.',
            'medium' => 'Pertahankan kemampuanmu dalam mengelola emosi negatif. Carilah dukungan ketika kamu merasa cemas atau tertekan.',
            'high' => 'Cobalah untuk mengidentifikasi penyebab emosi negatifmu dan cari cara untuk mengelolanya. Jangan ragu untuk mencari bantuan profesional jika diperlukan.'
        )
    );

    $analysis = '<div class="analysis-container">';
    foreach ($answers as $trait => $count) {
        // Perhitungan persentase berdasarkan jumlah total pertanyaan
        $percentage = ($count / $traitQuestions[$trait]) * 100;
        $percentage = min($percentage, 100); // Pastikan persentase tidak melebihi 100%
        
        // Kategori persentase
        if ($percentage < 40) {
            $category = 'low';
        } elseif ($percentage < 70) {
            $category = 'medium';
        } else {
            $category = 'high';
        }

        $analysis .= '<div class="trait-analysis">';
        $analysis .= '<h3>' . round($percentage) . '% ' . $descriptions[$trait] . '</h3>';
        $analysis .= '<p>' . $details[$trait][$category] . '</p>';
        $analysis .= '<p><strong>Saran:</strong> ' . $suggestions[$trait][$category] . '</p>';
        $analysis .= '</div>';
    }
    $analysis .= '</div>';

    return $analysis;
}
?>
