<?php
function get_gad7_analysis($total_score) {
    $analysis = '';

    if ($total_score <= 4) {
        $analysis .= '<b>Kecemasan Minimal:</b> Anda tidak menunjukkan gejala kecemasan yang signifikan. Kondisi Anda dalam batas normal.<br><br>';
    } elseif ($total_score <= 9) {
        $analysis .= '<b>Kecemasan Ringan:</b> Anda menunjukkan beberapa gejala kecemasan ringan. Disarankan untuk memonitor kondisi Anda dan mungkin berkonsultasi dengan profesional kesehatan mental.<br><br>';
    } elseif ($total_score <= 14) {
        $analysis .= '<b>Kecemasan Sedang:</b> Anda menunjukkan gejala kecemasan sedang. Disarankan untuk berkonsultasi dengan profesional kesehatan mental untuk evaluasi dan saran lebih lanjut.<br><br>';
    } else {
        $analysis .= '<b>Kecemasan Berat:</b> Anda menunjukkan gejala kecemasan yang berat. Sangat disarankan untuk segera berkonsultasi dengan profesional kesehatan mental untuk mendapatkan bantuan yang diperlukan.<br><br>';
    }

    return $analysis;
}
?>
