<?php
function get_analysis($result) {
    $analyses = array(
        'verbal' => array(
            'low' => 'Kemampuan verbal Anda perlu ditingkatkan. Anda mungkin kesulitan dalam memahami dan menggunakan bahasa secara efektif.',
            'medium' => 'Kemampuan verbal Anda cukup baik. Anda memiliki kemampuan yang memadai dalam memahami dan menggunakan bahasa.',
            'high' => 'Kemampuan verbal Anda sangat baik. Anda memiliki kemampuan yang kuat dalam memahami dan menggunakan bahasa secara efektif.',
        ),
        'arithmetics' => array(
            'low' => 'Kemampuan aritmetika Anda perlu ditingkatkan. Anda mungkin kesulitan dalam melakukan perhitungan matematis dasar.',
            'medium' => 'Kemampuan aritmetika Anda cukup baik. Anda memiliki kemampuan yang memadai dalam melakukan perhitungan matematis dasar.',
            'high' => 'Kemampuan aritmetika Anda sangat baik. Anda memiliki kemampuan yang kuat dalam melakukan perhitungan matematis.',
        ),
        'visual' => array(
            'low' => 'Pemahaman ruang visual Anda perlu ditingkatkan. Anda mungkin kesulitan dalam memvisualisasikan dan memanipulasi objek.',
            'medium' => 'Pemahaman ruang visual Anda cukup baik. Anda memiliki kemampuan yang memadai dalam memvisualisasikan dan memanipulasi objek.',
            'high' => 'Pemahaman ruang visual Anda sangat baik. Anda memiliki kemampuan yang kuat dalam memvisualisasikan dan memanipulasi objek.',
        ),
        'memory' => array(
            'low' => 'Memori kerja Anda perlu ditingkatkan. Anda mungkin kesulitan dalam menyimpan dan memanipulasi informasi sementara.',
            'medium' => 'Memori kerja Anda cukup baik. Anda memiliki kemampuan yang memadai dalam menyimpan dan memanipulasi informasi sementara.',
            'high' => 'Memori kerja Anda sangat baik. Anda memiliki kemampuan yang kuat dalam menyimpan dan memanipulasi informasi sementara.',
        ),
        'processing' => array(
            'low' => 'Kecepatan pemrosesan informasi Anda perlu ditingkatkan. Anda mungkin kesulitan dalam memproses informasi dengan cepat dan efisien.',
            'medium' => 'Kecepatan pemrosesan informasi Anda cukup baik. Anda memiliki kemampuan yang memadai dalam memproses informasi dengan cepat dan efisien.',
            'high' => 'Kecepatan pemrosesan informasi Anda sangat baik. Anda memiliki kemampuan yang kuat dalam memproses informasi dengan cepat dan efisien.',
        ),
    );

    $detailed_analysis = '';
    foreach ($result as $subtest => $score) {
        if ($score <= 3) {
            $detailed_analysis .= $analyses[$subtest]['low'] . '<br>';
        } elseif ($score <= 7) {
            $detailed_analysis .= $analyses[$subtest]['medium'] . '<br>';
        } else {
            $detailed_analysis .= $analyses[$subtest]['high'] . '<br>';
        }
    }

    return $detailed_analysis;
}
