<?php
function get_ssi_analysis($emotional_expressivity, $emotional_sensitivity, $emotional_control, $social_expressivity, $social_sensitivity, $social_control) {
    $analysis = "";

    // Analisis untuk Emotional Expressivity
    if ($emotional_expressivity >= 3.5) {
        $analysis .= "Anda memiliki tingkat ekspresivitas emosional yang tinggi. Anda mampu mengungkapkan emosi Anda dengan jelas dan efektif.<br>";
    } elseif ($emotional_expressivity >= 2.5) {
        $analysis .= "Anda memiliki tingkat ekspresivitas emosional yang cukup baik. Namun, ada beberapa area yang bisa ditingkatkan.<br>";
    } else {
        $analysis .= "Anda memiliki tingkat ekspresivitas emosional yang rendah. Disarankan untuk lebih terbuka dalam mengungkapkan emosi Anda.<br>";
    }

    // Analisis untuk Emotional Sensitivity
    if ($emotional_sensitivity >= 3.5) {
        $analysis .= "Anda sangat sensitif terhadap emosi orang lain. Anda dapat memahami perasaan orang lain dengan sangat baik.<br>";
    } elseif ($emotional_sensitivity >= 2.5) {
        $analysis .= "Anda cukup sensitif terhadap emosi orang lain. Namun, ada beberapa area yang bisa ditingkatkan.<br>";
    } else {
        $analysis .= "Anda kurang sensitif terhadap emosi orang lain. Disarankan untuk lebih memperhatikan isyarat emosional dari orang lain.<br>";
    }

    // Analisis untuk Emotional Control
    if ($emotional_control >= 3.5) {
        $analysis .= "Anda memiliki kontrol emosional yang baik. Anda mampu mengelola dan mengatur emosi Anda dalam berbagai situasi.<br>";
    } elseif ($emotional_control >= 2.5) {
        $analysis .= "Anda cukup baik dalam mengontrol emosi Anda. Namun, ada beberapa area yang bisa ditingkatkan.<br>";
    } else {
        $analysis .= "Anda kurang mampu mengontrol emosi Anda. Disarankan untuk belajar teknik-teknik manajemen emosi.<br>";
    }

    // Analisis untuk Social Expressivity
    if ($social_expressivity >= 3.5) {
        $analysis .= "Anda sangat ekspresif dalam interaksi sosial. Anda mampu berkomunikasi dengan lancar dan efektif.<br>";
    } elseif ($social_expressivity >= 2.5) {
        $analysis .= "Anda cukup ekspresif dalam interaksi sosial. Namun, ada beberapa area yang bisa ditingkatkan.<br>";
    } else {
        $analysis .= "Anda kurang ekspresif dalam interaksi sosial. Disarankan untuk lebih aktif dalam berkomunikasi dengan orang lain.<br>";
    }

    // Analisis untuk Social Sensitivity
    if ($social_sensitivity >= 3.5) {
        $analysis .= "Anda sangat sensitif terhadap isyarat sosial. Anda dapat memahami dan merespons kebutuhan orang lain dengan sangat baik.<br>";
    } elseif ($social_sensitivity >= 2.5) {
        $analysis .= "Anda cukup sensitif terhadap isyarat sosial. Namun, ada beberapa area yang bisa ditingkatkan.<br>";
    } else {
        $analysis .= "Anda kurang sensitif terhadap isyarat sosial. Disarankan untuk lebih memperhatikan isyarat sosial dari orang lain.<br>";
    }

    // Analisis untuk Social Control
    if ($social_control >= 3.5) {
        $analysis .= "Anda sangat baik dalam mengontrol situasi sosial. Anda mampu mengarahkan dan mengatur interaksi sosial dengan efektif.<br>";
    } elseif ($social_control >= 2.5) {
        $analysis .= "Anda cukup baik dalam mengontrol situasi sosial. Namun, ada beberapa area yang bisa ditingkatkan.<br>";
    } else {
        $analysis .= "Anda kurang mampu mengontrol situasi sosial. Disarankan untuk belajar teknik-teknik manajemen interaksi sosial.<br>";
    }

    return $analysis;
}
?>
