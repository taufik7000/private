<?php
function get_sii_analysis($scores) {
    $analysis = '';

    if ($scores['realistic'] > 7) {
        $analysis .= '<b>Realistic:</b> Anda sangat menyukai pekerjaan yang melibatkan alat, mesin, dan aktivitas fisik. Karir yang mungkin cocok untuk Anda termasuk teknisi, mekanik, atau insinyur.<br><br>';
    } elseif ($scores['realistic'] > 4) {
        $analysis .= '<b>Realistic:</b> Anda menikmati pekerjaan dengan alat dan mesin, tetapi mungkin juga memiliki minat lain. Pertimbangkan karir yang menggabungkan minat Anda ini dengan aspek lain yang Anda sukai.<br><br>';
    } else {
        $analysis .= '<b>Realistic:</b> Anda kurang tertarik pada pekerjaan yang melibatkan alat dan mesin. Anda mungkin lebih menikmati pekerjaan yang melibatkan interaksi sosial atau kreatif.<br><br>';
    }

    if ($scores['investigative'] > 7) {
        $analysis .= '<b>Investigative:</b> Anda sangat menikmati penelitian dan analisis. Karir yang mungkin cocok untuk Anda termasuk ilmuwan, peneliti, atau analis data.<br><br>';
    } elseif ($scores['investigative'] > 4) {
        $analysis .= '<b>Investigative:</b> Anda menikmati kegiatan analitis dan penelitian, tetapi mungkin juga memiliki minat lain. Pertimbangkan karir yang memungkinkan Anda melakukan penelitian sambil mengeksplorasi minat lain.<br><br>';
    } else {
        $analysis .= '<b>Investigative:</b> Anda kurang tertarik pada pekerjaan yang melibatkan penelitian dan analisis. Anda mungkin lebih menikmati pekerjaan yang melibatkan interaksi sosial atau praktis.<br><br>';
    }

    if ($scores['artistic'] > 7) {
        $analysis .= '<b>Artistic:</b> Anda sangat menikmati kegiatan kreatif seperti melukis, menulis, atau bermain musik. Karir yang mungkin cocok untuk Anda termasuk seniman, penulis, atau musisi.<br><br>';
    } elseif ($scores['artistic'] > 4) {
        $analysis .= '<b>Artistic:</b> Anda menikmati kegiatan kreatif, tetapi mungkin juga memiliki minat lain. Pertimbangkan karir yang memungkinkan Anda menggunakan kreativitas Anda sambil mengeksplorasi minat lain.<br><br>';
    } else {
        $analysis .= '<b>Artistic:</b> Anda kurang tertarik pada kegiatan kreatif. Anda mungkin lebih menikmati pekerjaan yang melibatkan analisis atau interaksi sosial.<br><br>';
    }

    if ($scores['social'] > 7) {
        $analysis .= '<b>Social:</b> Anda sangat menikmati bekerja dengan orang lain dan membantu mereka. Karir yang mungkin cocok untuk Anda termasuk guru, konselor, atau pekerja sosial.<br><br>';
    } elseif ($scores['social'] > 4) {
        $analysis .= '<b>Social:</b> Anda menikmati interaksi sosial, tetapi mungkin juga memiliki minat lain. Pertimbangkan karir yang memungkinkan Anda bekerja dengan orang lain sambil mengeksplorasi minat lain.<br><br>';
    } else {
        $analysis .= '<b>Social:</b> Anda kurang tertarik pada pekerjaan yang melibatkan interaksi sosial. Anda mungkin lebih menikmati pekerjaan yang melibatkan analisis atau aktivitas fisik.<br><br>';
    }

    if ($scores['enterprising'] > 7) {
        $analysis .= '<b>Enterprising:</b> Anda sangat menikmati memimpin dan membuat keputusan penting. Karir yang mungkin cocok untuk Anda termasuk manajer, pengusaha, atau eksekutif.<br><br>';
    } elseif ($scores['enterprising'] > 4) {
        $analysis .= '<b>Enterprising:</b> Anda menikmati memimpin, tetapi mungkin juga memiliki minat lain. Pertimbangkan karir yang memungkinkan Anda memimpin sambil mengeksplorasi minat lain.<br><br>';
    } else {
        $analysis .= '<b>Enterprising:</b> Anda kurang tertarik pada pekerjaan yang melibatkan kepemimpinan dan pengambilan keputusan. Anda mungkin lebih menikmati pekerjaan yang melibatkan analisis atau aktivitas kreatif.<br><br>';
    }

    if ($scores['conventional'] > 7) {
        $analysis .= '<b>Conventional:</b> Anda sangat menikmati mengatur data dan bekerja dengan angka. Karir yang mungkin cocok untuk Anda termasuk akuntan, analis data, atau petugas administrasi.<br><br>';
    } elseif ($scores['conventional'] > 4) {
        $analysis .= '<b>Conventional:</b> Anda menikmati mengatur data, tetapi mungkin juga memiliki minat lain. Pertimbangkan karir yang memungkinkan Anda bekerja dengan data sambil mengeksplorasi minat lain.<br><br>';
    } else {
        $analysis .= '<b>Conventional:</b> Anda kurang tertarik pada pekerjaan yang melibatkan pengaturan data dan bekerja dengan angka. Anda mungkin lebih menikmati pekerjaan yang melibatkan interaksi sosial atau aktivitas fisik.<br><br>';
    }

    return $analysis;
}
?>
