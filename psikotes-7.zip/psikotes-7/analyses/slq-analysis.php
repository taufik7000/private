<?php
function get_slq_analysis($scores) {
    $analysis = '';

    // Directing
    $directing_score = $scores['directing'];
    $analysis .= '<b>Directing:</b> ' . $directing_score . '<br>';
    if ($directing_score > max($scores['coaching'], $scores['supporting'], $scores['delegating'])) {
        $analysis .= 'Anda cenderung menggunakan gaya kepemimpinan direktif, memberikan arahan yang jelas dan mengawasi pelaksanaannya.<br>';
    }

    // Coaching
    $coaching_score = $scores['coaching'];
    $analysis .= '<b>Coaching:</b> ' . $coaching_score . '<br>';
    if ($coaching_score > max($scores['directing'], $scores['supporting'], $scores['delegating'])) {
        $analysis .= 'Anda cenderung menggunakan gaya kepemimpinan suportif, memberikan instruksi serta dukungan emosional.<br>';
    }

    // Supporting
    $supporting_score = $scores['supporting'];
    $analysis .= '<b>Supporting:</b> ' . $supporting_score . '<br>';
    if ($supporting_score > max($scores['directing'], $scores['coaching'], $scores['delegating'])) {
        $analysis .= 'Anda cenderung menggunakan gaya kepemimpinan partisipatif, mendiskusikan tugas bersama tim dan memberikan dukungan.<br>';
    }

    // Delegating
    $delegating_score = $scores['delegating'];
    $analysis .= '<b>Delegating:</b> ' . $delegating_score . '<br>';
    if ($delegating_score > max($scores['directing'], $scores['coaching'], $scores['supporting'])) {
        $analysis .= 'Anda cenderung menggunakan gaya kepemimpinan delegatif, memberikan tanggung jawab kepada tim untuk menyelesaikan tugas dengan sedikit pengawasan.<br>';
    }

    return $analysis;
}
?>
