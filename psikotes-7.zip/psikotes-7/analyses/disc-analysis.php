<?php
function get_disc_analysis($result) {
    error_log('Hasil yang diterima: ' . print_r($result, true));  // Log nilai yang diterima
    $analyses = array(
        'D' => array(
            'low' => 'Dominant (Low): Anda cenderung tidak ingin memimpin dan lebih suka mengikuti arahan orang lain. Anda mungkin merasa tidak nyaman dalam situasi kompetitif.',
            'medium' => 'Dominant (Medium): Anda memiliki kecenderungan untuk memimpin ketika diperlukan, tetapi tidak selalu mencari kesempatan untuk melakukannya. Anda bisa menyeimbangkan antara mengikuti dan memimpin.',
            'high' => 'Dominant (High): Anda adalah seorang pemimpin alami. Anda tegas, berorientasi pada hasil, dan tidak takut mengambil risiko. Anda suka tantangan dan cenderung mengambil alih situasi.'
        ),
        'I' => array(
            'low' => 'Influence (Low): Anda cenderung pendiam dan tidak terlalu tertarik untuk mempengaruhi atau menginspirasi orang lain. Anda mungkin lebih suka bekerja sendiri atau dalam kelompok kecil.',
            'medium' => 'Influence (Medium): Anda mampu berkomunikasi dengan baik dan bisa mempengaruhi orang lain ketika diperlukan, tetapi tidak selalu mencari kesempatan untuk melakukannya.',
            'high' => 'Influence (High): Anda adalah seorang komunikator yang hebat. Anda suka berinteraksi dengan orang lain dan cenderung menginspirasi dan memotivasi mereka. Anda optimis dan antusias.'
        ),
        'S' => array(
            'low' => 'Steadiness (Low): Anda cenderung tidak terlalu memperhatikan stabilitas dan harmoni dalam lingkungan kerja Anda. Anda mungkin lebih suka perubahan dan tantangan.',
            'medium' => 'Steadiness (Medium): Anda bisa menjaga keseimbangan antara stabilitas dan fleksibilitas. Anda dapat bekerja dengan baik dalam lingkungan yang stabil, tetapi juga mampu beradaptasi dengan perubahan.',
            'high' => 'Steadiness (High): Anda adalah seseorang yang dapat diandalkan dan tenang. Anda suka stabilitas dan harmoni dalam lingkungan kerja Anda. Anda sabar dan cenderung mendukung orang lain.'
        ),
        'C' => array(
            'low' => 'Conscientiousness (Low): Anda cenderung tidak terlalu memperhatikan detail dan mungkin merasa frustrasi dengan aturan dan prosedur. Anda lebih suka pendekatan yang lebih bebas dan kreatif.',
            'medium' => 'Conscientiousness (Medium): Anda dapat bekerja dengan baik dengan detail dan prosedur, tetapi tidak terlalu kaku dalam pendekatan Anda. Anda bisa menyesuaikan diri dengan kebutuhan situasi.',
            'high' => 'Conscientiousness (High): Anda adalah seorang yang analitis dan detail. Anda suka mengikuti prosedur dan standar yang ada. Anda berhati-hati dan cenderung menghindari risiko.'
        ),
    );

    $detailed_analysis = '';
    foreach ($result as $dimension => $score) {
        if ($score <= 3) {
            $detailed_analysis .= $analyses[$dimension]['low'] . '<br>';
        } elseif ($score <= 7) {
            $detailed_analysis .= $analyses[$dimension]['medium'] . '<br>';
        } else {
            $detailed_analysis .= $analyses[$dimension]['high'] . '<br>';
        }
    }

    error_log('Analisis yang ditemukan: ' . $detailed_analysis);  // Log analisis yang ditemukan
    return $detailed_analysis;
}
?>
