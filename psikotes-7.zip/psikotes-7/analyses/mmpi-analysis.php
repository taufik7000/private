<?php
function get_mmpi_analysis($scores) {
    $analysis = '';

    // Hypochondriasis (Hs)
    if ($scores['hypochondriasis'] > 7) {
        $analysis .= '<b>Hypochondriasis:</b> Anda memiliki kecenderungan yang sangat tinggi untuk khawatir tentang kesehatan fisik Anda. Ini mungkin mengindikasikan adanya kelebihan perhatian terhadap gejala fisik yang tidak proporsional dengan kondisi medis yang sebenarnya. Disarankan untuk berkonsultasi dengan profesional kesehatan untuk memastikan bahwa kekhawatiran Anda tidak mengganggu kualitas hidup Anda.<br><br>';
    } elseif ($scores['hypochondriasis'] > 4) {
        $analysis .= '<b>Hypochondriasis:</b> Anda memiliki kecenderungan sedang untuk khawatir tentang kesehatan fisik Anda. Ini mungkin mengindikasikan adanya beberapa kekhawatiran yang valid, tetapi tidak sepenuhnya mendominasi pikiran Anda. Disarankan untuk menjaga keseimbangan antara perhatian terhadap kesehatan dan tidak terlalu cemas.<br><br>';
    } else {
        $analysis .= '<b>Hypochondriasis:</b> Anda memiliki tingkat kekhawatiran kesehatan yang normal dan seimbang. Anda tampaknya dapat mengelola perhatian terhadap kesehatan dengan baik tanpa merasa terlalu cemas.<br><br>';
    }

    // Depression (D)
    if ($scores['depression'] > 7) {
        $analysis .= '<b>Depression:</b> Anda menunjukkan gejala depresi yang tinggi. Ini mungkin termasuk perasaan sedih yang berkelanjutan, kehilangan minat pada aktivitas yang biasa Anda nikmati, dan perubahan dalam pola tidur dan nafsu makan. Disarankan untuk segera berkonsultasi dengan profesional kesehatan mental untuk evaluasi lebih lanjut dan mendapatkan bantuan yang diperlukan.<br><br>';
    } elseif ($scores['depression'] > 4) {
        $analysis .= '<b>Depression:</b> Anda menunjukkan gejala depresi sedang. Ini mungkin termasuk beberapa perasaan sedih atau kehilangan minat, tetapi tidak mendominasi kehidupan Anda sehari-hari. Disarankan untuk memantau gejala ini dan mempertimbangkan untuk berbicara dengan profesional kesehatan mental jika gejala ini berlanjut.<br><br>';
    } else {
        $analysis .= '<b>Depression:</b> Anda menunjukkan tingkat kesejahteraan emosional yang baik dengan sedikit atau tidak ada gejala depresi. Tetap jaga keseimbangan hidup dan kesehatan mental Anda.<br><br>';
    }

    // Hysteria (Hy)
    if ($scores['hysteria'] > 7) {
        $analysis .= '<b>Hysteria:</b> Anda menunjukkan kecenderungan histeria yang tinggi. Ini mungkin mencakup reaksi emosional yang berlebihan terhadap stres dan situasi yang sulit. Disarankan untuk mencari strategi manajemen stres dan mungkin berkonsultasi dengan profesional kesehatan untuk mendapatkan saran lebih lanjut.<br><br>';
    } elseif ($scores['hysteria'] > 4) {
        $analysis .= '<b>Hysteria:</b> Anda menunjukkan beberapa gejala histeria, yang mungkin berarti Anda kadang-kadang bereaksi berlebihan terhadap situasi tertentu. Disarankan untuk mencari cara untuk mengelola reaksi emosional Anda dengan lebih baik.<br><br>';
    } else {
        $analysis .= '<b>Hysteria:</b> Anda menunjukkan reaksi emosional yang normal terhadap stres dan situasi yang sulit. Anda tampaknya memiliki kemampuan yang baik untuk mengelola stres.<br><br>';
    }

    // Psychopathic Deviate (Pd)
    if ($scores['psychopathic_deviate'] > 7) {
        $analysis .= '<b>Psychopathic Deviate:</b> Anda menunjukkan kecenderungan deviasi psikopat yang tinggi, yang mungkin mencakup masalah dengan otoritas, pelanggaran aturan, dan perilaku antisosial. Disarankan untuk berkonsultasi dengan profesional kesehatan mental untuk memahami lebih lanjut dan mendapatkan bantuan yang diperlukan.<br><br>';
    } elseif ($scores['psychopathic_deviate'] > 4) {
        $analysis .= '<b>Psychopathic Deviate:</b> Anda menunjukkan beberapa kecenderungan deviasi psikopat, yang mungkin berarti Anda memiliki beberapa masalah dengan otoritas atau aturan, tetapi tidak mendominasi perilaku Anda. Disarankan untuk memantau dan mencari cara untuk berinteraksi dengan lebih baik dalam konteks sosial.<br><br>';
    } else {
        $analysis .= '<b>Psychopathic Deviate:</b> Anda menunjukkan tingkat kepatuhan terhadap aturan sosial yang baik. Anda tampaknya memiliki kemampuan yang baik untuk berinteraksi dalam konteks sosial tanpa masalah besar.<br><br>';
    }

    // Masculinity-Femininity (Mf)
    if ($scores['masculinity_femininity'] > 7) {
        $analysis .= '<b>Masculinity-Femininity:</b> Anda menunjukkan ketidaksesuaian yang tinggi dengan peran gender tradisional. Ini mungkin mencakup minat atau perilaku yang biasanya tidak dikaitkan dengan gender Anda. Disarankan untuk mengeksplorasi identitas gender Anda lebih lanjut dan mencari dukungan jika diperlukan.<br><br>';
    } elseif ($scores['masculinity_femininity'] > 4) {
        $analysis .= '<b>Masculinity-Femininity:</b> Anda menunjukkan beberapa ketidaksesuaian dengan peran gender tradisional, tetapi masih dalam batas yang umum. Anda mungkin memiliki minat yang bervariasi yang tidak sepenuhnya sesuai dengan stereotip gender.<br><br>';
    } else {
        $analysis .= '<b>Masculinity-Femininity:</b> Anda menunjukkan kesesuaian yang baik dengan peran gender tradisional. Anda tampaknya nyaman dengan identitas gender Anda.<br><br>';
    }

    // Paranoia (Pa)
    if ($scores['paranoia'] > 7) {
        $analysis .= '<b>Paranoia:</b> Anda menunjukkan tingkat paranoia yang tinggi, yang mungkin mencakup kecurigaan berlebihan terhadap motif orang lain dan perasaan diawasi. Disarankan untuk berkonsultasi dengan profesional kesehatan mental untuk evaluasi lebih lanjut dan mendapatkan bantuan yang diperlukan.<br><br>';
    } elseif ($scores['paranoia'] > 4) {
        $analysis .= '<b>Paranoia:</b> Anda menunjukkan beberapa kecenderungan paranoid, yang mungkin berarti Anda memiliki kecurigaan terhadap motif orang lain tetapi tidak mendominasi pikiran Anda. Disarankan untuk memantau perasaan ini dan mencari cara untuk membangun kepercayaan.<br><br>';
    } else {
        $analysis .= '<b>Paranoia:</b> Anda menunjukkan tingkat kepercayaan yang baik terhadap orang lain. Anda tampaknya tidak memiliki kecurigaan berlebihan atau perasaan diawasi.<br><br>';
    }

    // Psychasthenia (Pt)
    if ($scores['psychasthenia'] > 7) {
        $analysis .= '<b>Psychasthenia:</b> Anda menunjukkan tingkat kecemasan yang tinggi, yang mungkin mencakup pikiran yang tidak dapat dikendalikan dan kekhawatiran berlebihan. Disarankan untuk segera berkonsultasi dengan profesional kesehatan mental untuk evaluasi lebih lanjut dan mendapatkan bantuan yang diperlukan.<br><br>';
    } elseif ($scores['psychasthenia'] > 4) {
        $analysis .= '<b>Psychasthenia:</b> Anda menunjukkan beberapa gejala kecemasan, yang mungkin berarti Anda memiliki beberapa kekhawatiran yang valid tetapi tidak sepenuhnya mendominasi pikiran Anda. Disarankan untuk mencari strategi manajemen kecemasan.<br><br>';
    } else {
        $analysis .= '<b>Psychasthenia:</b> Anda menunjukkan tingkat kecemasan yang normal dan seimbang. Anda tampaknya dapat mengelola kekhawatiran Anda dengan baik.<br><br>';
    }

    // Schizophrenia (Sc)
    if ($scores['schizophrenia'] > 7) {
        $analysis .= '<b>Schizophrenia:</b> Anda menunjukkan tanda-tanda skizofrenia yang tinggi, yang mungkin mencakup delusi, halusinasi, dan disorganisasi pikiran. Disarankan untuk segera berkonsultasi dengan profesional kesehatan mental untuk evaluasi lebih lanjut dan mendapatkan bantuan yang diperlukan.<br><br>';
    } elseif ($scores['schizophrenia'] > 4) {
        $analysis .= '<b>Schizophrenia:</b> Anda menunjukkan beberapa gejala skizofrenia, yang mungkin berarti Anda memiliki beberapa gangguan dalam pikiran atau persepsi tetapi tidak sepenuhnya mendominasi kehidupan Anda sehari-hari. Disarankan untuk memantau gejala ini dan mencari bantuan jika diperlukan.<br><br>';
    } else {
        $analysis .= '<b>Schizophrenia:</b> Anda menunjukkan orientasi realitas yang baik tanpa tanda-tanda skizofrenia yang signifikan. Anda tampaknya memiliki kemampuan yang baik untuk memahami dan merespon lingkungan Anda dengan cara yang realistis.<br><br>';
    }

    // Hypomania (Ma)
    if ($scores['hypomania'] > 7) {
        $analysis .= '<b>Hypomania:</b> Anda menunjukkan tanda-tanda hipomania yang tinggi, yang mungkin mencakup energi berlebihan, euforia, dan impulsivitas. Disarankan untuk berkonsultasi dengan profesional kesehatan mental untuk evaluasi lebih lanjut dan mendapatkan bantuan yang diperlukan.<br><br>';
    } elseif ($scores['hypomania'] > 4) {
        $analysis .= '<b>Hypomania:</b> Anda menunjukkan beberapa tanda hipomania, yang mungkin berarti Anda memiliki beberapa periode energi tinggi tetapi tidak sepenuhnya mendominasi perilaku Anda. Disarankan untuk mencari cara untuk menyalurkan energi ini dengan cara yang produktif.<br><br>';
    } else {
        $analysis .= '<b>Hypomania:</b> Anda menunjukkan tingkat energi yang normal dan seimbang. Anda tampaknya dapat mengelola tingkat energi Anda dengan baik tanpa menjadi terlalu impulsif.<br><br>';
    }

    // Social Introversion (Si)
    if ($scores['social_introversion'] > 7) {
        $analysis .= '<b>Social Introversion:</b> Anda menunjukkan kecenderungan introversi sosial yang tinggi, yang mungkin mencakup ketidaknyamanan dalam situasi sosial dan preferensi untuk kesendirian. Disarankan untuk mencari cara untuk terlibat dalam kegiatan sosial secara bertahap dan mencari dukungan jika diperlukan.<br><br>';
    } elseif ($scores['social_introversion'] > 4) {
        $analysis .= '<b>Social Introversion:</b> Anda menunjukkan beberapa kecenderungan introversi sosial, yang mungkin berarti Anda lebih suka lingkungan yang lebih tenang dan memiliki beberapa kesulitan dalam situasi sosial tetapi masih mampu berinteraksi dengan baik. Disarankan untuk mencari keseimbangan antara waktu sendiri dan kegiatan sosial.<br><br>';
    } else {
        $analysis .= '<b>Social Introversion:</b> Anda menunjukkan tingkat interaksi sosial yang baik dengan sedikit atau tidak ada tanda-tanda introversi sosial yang signifikan. Anda tampaknya nyaman dalam situasi sosial.<br><br>';
    }

    return $analysis;
}
?>
