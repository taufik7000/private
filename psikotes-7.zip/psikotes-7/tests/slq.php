<?php
$test_slug = 'slq';
include_once plugin_dir_path(__FILE__) . '../questions/' . $test_slug . '-questions.php';
include_once plugin_dir_path(__FILE__) . '../template-test.php';
?>
