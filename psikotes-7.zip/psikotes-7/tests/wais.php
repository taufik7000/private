<?php
$test_slug = 'wais';
include plugin_dir_path(__FILE__) . '../questions/wais-questions.php';
include plugin_dir_path(__FILE__) . '../template-test.php';
