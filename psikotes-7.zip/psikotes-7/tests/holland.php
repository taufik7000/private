<?php
$test_slug = 'holland';
include plugin_dir_path(__FILE__) . '../questions/holland-questions.php';
include plugin_dir_path(__FILE__) . '../template-test.php';
?>
