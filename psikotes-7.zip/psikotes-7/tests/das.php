<?php
$test_slug = 'das';
include plugin_dir_path(__FILE__) . '../questions/das-questions.php';
include plugin_dir_path(__FILE__) . '../template-test.php';
?>
