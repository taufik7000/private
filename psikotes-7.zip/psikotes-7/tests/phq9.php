<?php
$test_slug = 'phq9';
include_once plugin_dir_path(__FILE__) . '../questions/' . $test_slug . '-questions.php';
include_once plugin_dir_path(__FILE__) . '../template-test.php';
?>
