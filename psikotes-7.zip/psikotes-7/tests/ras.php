<?php
$test_slug = 'ras';
include plugin_dir_path(__FILE__) . '../questions/ras-questions.php';
include plugin_dir_path(__FILE__) . '../template-test.php';
?>
