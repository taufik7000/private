<?php
$test_slug = 'mlq';
include plugin_dir_path(__FILE__) . '../questions/mlq-questions.php';
include plugin_dir_path(__FILE__) . '../template-test.php';
?>
