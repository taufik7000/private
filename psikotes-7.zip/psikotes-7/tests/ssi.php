<?php
$test_slug = 'ssi';
include plugin_dir_path(__FILE__) . '../questions/ssi-questions.php';
include plugin_dir_path(__FILE__) . '../template-test.php';
?>