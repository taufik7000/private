<?php
$test_slug = 'mbti';
include plugin_dir_path(__FILE__) . '../questions/mbti-questions.php';
include plugin_dir_path(__FILE__) . '../template-test.php';
?>
