<?php
$test_slug = 'bigfive';
include plugin_dir_path(__FILE__) . '../questions/bigfive-questions.php';
include plugin_dir_path(__FILE__) . '../template-test.php';
?>
