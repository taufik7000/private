<?php
$test_slug = 'multiple-intelligences';
include plugin_dir_path(__FILE__) . '../questions/multiple-intelligences-questions.php';
include plugin_dir_path(__FILE__) . '../template-test.php';
?>
