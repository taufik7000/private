<div class="progress-bar-container">
    <div class="progress-bar" id="progress-bar"></div>
    <div class="progress-percentage" id="progress-percentage">0%</div>
</div>

<form id="test-form" data-test="<?php echo htmlspecialchars($test_slug, ENT_QUOTES, 'UTF-8'); ?>" data-total-questions="<?php echo count($questions); ?>">
    <?php
    $total_questions = count($questions);
    foreach ($questions as $index => $question) {
        echo '<div class="test-question" id="question_' . ($index + 1) . '"' . ($index >= 1 ? ' style="display:none;"' : '') . '>';
        echo '<p>Soal ' . ($index + 1) . ' / ' . $total_questions . '</p>';
        echo '<h3>' . htmlspecialchars($question['question'], ENT_QUOTES, 'UTF-8') . '</h3>';
        // Tambahkan bagian untuk menampilkan gambar jika ada
        if (isset($question['image']) && !empty($question['image'])) {
            echo '<img src="' . htmlspecialchars($question['image'], ENT_QUOTES, 'UTF-8') . '" alt="Question Image" class="question-image">';
        }
        foreach ($question['options'] as $value => $option) {
            echo '<label class="radio-label">';
            echo '<input type="radio" name="question_' . ($index + 1) . '" value="' . htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . '" required>';
            echo htmlspecialchars($option, ENT_QUOTES, 'UTF-8');
            echo '</label>';
        }
        echo '<div class="navigation-buttons">';
        if ($index >= 1) {
            echo '<button type="button" class="back-button" data-question="' . ($index + 1) . '">Back</button>';
        }
        if ($index < $total_questions - 1) {
            echo '<button type="button" class="next-button" data-question="' . ($index + 1) . '">Next</button>';
        } else {
            echo '<button type="submit" class="submit-button">Submit</button>';
        }
        echo '</div>';
        echo '</div>';
    }
    ?>
    <input type="hidden" name="test" value="<?php echo htmlspecialchars($test_slug, ENT_QUOTES, 'UTF-8'); ?>">
</form>
<div class="spinner" id="loading-spinner"></div>
<div id="test-result" style="display:none;">
    <h2>Hasil Tes</h2>
    <p id="result-text"></p>
    <button id="retry-button" class="retry-button">Ulangi</button>
    <button id="home-button" class="home-button" onclick="window.location.href='/'">Kembali ke Beranda</button>
</div>
